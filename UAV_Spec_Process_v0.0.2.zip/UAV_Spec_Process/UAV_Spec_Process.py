# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import *
from PyQt5.QtCore import *

import os.path
from datetime import datetime
import numpy as np

from .resources import *
from .UAV_Spec_Process_dialog import UAV_Spec_ProcessDialog


class UAV_Spec_Process:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor"""
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'UAV_Spec_Process_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&UAV_Spec_Process')
        self.toolbar = self.iface.addToolBar(u'UAV_Spec_Process')
        self.toolbar.setObjectName(u'UAV_Spec_Process')

    def tr(self, message): return QCoreApplication.translate('UAV_Spec_Process', message)

    def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/UAV_Spec_Process/icon.png'
        self.add_action(icon_path, text=self.tr(u'UAV_Spec_Process'), callback=self.run, parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&UAV_Spec_Process'), action)
            self.iface.removeToolBarIcon(action)

    def progress(self, i, f, proc_freq, proc_text):
        """Progress bar value."""
        if i % proc_freq == 0:
            self.dlg_spectr.progressBar.setValue(int((i/f)*100))
            self.dlg_spectr.progressBar.setFormat(proc_text + str(int((i/f)*100)) + ' %')

            QtWidgets.QApplication.processEvents()


    def merge_gpx_data(self):
        files_all = []
        data_gpx = []
        integrals = []
        data = []

        int_range = [int(self.dlg_spectr.int_min.text())-1, int(self.dlg_spectr.int_max.text())-1]
        K40_range = [int(self.dlg_spectr.K40_min.text())-1, int(self.dlg_spectr.K40_max.text())-1]
        Th_range = [int(self.dlg_spectr.Th_min.text())-1, int(self.dlg_spectr.Th_max.text())-1]
        U_range = [int(self.dlg_spectr.U_min.text())-1, int(self.dlg_spectr.U_max.text())-1]

        int_len = int_range[1] - int_range[0] + 1
        K40_len = K40_range[1] - K40_range[0] + 1
        Th_len = Th_range[1] - Th_range[0] + 1
        U_len = U_range[1] - U_range[0] + 1

        time_form = '%Y-%m-%d %H:%M:%S'

        root_gen = self.dlg_spectr.mQgsFileWidget.filePath()
        if len(root_gen) == 0:
            print('Нет пути')
            return

        # Find files
        for root, dirs, files in os.walk(root_gen):
            for file in files:
                if file.find('.dat') != -1 or file.find('.gpx') != -1:
                    files_all.append(root + '/' + file)

        for i, file in enumerate(files_all):
            self.progress(i, len(files_all), 20, 'Reading Data: ')
            # Read data
            if file.endswith(".dat") or file.endswith(".DAT"):
                time = file[-21:-17]+'-'+file[-17:-15]+'-'+file[-15:-13]+' '+file[-12:-10]+':'+file[-10:-8]+':'+file[-8:-6]
                time_sec = datetime.strptime(time, time_form).timestamp()
 
                data_vals = []
                integ = []
                with open(file, 'r', encoding = 'Windows-1251') as file:
                    lines = file.readlines()
                    for line in lines:
                        val_str = line[9]
                        data_vals.append(int(val_str))

                    int_np = np.array(data_vals[int_range[0]:int_range[1]+1], dtype='int32')
                    K40_np = np.array(data_vals[K40_range[0]:K40_range[1]+1], dtype='int32')
                    Th_np = np.array(data_vals[Th_range[0]:Th_range[1]+1], dtype='int32')
                    U_np = np.array(data_vals[U_range[0]:U_range[1]+1], dtype='int32')

                    integrals = np.sum(int_np) / int_len
                    K40 = np.sum(K40_np) / K40_len
                    Th = np.sum(Th_np) / Th_len
                    U = np.sum(U_np) / U_len

                    data.append((integrals, K40, Th, U, time_sec))

            # Read GPX
            elif file.endswith(".gpx"):
                with open(file, 'r', encoding = 'Windows-1251') as file:
                    line = file.readline()
                    words = line.split('<trkpt ')
                    del words[0]
                    del words[-1]
        
                    for word in words:
                        lat_pos_start = word.find('lat="') + 5
                        lon_pos_start = word.find('lon="') + 5
                        ele_pos_start = word.find('ele>') + 4
                        time_pos_start = word.find('time>') + 5
                        lat_pos_end = word.find('" lon')
                        lon_pos_end = word.find('"><ele')
                        ele_pos_end = word.find('</ele>')
                        time_pos_end = word.find('+')
                        lat = float(word[lat_pos_start:lat_pos_end])
                        lon = float(word[lon_pos_start:lon_pos_end])
                        ele = float(word[ele_pos_start:ele_pos_end])
                        time = word[time_pos_start:time_pos_end]
                        time_f = time.replace('T', ' ')
                        try:
                            time_sec = datetime.strptime(time_f, '%Y-%m-%d %H:%M:%S').timestamp()
                        except:
                            continue
                        data0 = [lat, lon, ele, time_sec]
                        data_gpx.append(data0)

        data.sort(key=lambda x: x[-1], reverse=False)
        data_gpx.sort(key=lambda x: x[-1], reverse=False)

        # Transpose
        list_gpx = list(map(list, zip(*data_gpx)))
        # Cut bad data
        cut_data_gpx = []
        for i in range(1, len(list_gpx[0])):
            if list_gpx[-1][i] != list_gpx[-1][i-1]:
                cut_data_gpx.append(data_gpx[i])
        list_gpx = list(map(list, zip(*cut_data_gpx)))

        # Find intersect times
        gpx_np = np.array(list_gpx, dtype='float64')
        data_np = np.array(data, dtype='float64').T

        intersect_indices = np.intersect1d(gpx_np[-1], data_np[-1], return_indices=True)

        gpx_indices = intersect_indices[1]
        data_indices = intersect_indices[2]

        gpx_lat = gpx_np[0][gpx_indices]
        gpx_lon = gpx_np[1][gpx_indices]
        gpx_alt = gpx_np[2][gpx_indices]
        gpx_time = gpx_np[3][gpx_indices]
        
        int_data = data_np[0][data_indices]
        K40_data = data_np[1][data_indices]
        Th_data = data_np[2][data_indices]
        U_data = data_np[3][data_indices]

        data_all = np.stack((gpx_lon, gpx_lat, gpx_alt, gpx_time, int_data, K40_data, Th_data, U_data)).T

        # Add points
        crs = QgsCoordinateReferenceSystem()
        crs.createFromId(4326)
        pnt = QgsVectorLayer('Point', 'Spectr', 'memory')
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        pr.addAttributes([
                          QgsField('Lon', QVariant.Double, 'double', 7, 7), 
                          QgsField('Lat', QVariant.Double, 'double', 7, 7),
                          QgsField('Alt', QVariant.Double, 'double', 7, 3),
                          QgsField('Time_UNIX', QVariant.Int),
                          QgsField('INT', QVariant.Double, 'double', 2, 5),
                          QgsField('K40', QVariant.Double, 'double', 2, 5),
                          QgsField('Th', QVariant.Double, 'double', 2, 5),
                          QgsField('U', QVariant.Double, 'double', 2, 5),
                         ])
        pnt.updateFields()
        
        fets = []

        for i, val in enumerate(data_all):
            self.progress(i, len(data_all), 10, 'Rendering: ')
            attrs = [float(val[0]), float(val[1]), float(val[2]), int(val[3]), float(val[4]), float(val[5]), float(val[6]), float(val[7])]
            fet = QgsFeature()
            fet.setGeometry(QgsPoint(val[0], val[1]))
            fet.setAttributes(attrs)
            fets.append(fet) 

        pr.addFeatures(fets)
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_spectr.progressBar.setValue(0)
        self.dlg_spectr.progressBar.setFormat(None)

    #--------------------------------------------------------------------------
    # Run plugin
    #--------------------------------------------------------------------------

    def run(self):
        self.dlg_spectr = UAV_Spec_ProcessDialog()
        self.dlg_spectr.show()
        self.dlg_spectr.merge_gpx_data.clicked.connect(self.merge_gpx_data)

        self.dlg_spectr.K40_min.textChanged.connect(self.change_cfg)
        self.dlg_spectr.K40_max.textChanged.connect(self.change_cfg)
        self.dlg_spectr.Th_min.textChanged.connect(self.change_cfg)
        self.dlg_spectr.Th_max.textChanged.connect(self.change_cfg)
        self.dlg_spectr.U_min.textChanged.connect(self.change_cfg)
        self.dlg_spectr.U_max.textChanged.connect(self.change_cfg)

        self.cfg_path = self.plugin_dir + '/cfg.ini'

        with open(self.cfg_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            try:
                self.dlg_spectr.K40_min.setText(str(cfg[0][1]))
                self.dlg_spectr.K40_max.setText(str(cfg[1][1]))
                self.dlg_spectr.Th_min.setText(str(cfg[2][1]))
                self.dlg_spectr.Th_max.setText(str(cfg[3][1]))
                self.dlg_spectr.U_min.setText(str(cfg[4][1]))
                self.dlg_spectr.U_max.setText(str(cfg[5][1]))
            except IndexError:
                pass

    def change_cfg(self):
        with open(self.cfg_path, 'w') as f:
            f.write('K40_min' + '\t' + str(self.dlg_spectr.K40_min.text()) + '\n')
            f.write('K40_max' + '\t' + str(self.dlg_spectr.K40_max.text()) + '\n')
            f.write('Th_min' + '\t' + str(self.dlg_spectr.Th_min.text()) + '\n')
            f.write('Th_max' + '\t' + str(self.dlg_spectr.Th_max.text()) + '\n')
            f.write('U_min' + '\t' + str(self.dlg_spectr.U_min.text()) + '\n')
            f.write('U_max' + '\t' + str(self.dlg_spectr.U_max.text()) + '\n')