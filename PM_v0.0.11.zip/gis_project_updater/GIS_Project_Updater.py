# -*- coding: utf-8 -*-
from .resources import *
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon, QImage, QPixmap
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QLineEdit, QDialog, QCheckBox, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtCore import Qt, QSize
from qgis.core import *
from qgis.gui import QgsMapLayerComboBox
import os
import processing
import shutil
from datetime import datetime



class GIS_Project_Updater:

    def __init__(self, iface):
        self.iface = iface

        self.plugin_dir = os.path.dirname(__file__)

        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'GIS_Project_Updater_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.toolbar = self.iface.addToolBar(u'GIS Project Updater')
        self.toolbar.setObjectName(u'GIS Project Updater')

    def add_action(self, icon_path, text, callback, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(True)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu('GIS Project Updater', action)

        self.actions.append(action)

        return action

    def initGui(self):
        icon_path = ':/plugins/GIS_Project_Updater/icon.png'
        self.add_action(icon_path, text='GIS Project Updater', callback=self.run, parent=self.iface.mainWindow())

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu('GIS Project Updater', action)
            self.iface.removeToolBarIcon(action)


    #----------------------------------------------------------------------
    def pushButton(self):
        layer = QgsVectorLayer("Point", "New_Points", "memory")
        crs = QgsProject.instance().crs()
        layer.setCrs(crs)
        layer.updateExtents()
        pr = layer.dataProvider()
        pr.addAttributes([QgsField('Name', QVariant.String)])
        layer.updateFields()
        QgsProject.instance().addMapLayer(layer)


        fields = layer.fields()
        field_index = fields.indexFromName('Name')

        # Widget type
        #config = {'IsMultiline': True, 'UseHtml': False}
        #widget_setup = QgsEditorWidgetSetup('TextEdit', config)
        #layer.setEditorWidgetSetup(field_index, widget_setup)

        list_values = {"red":"1", "green":"2"}
        config = {'map' : list_values}
        widget_setup = QgsEditorWidgetSetup('ValueMap', config)
        layer.setEditorWidgetSetup(field_index, widget_setup)

        # Default value
        default_value = QgsDefaultValue()
        default_value.setExpression("'Your value'")
        layer.setDefaultValueDefinition(field_index, default_value)


    def add_attr_to_tree(self):
        name_attr = self.dlg_fact.lineEdit_field_name.text()
        type_attr = self.dlg_fact.comboBox.currentText()
        len_attr = self.dlg_fact.lineEdit_lenght.text()
        precissoin_attr = self.dlg_fact.lineEdit_precissoin.text()

        parent = QtWidgets.QTreeWidgetItem(self.tree) 
        self.tree.addTopLevelItem(parent)
        parent.setText(0, name_attr)
        parent.setText(1, type_attr)
        parent.setText(2, len_attr)
        parent.setText(3, precissoin_attr)

    def remove_attr_from_tree(self):
        list_selected = self.tree.selectedItems()

        if len(list_selected) != 0:
            for i in range(len(list_selected)):
                list_selected[i].removeChild(list_selected[i])

    def save_list_fields(self):
        path, ok = QtWidgets.QFileDialog.getSaveFileName(None, 'Save', os.getenv('HOME'), 'SLF(*.slf)')
        if ok:
            root = self.tree.invisibleRootItem()
            items_cnt = root.childCount()
            with open(path, 'w') as f:
                for i in range(items_cnt):
                    item = root.child(i)
                    line = item.text(0) + '\t' + item.text(1) + '\t' + item.text(2) + '\t' + item.text(3) + '\n'
                    f.write(line)

    def load_list_fields(self):
        path, ok = QtWidgets.QFileDialog.getOpenFileName(None, 'Open', os.getenv('HOME'), 'SLF(*.slf)')
        if ok:
            self.tree.clear()
            with open(path, 'r', encoding = 'Windows-1251') as f:
                lines = f.readlines()
                for l in lines:
                    line = l.replace('\n','').split('\t')
                    parent = QtWidgets.QTreeWidgetItem(self.tree) 
                    self.tree.addTopLevelItem(parent)
                    for i in range(4):
                        parent.setText(i, line[i])

    def create_facts(self):
        root = self.tree.invisibleRootItem()
        items_cnt = root.childCount()

        list_attrs = []

        layer_name = self.dlg_fact.lineEdit_layer_name.text()

        layer = QgsVectorLayer("PointZ", layer_name, "memory")
        crs = self.dlg_fact.mQgsProjectionSelectionWidget.crs()
        layer.setCrs(crs)
        layer.updateExtents()
        pr = layer.dataProvider()

        for i in range(items_cnt):
            item = root.child(i)

            if item.text(1) == 'String':
                list_attrs.append((item.text(0), QVariant.String, 'string', item.text(2), None))
                pr.addAttributes([QgsField(item.text(0), QVariant.String, 'string', int(item.text(2)))])
            if item.text(1) == 'Int':
                list_attrs.append((item.text(0), QVariant.Int, 'int', item.text(2), None))
                pr.addAttributes([QgsField(item.text(0), QVariant.Int, 'int', int(item.text(2)))])
            if item.text(1) == 'Double':
                list_attrs.append((item.text(0), QVariant.Double, 'double', item.text(2), item.text(3)))
                pr.addAttributes([QgsField(item.text(0), QVariant.Double, 'double', int(item.text(2)), int(item.text(3)))])
            if item.text(1) == 'Bool':
                list_attrs.append((item.text(0), QVariant.Bool, 'bool', None, None))
                pr.addAttributes([QgsField(item.text(0), QVariant.Bool)])
            if item.text(1) == 'Date':
                list_attrs.append((item.text(0), QVariant.Date, 'date', None, None))
                pr.addAttributes([QgsField(item.text(0), QVariant.Date)])

        layer.updateFields()
        QgsProject.instance().addMapLayer(layer)

        # Save file
        file_path = self.dlg_fact.mQgsFileWidget.filePath()
        lay = self.iface.activeLayer()
        if file_path != "":
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "ESRI Shapefile"
            options.layerName = lay.name()
            QgsVectorFileWriter.writeAsVectorFormatV3(lay, file_path + '/' + lay.name(), QgsCoordinateTransformContext(), options)
            vlayer = QgsVectorLayer(file_path + '/' + lay.name()+'.shp', lay.name(), "ogr")
            QgsProject.instance().addMapLayer(vlayer)
            QgsProject.instance().removeMapLayers([lay.id()])


    def create_fact_dlg(self):
        self.dlg_main.setEnabled(False)
        self.dlg_fact.setEnabled(True)
        self.dlg_fact.show()
        self.dlg_fact.comboBox.currentTextChanged.connect(self.fact_CB_changed)

    def fact_CB_changed(self):
        if self.dlg_fact.comboBox.currentIndex() == 0:
            self.dlg_fact.lineEdit_lenght.setText('10')
            self.dlg_fact.lineEdit_precissoin.setText('')
            self.dlg_fact.lineEdit_lenght.setEnabled(True)
            self.dlg_fact.lineEdit_precissoin.setEnabled(False)
        elif self.dlg_fact.comboBox.currentIndex() == 1:
            self.dlg_fact.lineEdit_lenght.setText('10')
            self.dlg_fact.lineEdit_precissoin.setText('')
            self.dlg_fact.lineEdit_lenght.setEnabled(True)
            self.dlg_fact.lineEdit_precissoin.setEnabled(False)
        elif self.dlg_fact.comboBox.currentIndex() == 2:
            self.dlg_fact.lineEdit_lenght.setText('10')
            self.dlg_fact.lineEdit_precissoin.setText('3')
            self.dlg_fact.lineEdit_lenght.setEnabled(True)
            self.dlg_fact.lineEdit_precissoin.setEnabled(True)
        elif self.dlg_fact.comboBox.currentIndex() == 3:
            self.dlg_fact.lineEdit_lenght.setText('')
            self.dlg_fact.lineEdit_precissoin.setText('')
            self.dlg_fact.lineEdit_lenght.setEnabled(False)
            self.dlg_fact.lineEdit_precissoin.setEnabled(False)
        elif self.dlg_fact.comboBox.currentIndex() == 4:
            self.dlg_fact.lineEdit_lenght.setText('')
            self.dlg_fact.lineEdit_precissoin.setText('')
            self.dlg_fact.lineEdit_lenght.setEnabled(False)
            self.dlg_fact.lineEdit_precissoin.setEnabled(False)

    def buffer_dlg(self):
        self.dlg_main.setEnabled(False)
        self.dlg_buffer.setEnabled(True)
        self.dlg_buffer.mMapLayerComboBox.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.dlg_buffer.show()
        self.dlg_buffer.btn_ok.clicked.connect(self.buffers_create)

    def buffers_create(self):
        width = float(self.dlg_buffer.lineEdit_width.text())
        height = float(self.dlg_buffer.lineEdit_height.text())
        rotation = float(self.dlg_buffer.lineEdit_rotation.text())
        segments = int(self.dlg_buffer.lineEdit_segments.text())

        layer = self.dlg_buffer.mMapLayerComboBox.currentLayer()

        if self.dlg_buffer.checkBox.isChecked():
            sfo = True
        else:
            sfo = False

        parameter = {'INPUT': QgsProcessingFeatureSourceDefinition(layer.id(),selectedFeaturesOnly=sfo,featureLimit=-1,geometryCheck=QgsFeatureRequest.GeometryNoCheck)
        ,'SHAPE':2,'WIDTH':width,'HEIGHT':height,'ROTATION':rotation,'SEGMENTS':segments,'OUTPUT':'TEMPORARY_OUTPUT'}
        result = processing.run('native:rectanglesovalsdiamonds', parameter)['OUTPUT']
        result.setName('Buffer_zone')
        QgsProject.instance().addMapLayer(result)

        pr = layer.dataProvider()
        path = pr.dataSourceUri()
        print(path)

        directory, nameFile = os.path.split(path)
        print(directory, nameFile)

        if path.find('memory?') == -1:
            print('unfind')
            # Save file
            lay = self.iface.activeLayer()
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "ESRI Shapefile"
            options.layerName = lay.name()
            QgsVectorFileWriter.writeAsVectorFormatV3(lay, directory + '/' + lay.name(), QgsCoordinateTransformContext(), options)
            vlayer = QgsVectorLayer(directory + '/' + lay.name()+'.shp', lay.name(), "ogr")
            QgsProject.instance().addMapLayer(vlayer)
            QgsProject.instance().removeMapLayers([lay.id()])


    def tree_rec(self, child, all_gr, node):
        gr = []

        for item in child.children():
            
            childNode = QtWidgets.QTreeWidgetItem([item.name()]) 

            if item.__class__.__name__ == 'QgsLayerTreeGroup':
                childNode.setText(0, item.name())
                childNode.setIcon(0, QIcon(self.plugin_dir + "/folder_icon.png"))
                self.tree_rec(item, gr, childNode)

            elif item.__class__.__name__ == 'QgsLayerTreeLayer':
                childNode.setText(0, item.name())
                childNode.setText(1, item.layer().id())

                layer = item.layer()

                gr.append(item)

                if layer.__class__.__name__ == 'QgsVectorLayer':

                    renderer = layer.renderer()

                    try:
                        symbol = renderer.symbol()
                    except:
                        legendSymbolItems = renderer.legendSymbolItems()
                        legendSymbolItem = legendSymbolItems[0]
                        symbol = legendSymbolItem.symbol()

                    image = symbol.asImage(QSize(16, 16))
                    pixmap = QPixmap.fromImage(image)
                    icon = QIcon(pixmap)
                    childNode.setIcon(0, icon)

                else:
                    childNode.setIcon(0, QIcon(self.plugin_dir + "/raster_icon.png"))

            node.addChild(childNode)
            childNode.setCheckState(0, QtCore.Qt.Unchecked)

        all_gr.append(gr)  



    def create_child_proj_dlg(self):
        self.dlg_main.setEnabled(False)
        self.dlg_child_project.setEnabled(True)

        # Tree widget 
        self.tree = self.dlg_child_project.treeWidget
        self.tree.clear()
        self.tree.setSelectionMode(3)
        self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(['Слои', 'id'])
        self.tree.setColumnWidth(0, 300)

        all_gr = []

        root = QgsProject.instance().layerTreeRoot()

        for child in root.children():
            
            if child.__class__.__name__ == 'QgsLayerTreeGroup':

                node = QtWidgets.QTreeWidgetItem(self.tree) 

                self.tree.addTopLevelItem(node)
                node.setText(0, child.name())
                node.setCheckState(0, QtCore.Qt.Unchecked)
                node.setIcon(0, QIcon(self.plugin_dir + "/folder_icon.png"))

                self.tree_rec(child, all_gr, node)

            elif child.__class__.__name__ == 'QgsLayerTreeLayer':

                all_gr.append(child)

                layer = child.layer()
                node = QtWidgets.QTreeWidgetItem(self.tree) 
                self.tree.addTopLevelItem(node)
                node.setText(0, layer.name())
                node.setText(1, layer.id())
                node.setCheckState(0, QtCore.Qt.Unchecked)

                if layer.__class__.__name__ == 'QgsVectorLayer':
                    renderer = layer.renderer()
                    try:
                        symbol = renderer.symbol()
                    except:
                        legendSymbolItems = renderer.legendSymbolItems()
                        legendSymbolItem = legendSymbolItems[0]
                        symbol = legendSymbolItem.symbol()
    
                    image = symbol.asImage(QSize(16, 16))
                    pixmap = QPixmap.fromImage(image)
                    icon = QIcon(pixmap)
                    node.setIcon(0, icon)
                else:
                    node.setIcon(0, QIcon(self.plugin_dir + "/raster_icon.png"))

        self.all_gr = all_gr

        self.dlg_child_project.show()



    def create_child_proj(self):

        current_date = datetime.today().strftime('%d-%m-%Y')
        folder_path = self.dlg_child_project.mQgsFileWidget.filePath() + '/Project_' + current_date

        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        else:
            print(f"Папка `{folder_path}` уже существует!")
            return


        new_layers = []

        for item in self.tree.findItems("", Qt.MatchContains | Qt.MatchContains): # MatchRecursive

            if item.text(1) == '': # Group
                #print(item.text(0), 'Group')
                path = item.text(0)
                self.new_tree_rec(item, new_layers, path, folder_path)
            elif item.text(1) != '' and item.checkState(0) == 2:
                #print(item.text(0), 'Layer')
                new_layers.append(path)

        print(new_layers)

        
        #gr_layers.append(layers)

        return

        crs = self.iface.mapCanvas().mapSettings().destinationCrs()

        # Open new proj
        proj_fn = QgsProject.instance().fileName()
        self.iface.newProject()

        QgsProject.instance().setCrs(crs)

        for i, gr in enumerate(gr_layers):

            if len(gr) != 0:
                root = QgsProject.instance().layerTreeRoot()
                group = root.addGroup(gr_names[i][1:-2])
                

                for j, layer in enumerate(gr):
                    new_layer = QgsVectorLayer(folder_path + layer[3] + layer[1], layer[0], "ogr")
                    QgsProject.instance().addMapLayer(new_layer, False)
                    group.addLayer(new_layer) 
                    new_layer.loadNamedStyle(layer[2])

        QgsProject.instance().write(folder_path + '/new.qgz') 
        QgsProject.instance().clear()
        QgsProject.instance().read(proj_fn)


    def new_tree_rec(self, item, new_layers, path, folder_path):

        childCount = item.childCount()
        gr = []


        for i in range(childCount):
            child = item.child(i)

            path0 = path + '/' + str(child.text(0))

            if child.text(1) == '': # Group
                self.new_tree_rec(child, gr, path0, folder_path)

            if child.checkState(0) == 2: # Cheked Layer
                gr.append(path0)

                path_to_group = folder_path + '/' + path

                if not os.path.exists(path_to_group):
                    os.makedirs(path_to_group)

                self.save_layers(path_to_group, child.text(1))

        new_layers.append(gr)



    def save_layers(self, path_to_group, layer_id):

        layers = []

        layer = QgsProject.instance().layerTreeRoot().findLayer(layer_id).layer()

        shp_path = layer.source()
        file_name = os.path.basename(shp_path)
        fn = os.path.splitext(file_name)[0]
        fns = (file_name, fn+'.shx', fn+'.dbf', fn+'.prj', fn+'.cpg', fn+'.qmd')
        shp_name = shp_path[:-4]
        fact_src = (shp_path, shp_name+'.shx', shp_name+'.dbf', shp_name+'.prj', shp_name+'.cpg', shp_name+'.qmd')
                
        path_style = path_to_group + '/' + layer.name() + '.qml'
        layer.saveNamedStyle(path_style)

        layers.append((layer.name(), file_name, path_style, path_to_group))

        # Shp files
        for i in range(6):
            try:
                shutil.copyfile(fact_src[i], path_to_group + '/' + fns[i])
            except FileNotFoundError:
                pass

        return

        return layers



                
    def create_add_layers_ved_dlg(self):
        self.dlg_main.setEnabled(False)
        self.dlg_add_layers_ved.setEnabled(True)

        root = QgsProject.instance().layerTreeRoot()

        self.dlg_add_layers_ved.show()


    def create_add_points_ved_dlg(self):
        self.dlg_main.setEnabled(False)
        self.dlg_add_points_ved.setEnabled(True)

        groupBox = self.dlg_add_points_ved.groupBox
        root = QgsProject.instance().layerTreeRoot()

        # Создаем основной вертикальный layout
        vbox = QVBoxLayout()

        ved = False


        for child in root.children():
            if child.__class__.__name__ == 'QgsLayerTreeGroup':
                if child.name() == 'Исполнители':
                    ved = True
                    layer_ved_count = len(child.children())

                    # Создаем строки с QPushButton для каждого слоя с исполнителем
                    for i, layer_ved in enumerate(child.children()):

                        layer = layer_ved.layer()
                        if layer.geometryType() == QgsWkbTypes.PointGeometry:

                            hbox = QHBoxLayout()  # Горизонтальный layout для одной строки
                            
                            renderer = layer.renderer()
                        
                            symbol = renderer.symbol()
                            image = symbol.asImage(QSize(16, 16))
                            pixmap = QPixmap.fromImage(image)
    
                            label_icon = QLabel('')
                            label_icon.setPixmap(pixmap)
    
                            label_layer = QLabel(layer_ved.layer().name())
    
                            button1 = QPushButton('Добавить точки')
                            button2 = QPushButton('Удалить точки')
                
                            # Подключаем кнопку к методу
                            button1.clicked.connect(lambda x, arg=layer: self.on_button1_click(arg))
                            button2.clicked.connect(lambda x, arg=layer: self.on_button2_click(arg))
                
                            # Добавляем элементы в горизонтальный layout
                            hbox.addWidget(label_icon)
                            hbox.addWidget(label_layer)
                            hbox.addWidget(button1)
                            hbox.addWidget(button2)
                
                            # Добавляем горизонтальный layout в вертикальный
                            vbox.addLayout(hbox)
    
                            # Добавляем разделительную линию
                            line = QFrame()
                            line.setFrameShape(QFrame.HLine)  # Устанавливаем форму линии
                            line.setFrameShadow(QFrame.Sunken)  # Устанавливаем тень для линии
                            vbox.addWidget(line)  # Добавляем линию в вертикальный layout

        if ved == False:
            print('Не найдена группа слоев Исполнители')
            self.dlg_main.setEnabled(True)
            return
            
        # Устанавливаем вертикальный layout в QGroupBox
        groupBox.setLayout(vbox)
        self.dlg_add_points_ved.show()


    def on_button1_click(self, target_layer):
        input_layer = self.iface.activeLayer()

        if input_layer == target_layer:
            print('the same layers')
            return

        if self.dlg_add_points_ved.checkBox.isChecked():
            features_in = input_layer.selectedFeatures()
        else:
            features_in = input_layer.getFeatures()

        features_out = target_layer.getFeatures()

        fields_in_cnt = input_layer.fields().count()
        fields_out_cnt = target_layer.fields().count()
        
        pr = target_layer.dataProvider()
        fet = QgsFeature()

        for i, feature in enumerate(features_in):
            attrs = feature.attributes()
            geom = feature.geometry()
            xy = geom.asPoint()
            point = QgsPoint(xy)
            x, y = point.x(), point.y()

            fet.setGeometry(QgsPoint(x, y))
            fet.setAttributes(attrs[:fields_out_cnt])
            pr.addFeatures([fet])

        target_layer.updateExtents()
        target_layer.updateFields()
        self.iface.setActiveLayer(target_layer) 
        self.iface.setActiveLayer(input_layer) 
        self.iface.mapCanvas().zoomOut()
        self.iface.mapCanvas().zoomIn()
        self.iface.mapCanvas().refreshAllLayers()


    def on_button2_click(self, target_layer):
        # Начинаем редактирование слоя
        target_layer.startEditing()

        if self.dlg_add_points_ved.checkBox.isChecked():
            # Получаем выделенные точки
            selected_features = target_layer.selectedFeatures()
        
            # Удаляем выделенные точки
            target_layer.deleteFeatures([feature.id() for feature in selected_features])
        else:
            features = target_layer.getFeatures()
            target_layer.deleteFeatures([feature.id() for feature in features])

        # Завершаем редактирование и сохраняем изменения
        target_layer.commitChanges()



    #----------------------------------------------------------------------

    def run(self):
        self.dlg_main = main_dialog(self.iface, parent = self.iface.mainWindow())
        self.dlg_main.show()
        self.dlg_fact = fact_create_dialog(self.iface, parent = self.dlg_main)
        self.dlg_fact.lineEdit_precissoin.setEnabled(False)
        self.dlg_buffer = buffer_dialog(self.iface, parent = self.dlg_main)


        self.dlg_child_project = child_project_dialog(self.iface, parent = self.dlg_main)
        self.dlg_child_project.btn_create_child_proj.clicked.connect(self.create_child_proj)
        self.dlg_add_points_ved = add_points_ved_dialog(self.iface, parent = self.dlg_main)
        self.dlg_add_layers_ved = add_layers_ved_dialog(self.iface, parent = self.dlg_main)

        self.tree = self.dlg_fact.treeWidget
        self.tree.setSelectionMode(3)
        self.tree.setColumnCount(4)
        self.tree.setHeaderLabels(['Имя', 'Тип', 'Размер', 'Точность'])

        # Buttons click
        self.dlg_main.btn_create_fact.clicked.connect(self.create_fact_dlg)
        self.dlg_main.btn_buffer_elipse.clicked.connect(self.buffer_dlg)
        self.dlg_main.btn_child_project.clicked.connect(self.create_child_proj_dlg)
        self.dlg_main.btn_add_points_ved.clicked.connect(self.create_add_points_ved_dlg)
        self.dlg_main.btn_add_layers_ved.clicked.connect(self.create_add_layers_ved_dlg)


        self.dlg_fact.btn_add_attr.clicked.connect(self.add_attr_to_tree)
        self.dlg_fact.btn_remove_attr.clicked.connect(self.remove_attr_from_tree)
        self.dlg_fact.btn_create_facts.clicked.connect(self.create_facts)
        self.dlg_fact.btn_save_list_fields.clicked.connect(self.save_list_fields)
        self.dlg_fact.btn_load_list_fields.clicked.connect(self.load_list_fields)

        self.toolbar.setEnabled(False)



# Dialog windows
FORM_CLASS_main, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'main.ui'))
FORM_CLASS_fact, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'fact.ui'))
FORM_CLASS_buffer, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'buffer.ui'))
FORM_CLASS_child_project, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'child_project.ui'))
FORM_CLASS_add_points_ved, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'add_points_ved.ui'))
FORM_CLASS_add_layers_ved, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'add_layers_ved.ui'))

class main_dialog(QtWidgets.QDialog, FORM_CLASS_main):
    def __init__(self, iface, parent):
        super(main_dialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

    def closeEvent(self, event):
        for child in self.iface.mainWindow().children():
            name_tb = child.__class__.__name__
            if name_tb == 'QToolBar':
                if child.objectName() == 'GIS Project Updater':
                    this_plugin = child

        this_plugin.setEnabled(True)

class fact_create_dialog(QtWidgets.QDialog, FORM_CLASS_fact):
    def __init__(self, iface, parent):
        super(fact_create_dialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

        self.parent = parent

    def closeEvent(self, event):
        self.parent.setEnabled(True)

class buffer_dialog(QtWidgets.QDialog, FORM_CLASS_buffer):
    def __init__(self, iface, parent):
        super(buffer_dialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

        self.parent = parent

    def closeEvent(self, event):
        self.parent.setEnabled(True)


class child_project_dialog(QtWidgets.QDialog, FORM_CLASS_child_project):
    def __init__(self, iface, parent):
        super(child_project_dialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

        self.parent = parent

    def closeEvent(self, event):
        self.parent.setEnabled(True)

class add_points_ved_dialog(QtWidgets.QDialog, FORM_CLASS_add_points_ved):
    def __init__(self, iface, parent):
        super(add_points_ved_dialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

        self.parent = parent

    def closeEvent(self, event):
        self.parent.setEnabled(True)

class add_layers_ved_dialog(QtWidgets.QDialog, FORM_CLASS_add_layers_ved):
    def __init__(self, iface, parent):
        super(add_layers_ved_dialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

        self.parent = parent

    def closeEvent(self, event):
        self.parent.setEnabled(True)