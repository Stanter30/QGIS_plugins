# -*- coding: utf-8 -*-
"""
                             -------------------
        begin                : 2024-11-12
        git sha              : $Format:%H$
        copyright            : (C) 2024 by S.A.Tereshkin
        email                : stanter30@gmail.com
 ***************************************************************************/
"""

import os

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'UAV_Spec_Process_dialog_base.ui'))


class UAV_Spec_ProcessDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(UAV_Spec_ProcessDialog, self).__init__(parent)
        self.setupUi(self)
