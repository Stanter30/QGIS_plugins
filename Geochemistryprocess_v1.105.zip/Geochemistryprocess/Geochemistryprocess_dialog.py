# -*- coding: utf-8 -*-
"""
/***************************************************************************
 GeochemistryprocessDialog
                                 A QGIS plugin
 Geochemistryprocess
                             -------------------
        begin                : 2023-04-21
        git sha              : $Format:%H$
        copyright            : (C) 2023 by S. Tereshkin
        email                : stanter30@gmail.com
 ***************************************************************************/
"""

import os
import sys

from qgis.PyQt import uic, QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt
from PyQt5.Qt import *
from PyQt5.QtWidgets import*
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg, NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure

# This loads .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS_drifting, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'dreif.ui'))
FORM_CLASS_layout, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'layout.ui'))
FORM_CLASS_statistics, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'statistics.ui'))


class driftingDialog(QtWidgets.QDialog, FORM_CLASS_drifting):
    def __init__(self, parent=None):
        """Constructor."""
        super(driftingDialog, self).__init__(parent)
        self.setupUi(self)
       
    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_C and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            copied_cells = sorted(self.tableWidget.selectedIndexes())
            copy_text = ""
            max_column = copied_cells[-1].column()
            for c in copied_cells:
                if self.tableWidget.item(c.row(), c.column()) == None:
                    continue
                copy_text += self.tableWidget.item(c.row(), c.column()).text()
                if c.column() == max_column:
                    copy_text += "\n"
                else:
                    copy_text += "\t"
                    
            QApplication.clipboard().setText(copy_text)


class statisticsDialog(QtWidgets.QDialog, FORM_CLASS_statistics):
    def __init__(self, parent=None):
        super(statisticsDialog, self).__init__(parent)
        self.setupUi(self)


class layoutDialog(QtWidgets.QDialog, FORM_CLASS_layout):
    def __init__(self, parent=None):
        super(layoutDialog, self).__init__(parent)
        self.setupUi(self)
