# -*- coding: utf-8 -*-
def classFactory(iface):
    from .GIS_Project_Updater import GIS_Project_Updater
    return GIS_Project_Updater(iface)

