# -*- coding: utf-8 -*-
"""
/***************************************************************************
 UAV_Mag_Process
                                 A QGIS plugin
                              -------------------
        begin                : 2023-09-15
        git sha              : $Format:%H$
        copyright            : (C) 2023 by Tereshkin S.A.
        email                : Stanter30@gmail.com
 ***************************************************************************/
"""
import sys
import csv
import copy
import numpy as np
import pandas as pd
from itertools import compress
import scipy.interpolate as interp
from scipy import stats
import matplotlib.pyplot as plt
import time
from datetime import datetime
import os.path
import math
import processing
from osgeo import osr, gdal, ogr
from qgis.analysis import *
from qgis.core import *
from qgis.gui import *
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .UAVProcess_dialog import UAVProcessDialog

class Message:

    def msg(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Неправильный источник данных")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

    def info(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Информация")
        mbox.setIcon(QMessageBox.Information)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

mbox = Message().msg()
mboxi = Message().info()


class UAVProcess:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor."""
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'UAVProcess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&UAV_Mag_Process')
        self.toolbar = self.iface.addToolBar(u'UAV_Mag_Process')
        self.toolbar.setObjectName(u'UAV_Mag_Process')

        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message): return QCoreApplication.translate('UAV_Mag_Process', message)

    def tool_UAV(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/UAVProcess/icon.png'
        self.tool_UAV(icon_path, text=self.tr(u'UAV_Mag_Process'), callback=self.run_UAV, parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&UAV_Mag_Process'), action)
            self.iface.removeToolBarIcon(action)

    def rejectDlg(self):
        """Close dialog."""
        self.dlg.close()

    def progress(self, i, f, proc_freq, proc_text):
        """Progress bar value."""
        if i % proc_freq == 0:
            self.dlg_UAV.progressBar.setValue(int((i/f)*100))
            self.dlg_UAV.progressBar.setFormat(proc_text + str(int((i/f)*100)) + ' %')

            QApplication.processEvents()

    def timeForm(self, Time, var):
        d1 = self.dlg_UAV.d1_CB.currentText()
        d2 = self.dlg_UAV.d2_CB.currentText()
        d3 = self.dlg_UAV.d3_CB.currentText()
        t1 = self.dlg_UAV.t1_CB.currentText()
        t2 = self.dlg_UAV.t2_CB.currentText()
        t3 = self.dlg_UAV.t3_CB.currentText()
        t4 = self.dlg_UAV.t4_CB.currentText()

        d1_var = self.dlg_UAV.d1_var_CB.currentText()
        d2_var = self.dlg_UAV.d2_var_CB.currentText()
        d3_var = self.dlg_UAV.d3_var_CB.currentText()
        t1_var = self.dlg_UAV.t1_var_CB.currentText()
        t2_var = self.dlg_UAV.t2_var_CB.currentText()
        t3_var = self.dlg_UAV.t3_var_CB.currentText()
        t4_var = self.dlg_UAV.t4_var_CB.currentText()

        
        try:
            float(Time)
            test_float = True
        except ValueError:
            test_float = False

        if test_float == False:
            self.str_sep_var = ' '

            if var == 0:
                if Time.find('T') != -1:
                    self.str_sep = 'T'
                else:
                    self.str_sep = ' '
            else:
                if Time.find('T') != -1:
                    self.str_sep_var = 'T'
                else:
                    self.str_sep_var = ' '

            try:
                if Time[2].isdigit():
                    data_sep = Time[4]
                else:
                    data_sep = Time[2]
                    
                if data_sep == '.':
                    if var == 0:
                        self.time_form = d1 + '.' + d2 + '.' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                    else:
                        self.time_form_var = d1_var + '.' + d2_var + '.' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
                elif data_sep == '-':
                    if var == 0:
                        self.time_form = d1 + '-' + d2 + '-' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                    else:
                        self.time_form_var = d1_var + '-' + d2_var + '-' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
                elif data_sep == '/':
                    if var == 0:
                        self.time_form = d1 + '/' + d2 + '/' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                    else:
                        self.time_form_var = d1_var + '/' + d2_var + '/' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
                elif data_sep == ' ':
                    if var == 0:
                        self.time_form = d1 + ' ' + d2 + ' ' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                    else:
                        self.time_form_var = d1_var + ' ' + d2_var + ' ' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
                elif data_sep == '_':
                    if var == 0:
                        self.time_form = d1 + '_' + d2 + '_' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                    else:
                        self.time_form_var = d1_var + '_' + d2_var + '_' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
                elif data_sep == ',':
                    if var == 0:
                        self.time_form = d1 + ',' + d2 + ',' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                    else:
                        self.time_form_var = d1_var + ',' + d2_var + ',' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
            except:
                if var == 0:
                    mbox.setText('Формат времени для рядовых измерений не подходит')
                else:
                    mbox.setText('Формат времени для вариаций не подходит')
                mbox.show()
                return
        else:
            self.time_form = 'digit'


        print('Time Primer:', Time)
        print('Time Mag_Format:', self.time_form)
        print('Time Var_Format:', self.time_form_var)


        self.dlg_UAV.label_Mag_form.setStyleSheet("background:rgba(255, 255, 200, 255);") 
        self.dlg_UAV.label_Mag_form.setText(self.time_form)
        self.dlg_UAV.label_Mag_test.setStyleSheet("background:rgba(255, 255, 200, 255);") 
        self.dlg_UAV.label_Mag_test.setText(str(Time))


        if var == 1:
            self.dlg_UAV.label_Var_form.setStyleSheet("background:rgba(255, 255, 200, 255);") 
            self.dlg_UAV.label_Var_form.setText(self.time_form_var)
            self.dlg_UAV.label_Var_test.setStyleSheet("background:rgba(255, 255, 200, 255);") 
            self.dlg_UAV.label_Var_test.setText(Time)



    #--------------------------------------------------------------------------
    # UAV_Mag_Process functions
    #--------------------------------------------------------------------------

    def run_process(self, data, proc, tic):
        try:
            layer = self.vlayer
        except AttributeError:
            mbox.setText("Нужно загрузить слой в Load Data")
            mbox.show()
            return
            
        if self.dlg_UAV.process_list.item(0).checkState() == Qt.Checked: # Variations
            proc = 1
            tic = time.perf_counter()
            UAVProcess.variations(self, 0, proc, tic)
        elif self.dlg_UAV.process_list.item(0).checkState() != Qt.Checked and self.dlg_UAV.process_list.item(1).checkState() == Qt.Checked:
            proc = 2
            tic = time.perf_counter()
            UAVProcess.cut_points(self, self.data, proc, tic)
        elif self.dlg_UAV.process_list.item(0).checkState() != Qt.Checked and self.dlg_UAV.process_list.item(1).checkState() != Qt.Checked and self.dlg_UAV.process_list.item(2).checkState() == Qt.Checked:
            proc = 3
            rect = 0
            tic = time.perf_counter()
            UAVProcess.add_n_profile(self, self.data, proc, tic, rect)
        return



    def load_var_files(self, file, div, n_file):
        print('LOAD_VAR_FILES')

        if n_file == 0:
            # Read var
            with open(file, 'r', encoding = 'Windows-1251') as f:
                lines = f.readlines()
                if lines[2].find('\t') != -1:
                    self.spliter = '\t'
                else:
                    self.spliter = ' '
                print(lines[2])
                self.words = lines[2].replace('\n', '').split(self.spliter)
                print('words', len(self.words), self.words)
                headers = lines[0].replace('\n', '').split(self.spliter)
                
                if len(self.words) == 1:
                    self.spliter = '\t'
                    self.words = lines[2].replace('\n', '').split(self.spliter)
                    headers = lines[0].replace('\n', '').split(self.spliter)
                if len(self.words) == 1:
                    self.spliter = ','
                    self.words = lines[2].replace('\n', '').split(self.spliter)
                    headers = lines[0].replace('\n', '').split(self.spliter)
                if len(self.words) == 1:
                    self.spliter = ';'
                    self.words = lines[2].replace('\n', '').split(self.spliter)
                    headers = lines[0].replace('\n', '').split(self.spliter)

                print('split', self.spliter)
    
            self.dlg = QDialog()
            self.dlg.setWindowTitle("Variations fields selection")
    
            label, label1 = QtWidgets.QLabel(), QtWidgets.QLabel()
            label.setText('FIELD')
            label.setAlignment(Qt.AlignCenter)
            label.setFont(QFont('MS Shell Dlg 2', 10))
            label1.setText('DATE/TIME')
            label1.setAlignment(Qt.AlignCenter)
            label1.setFont(QFont('MS Shell Dlg 2', 10))
    
    
            items, items1, items2 = QComboBox(), QComboBox(), QComboBox()
    
            items.addItem('')
            items1.addItem('')
            items2.addItem('')
    
            for head in headers:
                items.addItem(head)
                items1.addItem(head)
                items2.addItem(head)
    
            gridLayout = QGridLayout()
            gridLayout.setVerticalSpacing(10)
            gridLayout.setHorizontalSpacing(30)
            gridLayout.addWidget(label, 0, 0)
            gridLayout.addWidget(items, 1, 0)
            gridLayout.addWidget(label1, 0, 1)
            gridLayout.addWidget(items1, 1, 1)
            gridLayout.addWidget(items2, 2, 1)
    
            for i, val in enumerate(headers):
                if val == 'T' or val == 'FIELD' or val == 'Field':
                    items.setCurrentIndex(i+1)
                if val == 'TIME' or val == 'Time' or val == 'Datetime' or val == 'DATETIME' or val == 'Date':
                    items1.setCurrentIndex(i+1)
    
    
            self.items_all = [items, items1, items2]
    
            btnBox = QDialogButtonBox()
            btnBox.setStandardButtons(QDialogButtonBox.Ok)
            btnBox.accepted.connect(lambda: self.ret_var(file, self.items_all, self.words, self.spliter, div))
            btnBox.rejected.connect(self.rejectDlg)
            gridLayout.addWidget(btnBox, 2, 3)
    
            self.dlg.setLayout(gridLayout)
            self.dlg.exec_()
        else:
            self.ret_var(file, self.items_all, self.words, self.spliter, div)



    def ret_var(self, file, items_all, words, spliter, div):
        print('ret_var')
        self.dlg.close()

        if items_all[1].currentIndex() != 0 and items_all[2].currentIndex() == 0:
            Time = words[items_all[1].currentIndex()-1]
            t = 1
        elif items_all[1].currentIndex() != 0 and items_all[2].currentIndex() != 0:
            Time = words[items_all[1].currentIndex()-1] + ' ' + words[items_all[2].currentIndex()-1]
            t = 2
        elif items_all[1].currentIndex() == 0 and items_all[2].currentIndex() == 0:
            Time = None
            t = 0


        if t != 0:
            UAVProcess.timeForm(self, Time, var=1)

        attrs = []
        c = -1
        for i, f in enumerate(items_all):
            attrs.append([f.currentIndex(), f.currentText()])

        min_var0 = int(self.dlg_UAV.var_min.text())
        max_var0 = int(self.dlg_UAV.var_max.text())


        # Read var
        with open(file, 'r', encoding = 'Windows-1251') as f:
            lines = f.readlines()
                    
            for i in range(len(lines)):
                if lines[i][0] != ';' and len(lines[i]) > 1 and i > 0:
                    words = lines[i].replace('\n', '').split(spliter)

                    attrs_list = []

                    if items_all[0].currentIndex() != 0:
                        fild = float(words[attrs[0][0]-1])/div

                        if min_var0 < fild < max_var0:
                            attrs_list.append(fild)


                    if t == 1:
                        attrs_list.append(words[attrs[1][0]-1])
                    elif t == 2:
                        time_add = words[attrs[1][0]-1] + ' ' + words[attrs[2][0]-1]
                        attrs_list.append(time_add)

                    if len(attrs_list) == 2:
                        self.var_data.append(attrs_list)

        print('len', len(self.var_data))
        if len(self.var_data) < 5:
            mbox.setText("Вариации не попали в указанные диапазоны")
            mbox.show()
            return

        print('VAR_NEW')
        print(self.var_data[-2])
        print(self.var_data[-1])

        

    def load_files(self):
        file_path = self.dlg_UAV.mQgs_open_files.filePath()

        if len(file_path) == 0:
            mbox.setText("Нужно выбрать файлы с данными")
            mbox.show()
            return

        file_paths = file_path.rsplit('"')
        for i in range(len(file_paths), -1, -1):
            if i % 2 == 0:
                del file_paths[i]
        file_paths = [file_path] if len(file_paths) == 0 else file_paths

        if len(file_paths[0]) == 0:
            return

        data = []

        for file in file_paths:
            # Read var
            if file.endswith(".txt") or file.endswith(".TXT"):
                with open(file, 'r', encoding = 'Windows-1251') as file:
                    lines = file.readlines()

                    spliter = ' '
                    words = lines[6].replace('\n', '').split(spliter)
                    headers = lines[0].replace('\n', '').split(spliter)

                    if len(headers) == 1:
                        spliter = '\t'
                        words = lines[6].replace('\n', '').split(spliter)
                        headers = lines[0].replace('\n', '').split(spliter)

                    if len(headers) == 1:
                        spliter = ','
                        words = lines[6].replace('\n', '').split(spliter)
                        headers = lines[0].replace('\n', '').split(spliter)

                    if len(headers) == 1:
                        spliter = ';'
                        words = lines[6].replace('\n', '').split(spliter)
                        headers = lines[0].replace('\n', '').split(spliter)



        self.dlg = QDialog()
        self.dlg.setWindowTitle("Fields selection")

        #self.dlg.resize(300, 200)

        label, label3 = QtWidgets.QLabel(), QtWidgets.QLabel()
        label4, label5, label6 = QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel()
        label.setText('FIELD')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        label3.setText('DATE/TIME')
        label3.setAlignment(Qt.AlignCenter)
        label3.setFont(QFont('MS Shell Dlg 2', 10))
        label4.setText('LAT')
        label4.setAlignment(Qt.AlignCenter)
        label4.setFont(QFont('MS Shell Dlg 2', 10))
        label5.setText('LON')
        label5.setAlignment(Qt.AlignCenter)
        label5.setFont(QFont('MS Shell Dlg 2', 10))
        label6.setText('ALT')
        label6.setAlignment(Qt.AlignCenter)
        label6.setFont(QFont('MS Shell Dlg 2', 10))


        items, items3 = QComboBox(), QComboBox()
        items4, items5, items6, items7 = QComboBox(), QComboBox(), QComboBox(), QComboBox()

        items.addItem('')
        items3.addItem('')
        items4.addItem('')
        items5.addItem('')
        items6.addItem('')
        items7.addItem('')

        for head in headers:
            items.addItem(head)
            items3.addItem(head)
            items4.addItem(head)
            items5.addItem(head)
            items6.addItem(head)
            items7.addItem(head)

        gridLayout = QGridLayout()
        gridLayout.setVerticalSpacing(10)
        gridLayout.setHorizontalSpacing(30)
        gridLayout.addWidget(label, 0, 0)
        gridLayout.addWidget(items, 1, 0)
        gridLayout.addWidget(label3, 0, 3)
        gridLayout.addWidget(items3, 1, 3)
        gridLayout.addWidget(label4, 0, 4)
        gridLayout.addWidget(items4, 1, 4)
        gridLayout.addWidget(label5, 0, 5)
        gridLayout.addWidget(items5, 1, 5)
        gridLayout.addWidget(label6, 0, 6)
        gridLayout.addWidget(items6, 1, 6)
        gridLayout.addWidget(items7, 2, 3)


        projection = QgsProjectionSelectionWidget()
        crs = QgsCoordinateReferenceSystem('EPSG:4326')
        projection.setCrs(crs)
        gridLayout.addWidget(projection, 2, 4, 1, 2)  # (p, row, pos_col, height, width)

        for i, val in enumerate(headers):
            if val == 'T' or val == 'FIELD' or val == 'Field':
                items.setCurrentIndex(i+1)
            if val == 'TIME' or val == 'Time' or val == 'time' or val == 'DATATIME':
                items3.setCurrentIndex(i+1)
            if val == 'LAT' or val == 'Lat' or val == 'lat':
                items4.setCurrentIndex(i+1)
            if val == 'LON' or val == 'Lon' or val == 'lon' or val == 'lng':
                items5.setCurrentIndex(i+1)
            if val == 'ALT' or val == 'Alt' or val == 'alt' or val == 'elev' or val == 'ELEV' or val == 'Elev':
                items6.setCurrentIndex(i+1)


        items_all = [items, items3, items4, items5, items6, items7]

        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(lambda: self.load_files_OK(file_paths, items_all, lines, spliter, words, projection))
        btnBox.rejected.connect(self.rejectDlg)
        gridLayout.addWidget(btnBox, 2, 6)

        self.dlg.setLayout(gridLayout)
        self.dlg.exec_()



    def load_files_OK(self, file_paths, items_all, lines, spliter, words, projection):
        self.dlg.close()
        tic = time.perf_counter()

        if items_all[1].currentIndex() != 0 and items_all[5].currentIndex() == 0:
            Time = words[items_all[1].currentIndex()-1]
            t = 1
        elif items_all[1].currentIndex() != 0 and items_all[5].currentIndex() != 0:
            Time = words[items_all[1].currentIndex()-1] + ' ' + words[items_all[5].currentIndex()-1]
            t = 2
        elif items_all[1].currentIndex() == 0 and items_all[5].currentIndex() == 0:
            Time = None
            t = 0



        if t != 0:
            UAVProcess.timeForm(self, Time, var=0)

        types = [['FIELD', QVariant.Double, 'double', 8, 3], 
                ['TIME', QVariant.String], 
                ['LAT', QVariant.Double, 'double', 10, 7], 
                ['LON', QVariant.Double, 'double', 10, 7], 
                ['ALT', QVariant.Double, 'double', 7, 3], 
                ['TIME2', QVariant.String]]
        attrs = []
        c = -1
        for i, f in enumerate(items_all):
            attrs.append([f.currentIndex(), f.currentText(), types[i]])
            if f.currentIndex() != 0:
                c += 1
            if i == 2:
                y_index = c
            if i == 3:
                x_index = c
            if i == 1:
                time_index = c 


        data = []
        for j, file in enumerate(file_paths):
            # Read file
            if file.endswith(".txt") or file.endswith(".TXT"):
                with open(file, 'r', encoding = 'Windows-1251') as file:
                    lines = file.readlines()
                    
                    for i in range(len(lines)):
                        try:
                            if lines[i][0] != ';' and len(lines[i]) > 1 and i > 0:
                                words = lines[i].replace('\n', '').split(spliter)
    
                                attrs_list = []
    
                                if items_all[0].currentIndex() != 0:
                                    field_val = float(words[attrs[0][0]-1])
                                    if math.isnan(field_val):
                                        continue
                                    attrs_list.append(field_val)
    
                                if t == 1:
                                    attrs_list.append(words[attrs[1][0]-1])
                                elif t == 2:
                                    time_add = words[attrs[1][0]-1] + ' ' + words[attrs[5][0]-1]
                                    attrs_list.append(time_add)
    
                                if items_all[2].currentIndex() != 0:
                                    lat = float(words[attrs[2][0]-1])
                                    if math.isnan(lat):
                                        continue
                                    attrs_list.append(lat)
                                if items_all[3].currentIndex() != 0:
                                    lon = float(words[attrs[3][0]-1])
                                    if math.isnan(lon):
                                        continue
                                    attrs_list.append(lon)
                                if items_all[4].currentIndex() != 0:
                                    alt = float(words[attrs[4][0]-1])
                                    if math.isnan(alt):
                                        continue
                                    attrs_list.append(alt)
    
                                data.append(attrs_list)

                        except:
                            # uncorrect line in file
                            pass

        del attrs[-1]

        # Shift time transpose
        time_shift = float(self.dlg_UAV.time_shift_mm.text())

        if time_shift != 0:
            shift = int(time_shift * 2)
            list_data = list(map(list, zip(*data)))
            
            if shift > 0: # T cut in end
                list_data[0] = list_data[0][:-shift] # Cut end
                list_data[1] = list_data[1][shift:]
                list_data[2] = list_data[2][shift:]
                list_data[3] = list_data[3][shift:]
                list_data[4] = list_data[4][shift:]
            else: # Time cut in end
                list_data[0] = list_data[0][-shift:] # Cut start
                list_data[1] = list_data[1][:shift]
                list_data[2] = list_data[2][:shift]
                list_data[3] = list_data[3][:shift]
                list_data[4] = list_data[4][:shift]

            data = list(map(list, zip(*list_data)))


        # Add points
        pnt = QgsVectorLayer('Point', 'Mag_files_'+str(time_shift), 'memory')

        pnt.setCrs(projection.crs())
        pr = pnt.dataProvider()
        att = []
        for i, attr in enumerate(attrs):
            if attr[0] != 0:
                Qgs_Field = QgsField(*attr[2])
                att.append(Qgs_Field)

        pr.addAttributes(att)
        pnt.updateFields()
        
        fets = []

        for i, val in enumerate(data):
            self.progress(i, len(data), 1000, 'Rendering: ')

            attrs = [j for j in val]
            fet = QgsFeature()
            fet.setGeometry(QgsPoint(val[x_index], val[y_index]))
            fet.setAttributes(attrs)
            fets.append(fet) 

        pr.addFeatures(fets)
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(data)))
        mboxi.show()
        mboxi.exec_()



    def merge_coord_time(self):
        tic = time.perf_counter()
        
        days = []
        root_gen = self.dlg_UAV.mQgsFileWidget_3.filePath()
        if len(root_gen) == 0:
            mbox.setText('Не найден путь к папке исходников')
            mbox.show()
            return
        time_shift = float(self.dlg_UAV.time_shift.text())

        if self.dlg_UAV.all_project.isChecked():
            # def days
            for root, dirs, files in os.walk(root_gen):
                (Directory, File) = os.path.split(root)
                for day in dirs:
                    days.append(root + '/' + day)
                break
        elif self.dlg_UAV.one_day.isChecked():
            # def day
            for root, dirs, files in os.walk(root_gen):
                days.append(root)
                day_index = root.rfind(r'\\'[:-1])
                day_pref = root[day_index+1:]
                break
        else:
            # def group
            for root, dirs, files in os.walk(root_gen):
                subfold = [root]
                sub_index = root.rfind(r'\\'[:-1])
                sub = root[sub_index+1:]
                slice_index = root.rfind(r'\\'[:-1])
                day = root[:slice_index]
                days.append(day)
                day_index = day.rfind(r'\\'[:-1])
                day_pref = day[day_index+1:]
                break
    
        # def num groups
        for root, dirs, files in os.walk(days[0]):
            gr_num = len(dirs)
            break
        if self.dlg_UAV.one_group.isChecked():
            gr_num = 1

        # def all files
        gr = []
        for grp in range(gr_num):
            gr_day = []
            for day in days:
                subfolders = [f.path for f in os.scandir(day) if f.is_dir()]
                if self.dlg_UAV.one_group.isChecked():
                    subfolders = subfold
                dir_gr = subfolders[grp]
                files_in_days = []
                for root, dirs, files in os.walk(dir_gr):
                    for file in files:
                        if file.find('.txt') != -1 or file.find('.gpx') != -1:
                            files_in_days.append(root + '/' + file)
                gr_day.append(files_in_days)
            gr.append(gr_day)

        # del empty dir
        for num_g, g in enumerate(gr):
            for i, day in enumerate(g):
                if len(day) < 2:
                    del gr[num_g][i]

        file_n = 0 # n file for def time format
        data_merge = []
        g = 0
        # Merge days
        for grp in gr:
            g += 1
            d = 0

            for day in grp:
                d += 1
                self.dlg_UAV.progressBar.setValue(int((100/len(grp))*d))
                self.dlg_UAV.progressBar.setFormat('Gr: ' + str(g) + '/' + str(len(gr)) + '    Day: ' + str(d) + '/' + str(len(grp)))
                QApplication.processEvents()
                data_mag = []
                data_gpx = []
                data_merge0 = []

                for file in day:
                    # Read mag
                    if file.endswith(".txt") or file.endswith(".TXT"):
                        with open(file, 'r', encoding = 'Windows-1251') as file:
                            lines = file.readlines()
                            if lines[0][0] != ';':
                                continue
                        file_n += 1

                        if file_n == 1:
                            words = lines[6].replace('\n','').split(' ')
                            Time = words[3] + ' ' + words[4]
                            UAVProcess.timeForm(self, Time, var=0)

                            try:
                                time_sec = datetime.strptime(Time, self.time_form).timestamp()
                            except ValueError:
                                mbox.setText("Формат времени не подходит (при merge pos 1)")
                                mbox.show()
                                return
                
                        for line in lines:
                            if line[0] != ';' and len(line) == 39:
                                words = line.replace('\n','').split(' ')
                                Time = words[3] + ' ' + words[4]
                                time_sec = datetime.strptime(Time, self.time_form).timestamp()
                                data0 = [float(words[0]) / 1000, int(words[1]), int(words[2]), Time, time_sec]
                                data_mag.append(data0)
        
                    # Read coord
                    elif file.endswith(".gpx"):
                        with open(file, 'r', encoding = 'Windows-1251') as file:
                            line = file.readline()
                            words = line.split('<trkpt ')
                            del words[0]
                            del words[-1]
        
                            for word in words:
                                lat_pos_start = word.find('lat="') + 5
                                lon_pos_start = word.find('lon="') + 5
                                ele_pos_start = word.find('ele>') + 4
                                time_pos_start = word.find('time>') + 5
                                lat_pos_end = word.find('" lon')
                                lon_pos_end = word.find('"><ele')
                                ele_pos_end = word.find('</ele>')
                                time_pos_end = word.find('+')
                                lat = float(word[lat_pos_start:lat_pos_end])
                                lon = float(word[lon_pos_start:lon_pos_end])
                                ele = float(word[ele_pos_start:ele_pos_end])
                                Time = word[time_pos_start:time_pos_end]
                                time_f = Time.replace('T', ' ')
                                try:
                                    time_sec = datetime.strptime(time_f, '%Y-%m-%d %H:%M:%S').timestamp()
                                except:
                                    continue
                                data0 = [lat, lon, ele, g, time_sec]
                                data_gpx.append(data0)
        
                data_mag.sort(key=lambda x: x[-1], reverse=False)
                data_gpx.sort(key=lambda x: x[-1], reverse=False)
        
                # Transpose
                list_gpx = list(map(list, zip(*data_gpx)))
                list_mag = list(map(list, zip(*data_mag)))
        
                # Cut bad data
                cut_data_gpx = []
                for i in range(1, len(list_gpx[0])):
                    if list_gpx[-1][i] != list_gpx[-1][i-1]:
                        cut_data_gpx.append(data_gpx[i])
        
                list_gpx = list(map(list, zip(*cut_data_gpx)))
                print('len_list_gpx', len(list_gpx[0]))

                #------------------------New interpolate------------------------------------
                a = [list_gpx[0], list_gpx[1], list_gpx[2], list_gpx[3], list_gpx[-1]] 
                gpx_list = [[], [], [], [], []]
          
                gpx_list[-1].append(a[-1][0])
                gpx_list[0].append(a[0][0])
                gpx_list[1].append(a[1][0])
                gpx_list[2].append(a[2][0])
                gpx_list[3].append(a[3][0])

                for i in range(1, len(a[-1])):
                    dist_time = int(a[-1][i] - a[-1][i-1])

                    if dist_time == 1:
                        gpx_list[-1].append(a[-1][i-1] + 0.5) # Time
                        gpx_list[-1].append(a[-1][i])
                        gpx_list[0].append(a[0][i-1] + (a[0][i] - a[0][i-1]) / 2) # lat
                        gpx_list[0].append(a[0][i])
                        gpx_list[1].append(a[1][i-1] + (a[1][i] - a[1][i-1]) / 2) # lon
                        gpx_list[1].append(a[1][i])
                        gpx_list[2].append(a[2][i-1] + (a[2][i] - a[2][i-1]) / 2) # alt
                        gpx_list[2].append(a[2][i])
                        gpx_list[3].append(a[3][i-1]) # gr
                        gpx_list[3].append(a[3][i])
                    else:
                        for j in range(dist_time):
                            if dist_time > 99999:
                                self.progress(i, dist_time, 1000, 'Gr: ' + str(g) + '/' + str(len(gr)) + '    Day: ' + str(d) + '/' + str(len(grp)) + ' Interpolate GPX: ')

                            gpx_list[-1].append(a[-1][i-1] + j+1 - 0.5)
                            gpx_list[-1].append(a[-1][i-1] + j+1)
                            gpx_list[0].append(a[0][i-1] + ((a[0][i] - a[0][i-1]) / (dist_time)) * (j+1) - ((a[0][i] - a[0][i-1]) / (dist_time * 2)))
                            gpx_list[0].append(a[0][i-1] + ((a[0][i] - a[0][i-1]) / (dist_time)) * (j+1))
                            gpx_list[1].append(a[1][i-1] + ((a[1][i] - a[1][i-1]) / (dist_time)) * (j+1) - ((a[1][i] - a[1][i-1]) / (dist_time * 2)))
                            gpx_list[1].append(a[1][i-1] + ((a[1][i] - a[1][i-1]) / (dist_time)) * (j+1))
                            gpx_list[2].append(a[2][i-1] + ((a[2][i] - a[2][i-1]) / (dist_time)) * (j+1) - ((a[2][i] - a[2][i-1]) / (dist_time * 2)))
                            gpx_list[2].append(a[2][i-1] + ((a[2][i] - a[2][i-1]) / (dist_time)) * (j+1))
                            gpx_list[3].append(a[3][i-1]) # gr
                            gpx_list[3].append(a[3][i])

                #-------------------------------------------------------------

                gpx_points = list(map(list, zip(*gpx_list)))
        
                print('gpx', gpx_list[-1][0], gpx_list[-1][-1], gpx_list[-1][-1] - gpx_list[-1][0])
                print('mag', list_mag[-1][0], list_mag[-1][-1], list_mag[-1][-1] - list_mag[-1][0])

                if list_mag[-1][0] < gpx_list[-1][0] and list_mag[-1][-1] < gpx_list[-1][0]:
                    mbox.setText('Gr' + ' ' + str(g) + ' Day '+ str(d) +'/'+ str(len(days)) + ' Не найдено совпадений времени (merge)')
                    mbox.show()
                    continue
                if list_mag[-1][0] > gpx_list[-1][-1] and list_mag[-1][-1] < gpx_list[-1][-1]:
                    mbox.setText('Gr' + ' ' + str(g) + ' Day '+ str(d) +'/'+ str(len(days)) + ' Не найдено совпадений времени (merge)')
                    mbox.show()
                    continue

                for i in range(len(list_mag[-1])):
                    try:
                        start_gpx = gpx_list[-1].index(list_mag[-1][i])
                        start_mag = i
                        break
                    except:
                        continue
    
                cnt_mag = -1
                cnt_gpx = -1
    
                # Merge coord with attrs
                for i in range(start_mag, len(list_mag[-1])):
                    cnt_mag += 1
                    cnt_gpx += 1
    
                    try:
                        if data_mag[start_mag + cnt_mag][-1] == gpx_points[start_gpx + cnt_gpx][-1]:
                            point = data_mag[start_mag + cnt_mag][:-1]
                            point.extend([*gpx_points[start_gpx + cnt_gpx]])
                            data_merge0.append(point)
                        else:
                            for j in range(start_mag + cnt_mag, len(list_mag[-1])):
                                try:
                                    start_gpx = gpx_list[-1].index(list_mag[-1][j])
                                    start_mag = j
                                    point = data_mag[start_mag][:-1]
                                    point.extend([*gpx_points[start_gpx]])
                                    data_merge0.append(point)
                                    cnt_mag = 0
                                    cnt_gpx = 0
                                    break
                                except:
                                    continue
                    except:
                        break
            
                if len(data_merge0) == 0:
                    mbox.setText(str(d) +'/'+ str(len(days)) + 'Не найдено совпадений времени (merge)')
                    mbox.show()
            
                print('len_merge', len(data_merge0))
                data_merge += data_merge0


        # Shift time transpose
        if time_shift != 0:
            shift = int(time_shift * 2)
            list_merge = list(map(list, zip(*data_merge)))
            
            if shift > 0: # T cut in end
                list_merge[0] = list_merge[0][:-shift] # Cut end
                list_merge[1] = list_merge[1][:-shift]
                list_merge[2] = list_merge[2][:-shift]
                list_merge[3] = list_merge[3][shift:]
                list_merge[4] = list_merge[4][shift:]
                list_merge[5] = list_merge[5][shift:]
                list_merge[6] = list_merge[6][shift:]
                list_merge[7] = list_merge[7][shift:]
                list_merge[8] = list_merge[8][shift:]
            else: # Time cut in end
                list_merge[0] = list_merge[0][-shift:] # Cut start
                list_merge[1] = list_merge[1][-shift:]
                list_merge[2] = list_merge[2][-shift:]
                list_merge[3] = list_merge[3][:shift]
                list_merge[4] = list_merge[4][:shift]
                list_merge[5] = list_merge[5][:shift]
                list_merge[6] = list_merge[6][:shift]
                list_merge[7] = list_merge[7][:shift]
                list_merge[8] = list_merge[8][:shift]

            data_merge = list(map(list, zip(*list_merge)))


        # Add points
        if self.dlg_UAV.all_project.isChecked():
            pnt = QgsVectorLayer('Point', File+'_'+str(time_shift), 'memory')
        if self.dlg_UAV.one_group.isChecked():
            pnt = QgsVectorLayer('Point', 'MAG_' + day_pref +'_'+ sub+'_'+str(time_shift), 'memory')
        if self.dlg_UAV.one_day.isChecked():
            pnt = QgsVectorLayer('Point', 'MAG_' + day_pref+'_'+str(time_shift), 'memory')

        crs = QgsCoordinateReferenceSystem()
        crs.createFromId(4326)
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        pr.addAttributes([
                          QgsField('T', QVariant.Double, 'double', 8, 3), 
                          QgsField('QMC', QVariant.Int),
                          QgsField('ST', QVariant.Int),
                          QgsField('TIME', QVariant.String),
                          QgsField('LAT', QVariant.Double, 'double', 10, 7),
                          QgsField('LON', QVariant.Double, 'double', 10, 7),
                          QgsField('ALT', QVariant.Double, 'double', 7, 3),
                          QgsField('GR', QVariant.Int)
                         ])
        pnt.updateFields()
        
        fets = []

        for i, val in enumerate(data_merge):
            self.progress(i, len(data_merge), 1000, 'Rendering: ')
            attrs = [val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7]]
            fet = QgsFeature()
            fet.setGeometry(QgsPoint(val[5], val[4]))
            fet.setAttributes(attrs)
            fets.append(fet) 

        pr.addFeatures(fets)
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(data_merge)))
        mboxi.show()
        mboxi.exec_()



    def read_var(self):
        file_path = self.dlg_UAV.mQgsFileWidget_4.filePath()

        if len(file_path) == 0:
            mbox.setText("Нужно выбрать файл с вариациями")
            mbox.show()
            return

        file_paths = file_path.rsplit('"')
        for i in range(len(file_paths), -1, -1):
            if i % 2 == 0:
                del file_paths[i]
        file_paths = [file_path] if len(file_paths) == 0 else file_paths

        if len(file_paths[0]) == 0:
            return

        data_var = []
        self.var_data = []


        if self.dlg_UAV.check_1000.isChecked():
            div = 1000
        else:
            div = 1

        # Read var
        for j, file in enumerate(file_paths):
            if file.endswith(".txt") or file.endswith(".TXT"):
                with open(file, 'r', encoding = 'Windows-1251') as f:
                    lines = f.readlines()

                if lines[0][0] == ';':    
                    words = lines[6].replace('\n','').split(' ')
                    Time = words[3] + ' ' + words[4]
                    UAVProcess.timeForm(self, Time, var=1)

                    try:
                        time_sec = datetime.strptime(Time, self.time_form_var).timestamp()
                    except ValueError:
                        mbox.setText("Формат времени не подходит (при чтении вариаций)")
                        mbox.show()
                        return
                
                    for i in range(len(lines)):
                        if lines[i][0] != ';' and len(lines[i]) > 1:
                            words = lines[i].replace('\n','').split(' ')
                            Time = words[3] + ' ' + words[4]
                            time_sec = datetime.strptime(Time, self.time_form_var).timestamp()
                            data0 = [float(words[0]) / div, time_sec]
                            data_var.append(data0)
                else:
                    self.load_var_files(file, div, j)
                    if self.check_div1000_var == 1:
                        return None


        for vd in self.var_data:
            Time = vd[-1]
            try:
                time_sec = datetime.strptime(Time, self.time_form_var).timestamp()
            except ValueError:
                mbox.setText("Формат времени не подходит")
                mbox.show()
                return
            time_sec_round = round(time_sec/0.5)*0.5
            data0 = [vd[0], time_sec_round]
            data_var.append(data0)


        if len(data_var) != 0:
            print('var_old', data_var[0])
        if len(self.var_data) != 0:
            print('var_new', self.var_data[0])

        data_var.sort(key=lambda x: x[-1], reverse=False)


        group_var = []
        group_var0 = []
        c = 1
        for i in range(1, len(data_var)):
            c += 1
            if abs(data_var[i-1][-1] - data_var[i][-1]) < 68:
                group_var0.append([data_var[i-1][0], data_var[i-1][-1]])
            else:
                group_var.append(group_var0)
                group_var0 = []
        group_var.append(group_var0)
        
         
        # Transpose
        group_list_var = []
        for group in group_var:
            list_data_var = list(map(list, zip(*group)))
            group_list_var.append(list_data_var)

        print('groups count', len(group_var))
        print('len_group_list_var', len(group_list_var))



        #------------------------New interpolate------------------------------------
        
        var_interp = [[], []]
    
        for gr in range(len(group_list_var)):
            self.dlg_UAV.progressBar.setValue(int((100/len(group_list_var)) * (gr+1)))
            self.dlg_UAV.progressBar.setFormat('Interpolate Variations: ' + str(gr+1) + '/' + str(len(group_list_var)))
            QApplication.processEvents()

            a = [group_list_var[gr][0], group_list_var[gr][-1]] 

            var_interp[-1].append(a[-1][0])
            var_interp[0].append(a[0][0])

            for i in range(1, len(a[-1])):
                dist_time = int(a[-1][i] - a[-1][i-1])

                if dist_time == 0:
                    dist_time = a[-1][i] - a[-1][i-1]

                if dist_time == 1:
                    var_interp[-1].append(a[-1][i-1] + 0.5) # Time
                    var_interp[-1].append(a[-1][i])
                    var_interp[0].append(a[0][i-1] + (a[0][i] - a[0][i-1]) / 2) # Field
                    var_interp[0].append(a[0][i])

                elif dist_time == 0.5:
                    var_interp[-1].append(a[-1][i-1]) # Time
                    var_interp[0].append(a[0][i-1]) #Field

                else:
                    for j in range(int(dist_time)):
                        var_interp[-1].append(a[-1][i-1] + j+1 - 0.5)
                        var_interp[-1].append(a[-1][i-1] + j+1)

                        ttt = a[-1][i-1] + j+1 - 0.5
                        tttt = a[-1][i-1] + j+1

                        var_interp[0].append(a[0][i-1] + ((a[0][i] - a[0][i-1]) / (dist_time)) * (j+1) - ((a[0][i] - a[0][i-1]) / (dist_time * 2)))
                        var_interp[0].append(a[0][i-1] + ((a[0][i] - a[0][i-1]) / (dist_time)) * (j+1))

        return var_interp



    def variations(self, data, proc, tic):

        tic = time.perf_counter()
        self.check_div1000_var = 0
        
        try:
            layer = self.vlayer
        except AttributeError:
            print(self.vlayer)
            mbox.setText("Нужно загрузить слой в Load Data")
            mbox.show()
            return

        var_interp = self.read_var()

        if var_interp == None:
            return

        #-------------------------------------------------------------

        if self.dlg_UAV.med_check.isChecked():
            norm_T = float(np.median(var_interp[0], axis=0))
        else:
            norm_T = float(self.dlg_UAV.norm_T.text())

        norm_var = [[], []]
        for i in range(len(var_interp[-1])):
            norm_var[0].append(var_interp[0][i] - norm_T)
            norm_var[-1].append(var_interp[-1][i])


        # Load layer
        time_index = self.dlg_UAV.time_CB.currentIndex() - 1
    
        Time = self.data[0][time_index]
        UAVProcess.timeForm(self, Time, var=0)
    
        try:
            time_sec = datetime.strptime(self.data[0][time_index], self.time_form).timestamp()
        except ValueError:
            mbox.setText("Формат времени не подходит (для коптера в вариациях)")
            mbox.show()
            return

        data_arr = []
        for i, point in enumerate(self.data):
            self.progress(i, len(self.data), 1000, 'Variations: mag times calc: ')
            time_sec = datetime.strptime(point[time_index], self.time_form).timestamp()
            time_sec_round = round(time_sec/0.5)*0.5
            arr = [*point, time_sec_round]
            data_arr.append(arr)

        # SORT MAG
        data_arr.sort(key=lambda x: (x[-1]), reverse=False)


        try:
            start = norm_var[-1].index(data_arr[0][-1])
        except ValueError:
            mbox.setText('Не найдено совпадений времени при чтении вариаций')
            mbox.show()
            return


        d = 0
        # Add vars in T
        cnt = -1
        for i, point in enumerate(data_arr):
            self.progress(i, len(data_arr), 1000, 'Variations: fill variations: ')
            
            strt_cnt = start + cnt

            if strt_cnt > len(norm_var[-1]) - 1:
                break

            mag_time = point[-1]
            var_time = norm_var[-1][strt_cnt+1]

            if mag_time == var_time:
                point[0] = round(point[0] - norm_var[0][strt_cnt], 3)
                cnt += 1
            else:
                idx = strt_cnt
    
                for j in range(idx, len(norm_var[-1])):
                    var_time_n = norm_var[-1][j]

                    if mag_time == var_time_n:
                        point[0] = round(point[0] - norm_var[0][j], 3)

                        start = j
                        cnt = 0
                        break
                    elif mag_time < var_time_n:
                        start = j
                        cnt = 0
                        break
                


        if proc == 1:
            if self.dlg_UAV.process_list.item(1).checkState() == Qt.Checked: # Slicing
                proc = 2
                self.cut_points(data_arr, proc, tic)
                return


        # Add points
        pnt = QgsVectorLayer('Point', layer.name() + '_Var', 'memory')
        crs = QgsCoordinateReferenceSystem()
        crs.createFromId(4326)
        pnt.setCrs(crs)
        pr = pnt.dataProvider()

        print(self.fieldList)

        #QgsField("Lenght", QVariant.Double,'double', 20, 3)

        for i in self.fieldList:
            if i[1] == 10: # String
                pr.addAttributes([QgsField(i[0], QVariant.String, 'string', 0, 0)])
            elif i[1] == 6: # Double
                pr.addAttributes([QgsField(i[0], QVariant.Double, 'double', i[2], i[3])])
            elif i[1] == 2: # Int
                pr.addAttributes([QgsField(i[0], QVariant.Int, 'int', i[2])])
            else:
                pr.addAttributes([QgsField(i[0], i[1])])

        pnt.updateFields()
        
        fets = []

        for i, val in enumerate(data_arr):
            self.progress(i, len(data_arr), 1000, 'Rendering: ')
            attrs = []
            for v in val:
                attrs.extend([v])
            fet = QgsFeature()
            fet.setGeometry(QgsPoint(val[-3], val[-2]))
            fet.setAttributes(attrs)
            fets.append(fet)

        pr.addFeatures(fets)
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(self.data)))
        mboxi.show()
        mboxi.exec_()



    def check_var(self):
        try:
            layer = self.vlayer
        except AttributeError:
            mbox.setText("Нужно загрузить слой в Load Data")
            mbox.show()
            return

        self.check_div1000_var = 0

        var_0 = self.read_var()

        if self.check_div1000_var == 1:
            mbox.setText("Значение поля в вариационном файле превышает 1_000_000, проверить деление вариаций на 1000")
            mbox.show()
            return

        try:
            var_interp = var_0[1]
        except TypeError:
            return

        var_val = var_0[0]

        min_var = min(var_val)
        max_var = max(var_val)
        
        # Load layer
        time_index = self.dlg_UAV.time_CB.currentIndex() - 1
        Time = self.data[0][time_index]
        UAVProcess.timeForm(self, Time, var=0)

        try:
            time_sec = datetime.strptime(self.data[0][time_index], self.time_form).timestamp()
        except ValueError:
            mbox.setText("Формат времени не подходит (в коптере при проверке вариаций)")
            mbox.show()
            return

        mag_times = []

        for i, point in enumerate(self.data):
            self.progress(i, len(self.data), 1000, 'Calc Mag Times: ')

            time_sec = datetime.strptime(point[time_index], self.time_form).timestamp()
            mag_times.append(time_sec)


        mag_times.sort()

        print('start mag', mag_times[0], 'start var', var_interp[0])

        start_time = min([var_interp[0], mag_times[0]])
        end_time = max([var_interp[-1], mag_times[-1]])

        mag_times = [t - start_time for t in mag_times]

        # Load variations
        var_times = [var_interp[0]-start_time]
        var_times_flat = [None]
        for i in range(1, len(var_interp)):
            var_times.append(var_interp[i]-start_time)
            if var_interp[i] > var_interp[i-1] + 80:
                var_times_flat.append(None)
            else:
                var_times_flat.append(var_val[i])

        mag_times_flat = [None]
        for i in range(1, len(mag_times)):
            if mag_times[i] > mag_times[i-1] + 1:
                mag_times_flat.append(None)
            else:
                mag_times_flat.append(min_var+5)

        day_tick = []
        day_tick_m = []
        day_tick_n = []
        for i in range(int(var_times[-1]/86400)+1):
            day_tick.append(86400*i)
            day_tick_m.append(86400*i+43200)
            day_tick_n.append(str(i+1))

        fig, axs = plt.subplots(1, 1, figsize = [22, 8]) # Figure
        plt.subplots_adjust(top=0.94, bottom=0.1, left=0.065, right=0.90, hspace=0.020)

        #axs.set_yticklabels([])
        axs.plot(mag_times, mag_times_flat, linewidth = 2, label = 'Съемка')
        axs.plot(var_times, var_times_flat, linewidth = 2, label = 'Вариации')
        for day in day_tick:
            axs.axvline(x = day, color = 'g', linestyle='--', linewidth=0.8)

        ticks1 = axs.set_xticks(day_tick_m, minor=True)
        labels1 = axs.set_xticklabels(day_tick_n, minor=True, fontsize=10, fontname="Arial", style='italic', color='g')
        for lnum, label in enumerate(labels1):
            label.set_y(label.get_position()[1] + 0.04)

        #for lab in labels1:
        #    lab.set_y(0.1)

        axs.tick_params(which='minor', axis='x', bottom = False)

        plt.suptitle('Длительности записей вариаций и съемки', y = 0.98, fontsize = 12)
        axs.set_xlim(0, end_time-start_time)
        axs.set_ylim(min_var, max_var)
        axs.set_xlabel('Время, сек', labelpad = 10, fontsize = 14)
        axs.set_ylabel('нТл', fontsize = 20, rotation = 90, labelpad = 24)
        
        fig.legend(loc=(0.91, 0.5), framealpha=1.0, frameon=True, fontsize = 12)
        #plt.grid(True)
        plt.show()

        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)



    def add_IGRF(self):
        self.layer = self.iface.activeLayer()

        self.fieldList = []
        [self.fieldList.append([field.name(), field.type()]) for field in self.layer.fields()]
        self.items = QgsFieldComboBox()
        self.items1 = QgsFieldComboBox()
        self.items2 = QgsFieldComboBox()
        self.items3 = QgsFieldComboBox()

        self.items.setLayer(self.layer)
        self.items1.setLayer(self.layer)
        self.items2.setLayer(self.layer)
        self.items3.setLayer(self.layer)

        for i, val in enumerate(self.fieldList):
            if val[0] == 'LON' or val[0] == 'lon' or val[0] == 'Lon':
                self.items.setCurrentIndex(i)
            if val[0] == 'LAT' or val[0] == 'lat' or val[0] == 'Lat':
                self.items1.setCurrentIndex(i)
            if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                self.items2.setCurrentIndex(i)
            if not self.dlg_UAV.fixed_data.isChecked():
                if val[0] == 'TIME' or val[0] == 'DATETIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATA':
                    self.items3.setCurrentIndex(i)

        label, label1, label2, label3= QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel()
        label.setText('Поле долготы')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        label1.setText('Поле широты')
        label1.setAlignment(Qt.AlignCenter)
        label1.setFont(QFont('MS Shell Dlg 2', 10))
        label2.setText('Поле высоты')
        label2.setAlignment(Qt.AlignCenter)
        label2.setFont(QFont('MS Shell Dlg 2', 10))
        label3.setText('Поле времени')
        label3.setAlignment(Qt.AlignCenter)
        label3.setFont(QFont('MS Shell Dlg 2', 10))
        self.dlg = QDialog()

        gridLayout = QGridLayout()
        gridLayout.setVerticalSpacing(10)
        gridLayout.setHorizontalSpacing(30)
        gridLayout.addWidget(label, 0, 0)
        gridLayout.addWidget(self.items, 1, 0)
        gridLayout.addWidget(label1, 0, 1)
        gridLayout.addWidget(self.items1, 1, 1)
        gridLayout.addWidget(label2, 0, 2)
        gridLayout.addWidget(self.items2, 1, 2)
        if not self.dlg_UAV.fixed_data.isChecked():
            gridLayout.addWidget(label3, 0, 3)
            gridLayout.addWidget(self.items3, 1, 3)

        self.dlg.setWindowTitle("Fields selection")
        #self.dlg.resize(300, 200)
        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(self.add_IGRF_OK)
        btnBox.rejected.connect(self.rejectDlg)
        if not self.dlg_UAV.fixed_data.isChecked():
            gridLayout.addWidget(btnBox, 2, 3)
        else:
            gridLayout.addWidget(btnBox, 2, 2)
        self.dlg.setLayout(gridLayout)
        self.dlg.exec_()

    def add_IGRF_OK(self):
        self.dlg.close()
        import UAV_Mag_Process.pyIGRF.value as igrf

        field_lon = self.items.currentField()
        field_lat = self.items1.currentField()
        field_alt = self.items2.currentField()
        field_time = self.items3.currentField()

        features = self.layer.getFeatures()

        range_from = int(self.dlg_UAV.lineEdit_from.text())
        range_to = int(self.dlg_UAV.lineEdit_to.text())
        step_year = int(self.dlg_UAV.lineEdit_step_year.text())


        # Fixed data
        if self.dlg_UAV.fixed_data.isChecked():
            year = int(self.dlg_UAV.year_str.text())
            if year % 4 == 0:
                year_sec = 31_622_400
            else:
                year_sec = 31_536_000
            month = int(self.dlg_UAV.month_str.text())
            day = int(self.dlg_UAV.day_str.text())

            moment1 = datetime(year, 1, 1, 00, 00, 00) # start year
            moment2 = datetime(year, month, day, 0, 0, 0)
            delta = moment2 - moment1
            d = delta.total_seconds() / year_sec
            time_year = year + d
        else:
            # Time format
            for feature in features:
                Time = feature.attribute(field_time)
                print(Time)
                UAVProcess.timeForm(self, Time, var=0)
                break
            # Def year
            date_time_obj = datetime.strptime(Time, self.time_form)
            year = date_time_obj.date().year
            if year % 4 == 0:
                year_sec = 31_622_400
            else:
                year_sec = 31_536_000
            moment1 = datetime(year, 1, 1, 00, 00, 00) # start year


        fields = []
        coords = []

        # Load attrs layer
        fet_count = self.layer.featureCount()

        for i, feature in enumerate(features):
            self.progress(i, fet_count, 25, 'Calculate: ')

            lon = feature.attribute(field_lon)
            lat = feature.attribute(field_lat)
            alt = feature.attribute(field_alt)
            
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.PointGeometry:
                if geomSingleType:
                    xy = geom.asPoint()
                    point = QgsPoint(xy)
                else:
                    xy = geom.asMultiPoint()
                    point = QgsPoint(xy[0])

            # calc share of year
            if not self.dlg_UAV.fixed_data.isChecked():
                time = feature.attribute(field_time)
                time_obj = datetime.strptime(time, self.time_form)
                mm = time_obj.date().month
                dd = time_obj.date().day
                hh = time_obj.time().hour
                m = time_obj.time().minute
                s = time_obj.time().second
                moment2 = datetime(year, mm, dd, hh, m, s)
                delta = moment2 - moment1
                d = delta.total_seconds() / year_sec
                time_year = year + d

            
            #with open("C:/Users/Admin/Desktop/pyxl/1585-2030.txt", "w") as f:
            #    pass
            
            #for d in range(1590, 2030, 1):
            #    print(d)
            coords.append((point.x(), point.y()))
            fields0 = []

            for j in self.fieldList:
                fields0.extend([feature.attribute(j[0])])

            if self.dlg_UAV.checkBox_fromto.isChecked():
                #f_dec = []
                f_inc = []
                #f_F = []
                for d in range(range_from, range_to, step_year):
                    mag = igrf.igrf_value(lat, lon, alt/1000, d)
                    #dec = round(float(mag[0]), 5)
                    inc = round(float(mag[1]), 5)
                    #F = round(float(mag[-1]), 3)
                    #f_dec.append(dec)
                    f_inc.append(inc)
                    #f_F.append(F)

                fields0.extend(f_inc)

            else:
                mag = igrf.igrf_value(lat, lon, alt/1000, time_year)
                dec = round(float(mag[0]), 5)
                inc = round(float(mag[1]), 5)
                F = round(float(mag[-1]), 3)

                fields0.extend([F, dec, inc])

            fields.append(fields0)
                
            #with open("C:/Users/Admin/Desktop/pyxl/1585-2030.txt", "a+") as f:
            #    f.write(str(d) + ' ' + str(dec) + ' ' + str(inc) + ' ' + str(F) + '\n')

        # Create points layer
        pnt = QgsVectorLayer('Point', self.layer.name() + '_igrf', 'memory')
        crs = self.layer.crs()
        pnt.setCrs(crs)
        pr = pnt.dataProvider()

        for i in self.fieldList:
            if i[1] == 10: # String
                pr.addAttributes([QgsField(i[0], QVariant.String, 'string', 0, 0)])
            elif i[1] == 6: # Double
                pr.addAttributes([QgsField(i[0], QVariant.Double, 'double', i[2], i[3])])
            elif i[1] == 2: # Int
                pr.addAttributes([QgsField(i[0], QVariant.Int, 'int', i[2])])
            else:
                pr.addAttributes([QgsField(i[0], i[1])])


        if self.dlg_UAV.checkBox_fromto.isChecked():
            #for d in range(range_from, range_to, step_year):
            #    pr.addAttributes([QgsField(str(d)+"_DEC", QVariant.Double)])
            for d in range(range_from, range_to, step_year):
                pr.addAttributes([QgsField(str(d)+"_INC", QVariant.Double)])
            #for d in range(range_from, range_to, step_year):
            #    pr.addAttributes([QgsField(str(d)+"_F", QVariant.Double)])
        else:
            pr.addAttributes([
                            QgsField("F_norm", QVariant.Double),
                            QgsField("DEC", QVariant.Double), 
                            QgsField("INC", QVariant.Double)
                            ])
        pnt.updateFields()
        fet = QgsFeature()

        for i, field in enumerate(fields):
            self.progress(i, len(fields), 1000, 'Rendering: ')
            fet.setGeometry(QgsPoint(coords[i][0], coords[i][1]))
            fet.setAttributes(field)
            pr.addFeatures([fet])

        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.iface.setActiveLayer(self.layer)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)



    def load_layer_data(self):
        self.vlayer = self.iface.activeLayer()
        self.vlayer_proc = self.iface.activeLayer()
        self.fieldList = []
        self.data = []

        [self.fieldList.append((field.name(), field.type(), field.length(), field.precision())) for field in self.vlayer.fields()]
        if self.vlayer == None or self.vlayer.type() == QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран слой с точками")
            mbox.show()
            return
        features = self.vlayer.getFeatures()
        fet_count = self.vlayer.featureCount()

        # Create points array
        for i, feature in enumerate(features):
            self.progress(i, fet_count, 1000, 'Load Data: ')
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.PointGeometry:
                if geomSingleType:
                    xy = geom.asPoint()
                    point = QgsPoint(xy)
                else:
                    xy = geom.asMultiPoint()
                    point = QgsPoint(xy[0])
            else:
                print(geom.type(), i)
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                return
            attrs = [*feature.attributes(), point.x(), point.y()]
            self.data.append(attrs)

        CB = [self.dlg_UAV.field1_CB, self.dlg_UAV.field2_CB, self.dlg_UAV.time_CB, self.dlg_UAV.alt1_CB, self.dlg_UAV.alt2_CB, self.dlg_UAV.pr_CB]
        for i in range(self.dlg_UAV.field1_CB.count() + 1):
            for item in CB:
                item.removeItem(0)
        for item in CB:
                item.addItem('')
        for i in self.fieldList:
            for item in CB:
                item.addItem(i[0])

        for i, val in enumerate(self.fieldList):
            if val[0] == 'TIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATETIME':
                self.dlg_UAV.time_CB.setCurrentIndex(i + 1)
            if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                self.dlg_UAV.alt1_CB.setCurrentIndex(i + 1)
            if val[0] == 'Alt_con':
                self.dlg_UAV.alt2_CB.setCurrentIndex(i + 1)
            if val[0] == 'FIELD' or val[0] == 'Field' or val[0] == 'T' or val[0] == 'T_reg':
                self.dlg_UAV.field1_CB.setCurrentIndex(i + 1)
            if val[0] == 'T_con':
                self.dlg_UAV.field2_CB.setCurrentIndex(i + 1)
            if val[0] == 'PR' or val[0] == 'Pr' or val[0] == 'pr':
                self.dlg_UAV.pr_CB.setCurrentIndex(i + 1)

        time_index = self.dlg_UAV.time_CB.currentIndex() - 1

        if time_index != -1:
            Time = self.data[0][time_index]
            UAVProcess.timeForm(self, Time, var=0)

        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat('Data loaded')
        self.dlg_UAV.label_15.setStyleSheet("background:rgba(255, 255, 200, 255);") 
        self.dlg_UAV.label_15.setText(self.vlayer.name())



    def LinesFromPoints(self):
        vlayer = self.iface.activeLayer()

        points = []
        Vertex = []
        VertexLines = []

        fet_count = vlayer.featureCount()
        off = 0

        t0 = time.perf_counter()

        for i in range(fet_count):

            self.progress(i, fet_count, 1000, 'Create Lines: ')

            feature = vlayer.getFeature(i)

            if feature.attributes() == []:
                mbox.setText("Работает только с сохраненным на диск слоем и номер профиля должен быть в 9 столбце")
                mbox.show()
                return

            numPr = feature.attribute(5)

            # Условие для первой точки
            if i == 0:
                geom = feature.geometry()
                xy = geom.asPoint()
                x = xy.x()
                y = xy.y()
                VertexLines.append([x, y])

            if off == 0:
                cnt = numPr
                off = 1

            if cnt != numPr:
                off = 0
                geom = feature.geometry()
        
                xy = geom.asPoint()
                
                x = xy.x()
                y = xy.y()

                feature = vlayer.getFeature(i-1)
                geom = feature.geometry()
                xy = geom.asPoint()
                x_end = xy.x()
                y_end = xy.y()

                VertexLines.append([x_end, y_end])
                VertexLines.append([x, y])

            # Условие для последней точки
            if i == fet_count - 1:
                geom = feature.geometry()
                xy = geom.asPoint()
                x = xy.x()
                y = xy.y()
                VertexLines.append([x, y])

        t1 = time.perf_counter()
        print('t1', t1-t0)

        dist_list = []
        profiles = []

        # Разбиение точек на линии
        for i in range(0, len(VertexLines), 2):
            profiles.append([VertexLines[i], VertexLines[i+1]])
            dist_list.append(((VertexLines[i+1][0] - VertexLines[i][0]) ** 2 + (VertexLines[i+1][1] - VertexLines[i][1]) ** 2) ** 0.5)

        # create layer
        Lines = QgsVectorLayer("LineString", "Lines", "memory")
        crs = vlayer.crs()
        Lines.setCrs(crs)
        pr = Lines.dataProvider()
        pr.addAttributes([QgsField("PR", QVariant.Int), QgsField("Length", QVariant.Double,'double', 15, 3)])
        Lines.updateFields()
        fet = QgsFeature()

        # add lines
        for i in range(len(profiles)):
            xy = [QgsPoint(profiles[i][0][0], profiles[i][0][1]), QgsPoint(profiles[i][1][0], profiles[i][1][1])]
            fet.setGeometry(QgsGeometry.fromPolyline(xy))
            fet.setAttributes([i + 1, dist_list[i]])
            pr.addFeatures([fet])
            Lines.updateExtents()
            QgsProject.instance().addMapLayer(Lines)

        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)

        print("Построено линий", len(profiles))



    def cut_points(self, data, proc, tic):
        try:
            vlayer = self.vlayer
        except AttributeError:
            mbox.setText("Нужно загрузить слой в Load Data")
            mbox.show()
            return

        time_index = self.dlg_UAV.time_CB.currentIndex() - 1

        if time_index == -1:
            mbox.setText("Нужно выбрать столбец для времени")
            mbox.show()
            return

        if proc == 0:
            tic = time.perf_counter()
            data = self.data

        gr_index = None

        for i, val in enumerate(self.fieldList):
            if val[0] == 'Gr' or val[0] == 'GR' or val[0] == 'gr' or val[0] == 'Group' or val[0] == 'group' or val[0] == 'GROUP':
                gr_index = i

        targetCrs = self.dlg_UAV.mQgsProjectionSelectionWidget.crs().authid()
        crsSrc = vlayer.crs()
        crsDest = QgsCoordinateReferenceSystem(targetCrs) # WGS 84 convert rect proj
        transformContext = QgsProject.instance().transformContext()
        xform = QgsCoordinateTransform(crsSrc, crsDest, transformContext)

        if len(targetCrs) == 0:
            mbox.setText("Нужно выбрать прямоугольную систему координат")
            mbox.show()
            return

        # add timesec to list
        Time = data[0][time_index]
        UAVProcess.timeForm(self, Time, var=0)

        if self.time_form != 'digit':
            try:
                time_sec = datetime.strptime(data[0][time_index], self.time_form).timestamp()
            except ValueError:
                mbox.setText("Формат времени не подходит (при обрезке)")
                mbox.show()
                return

        data_0 = []
    
        for i, point in enumerate(data):
            self.progress(i, len(data), 1000, 'Slicing: reprojecting: ')
            
            if proc == 0 or (proc == 2 and self.dlg_UAV.process_list.item(0).checkState() != Qt.Checked):
                if self.time_form == 'digit':
                    time_sec = float(point[time_index])
                else:
                    time_sec = datetime.strptime(point[time_index], self.time_form).timestamp()
                data_0.append([*point, time_sec])
            elif proc == 2 and self.dlg_UAV.process_list.item(0).checkState() == Qt.Checked:
                data_0.append(point)

            # forward transformation: src -> dest
            xy = xform.transform(QgsPointXY(data_0[i][-3], data_0[i][-2]))
            x = xy.x()
            y = xy.y()

            data_0[i][-3] = x
            data_0[i][-2] = y


        if gr_index:
            data_0.sort(key=lambda x: (x[gr_index], x[-1]), reverse=False)
        else:
            data_0.sort(key=lambda x: x[-1], reverse=False)

        x0 = data_0[0][-3]
        y0 = data_0[0][-2]

        for i in range(1, len(data_0)):
            self.progress(i, len(data_0), 1000, 'Slicing: calculate angle: ')

            dtime = data_0[i][-1]-data_0[i-1][-1]

            if abs(dtime) > 60:
                x0 = data_0[i][-3]
                y0 = data_0[i][-2]

            dx = data_0[i][-3] - data_0[i-1][-3]
            dy = data_0[i][-2] - data_0[i-1][-2]

            if dy == 0:
                dy = 0.00000001

            tga = dx/dy
            deg = math.degrees(math.atan(tga))

            if 84 < deg or deg < -84:
                deg = abs(deg) 

            dist = ((data_0[i][-3]-x0)**2 + (data_0[i][-2]-y0)**2)**0.5
            disti = ((data_0[i][-3]-data_0[i-1][-3])**2+(data_0[i][-2]-data_0[i-1][-2])**2)**0.5
            

            data_0[i-1].append(dtime)
            data_0[i-1].append(deg)
            data_0[i-1].append(dist)
            data_0[i-1].append(disti)

        data_0[i].append(dtime)
        data_0[i].append(deg)
        data_0[i].append(dist)
        data_0[i].append(disti)

        #  Def angle
        data_1 = []
        Distarr = []
        Degarr = []

        for i in range(len(data_0)):
            if data_0[i][-2] > 6 and 1.2 < data_0[i][-1] < 60:
                data_1.append(data_0[i])
                Distarr.append(data_0[i][-1])
                Degarr.append(data_0[i][-3])

        npDeg = np.median(Degarr)

        Degarr2 = []
        Deg2 = []
        for i, val in enumerate(Degarr):
             Deg2.append(val)
             if i % 20 == 0 and (npDeg - 5 < val < npDeg + 5):
                Degarr2.append(np.median(Deg2))
                Deg2 = []

        npDeg2 = np.median(Degarr2)
        mean_dists = np.mean(Distarr)
        
        print('deg1', npDeg)
        print('deg2', npDeg2)
        print('mean_dist', mean_dists)

        # Def cut points 
        end = 0
        data_2 = []
        coef = float(self.dlg_UAV.coef.text()) * 2
        step_series = int(self.dlg_UAV.points_win.text()) # Window points

        print(data_1[0])
        print(data_1[2])

        # Rotate for 90 -------------------------------------------------------------------
        angle = 0
        if npDeg2 > 84:
            new_xy = []

            ext = vlayer.extent()
            ext_list = [ext.xMinimum(), ext.xMaximum(), ext.yMinimum(), ext.yMaximum()]
            xy_min = xform.transform(QgsPointXY(ext.xMinimum(), ext.yMinimum()))
            x_min, y_min = xy_min.x(), xy_min.y()
            x_min, y_min = x_min - 100, y_min - 100

            angle = 15

            cos = math.cos(math.radians(angle))
            sin = math.sin(math.radians(angle))

            for i, pt in enumerate(data_1):
                x, y = pt[-7], pt[-6]
                x_rot = (x - x_min) * cos - (y - y_min) * sin + x_min
                y_rot = (x - x_min) * sin + (y - y_min) * cos + y_min 
                data_1[i][-7], data_1[i][-6] = x_rot, y_rot

            npDeg2 = npDeg2 - angle

            for i in range(1, len(data_1)):
                self.progress(i, len(data_1), 1000, 'Slicing: calculate angle for 90 deg: ')
    
                dx = data_1[i][-7] - data_1[i-1][-7]
                dy = data_1[i][-6] - data_1[i-1][-6]
    
                if dy == 0:
                    dy = 0.00000001
    
                tga = dx / dy
                deg = math.degrees(math.atan(tga))

                data_1[i-1][-3] = deg

            data_1[i][-3] = deg
        #------------------------------------------------------------------------------------------



        for i in range(len(data_1)-step_series):
            self.progress(i, len(data_1), 1000, 'Slicing: cut points: ')
            degs_series = []
            
            for j in range(step_series):
                deg = data_1[i+j][-3]
                degs_series.append(round(deg, 3))

            angle_series = np.median(degs_series)

            if npDeg2 - coef < angle_series < npDeg2 + coef:
                data_2.append(data_1[i][:-5])
                index_end = i
                end = 1
            else:
                if end == 1 and i > step_series:
                    degs_series = []
                    for l in range(step_series):
                        for k in range(step_series):
                            deg = data_1[i+k+l-step_series][-3]
                            degs_series.append(deg) 
    
                        angle_series = np.mean(degs_series)
    
                        if npDeg2 - coef < angle_series < npDeg2 + coef:
                            data_2.append(data_1[i+l][:-5])

                end = 0 

        if index_end + 2 >= len(data_1) - step_series:
            for i in range(step_series):
                data_2.append(data_1[index_end+1+i][:-5])


        # turn rot ----------------------------------------------------------
        if angle != 0:
            angle = -angle
            cos = math.cos(math.radians(angle))
            sin = math.sin(math.radians(angle))
            for i, pt in enumerate(data_2):
                x, y = pt[-2], pt[-1]
                x_rot = (x - x_min) * cos - (y - y_min) * sin + x_min
                y_rot = (x - x_min) * sin + (y - y_min) * cos + y_min 
                data_2[i][-2], data_2[i][-1] = x_rot, y_rot
        #--------------------------------------------------------------------



        if proc == 0 or ():
            pnt = QgsVectorLayer('Point', vlayer.name() + '_Cut', 'memory')
        elif proc == 2 and self.dlg_UAV.process_list.item(2).checkState() != Qt.Checked: # Stop
            pnt = QgsVectorLayer('Point', vlayer.name() + '_Cut', 'memory') 
        elif proc == 2 and self.dlg_UAV.process_list.item(2).checkState() == Qt.Checked: # goto numerate
            proc = 3
            rect = 0
            self.add_n_profile(data_2, proc, tic, rect)
            return       

        # Render points
        pnt.setCrs(self.dlg_UAV.mQgsProjectionSelectionWidget.crs())
        pr = pnt.dataProvider()

        for i in self.fieldList:
            if i[1] == 10: # String
                pr.addAttributes([QgsField(i[0], QVariant.String, 'string', 0, 0)])
            elif i[1] == 6: # Double
                pr.addAttributes([QgsField(i[0], QVariant.Double, 'double', i[2], i[3])])
            elif i[1] == 2: # Int
                pr.addAttributes([QgsField(i[0], QVariant.Int, 'int', i[2])])
            else:
                pr.addAttributes([QgsField(i[0], i[1])])

        pnt.updateFields()
        fet = QgsFeature()

        for i, pt in enumerate(data_2):
            self.progress(i, len(data_2), 1000, 'Rendering: ')
            attrs = []
            attrs.extend(pt)
            fet.setGeometry(QgsPoint(pt[-2], pt[-1]))
            fet.setAttributes(attrs)
            pr.addFeatures([fet])

        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)

        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(data_2)))
        mboxi.show()
        mboxi.exec_()



    def edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr):
        x_reg = i[2].x()
        y_reg = i[2].y()
        dist = round(((x_ctrl - x_reg)**2 + (y_ctrl - y_reg)**2)**0.5, 3)
        if dist < dist_ctrl:
            T0 = i[0]
            T1 = ctrl[0]
            Time0 = i[1]
            Time1 = ctrl[1]
            alt0 = i[3]
            alt1 = ctrl[3]
            alt_err = alt0 - alt1
            alt_err_abs = abs(alt0 - alt1)
            T_err = T0-T1
            T_err_abs = abs(T_err)
            self.fin.append([T0, T1, Time0, Time1, x_reg, y_reg, x_ctrl, y_ctrl, alt0, alt1, alt_err, alt_err_abs, dist, T_err, T_err_abs, pr])

    def Control(self):
        reg_layer = self.dlg_UAV.MapLayer_CB.currentLayer()
        con_layer = self.dlg_UAV.MapLayer_control_CB.currentLayer()

        self.fieldList_reg = []
        self.fieldList_con = []
        [self.fieldList_reg.append([field.name(), field.type()]) for field in reg_layer.fields()]
        [self.fieldList_con.append([field.name(), field.type()]) for field in con_layer.fields()]
        self.items_reg = QgsFieldComboBox()
        self.items1_reg = QgsFieldComboBox()
        self.items2_reg = QgsFieldComboBox()
        self.items_con = QgsFieldComboBox()
        self.items1_con = QgsFieldComboBox()
        self.items2_con = QgsFieldComboBox()
        self.items_reg.setLayer(reg_layer)
        self.items1_reg.setLayer(reg_layer)
        self.items2_reg.setLayer(reg_layer)
        self.items_con.setLayer(con_layer)
        self.items1_con.setLayer(con_layer)
        self.items2_con.setLayer(con_layer)

        gridLayout = QGridLayout()

        for i, val in enumerate(self.fieldList_reg):
            if val[0] == 'T' or val[0] == 'FIELD':
                self.items_reg.setCurrentIndex(i)
            if val[0] == 'TIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATATIME':
                self.items1_reg.setCurrentIndex(i)
            if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                self.items2_reg.setCurrentIndex(i)
            if val[0] == 'PR' or val[0] == 'Pr' or val[0] == 'pr':
                self.items3_reg = QgsFieldComboBox()
                self.items3_reg.setLayer(reg_layer)
                self.items3_reg.setCurrentIndex(i)
                self.gr_index = i
                label3 = QtWidgets.QLabel()
                label3.setText('Поле профиля')
                label3.setAlignment(Qt.AlignCenter)
                label3.setFont(QFont('MS Shell Dlg 2', 10))
                gridLayout.addWidget(label3, 0, 4)
                gridLayout.addWidget(self.items3_reg, 1, 4)
        for i, val in enumerate(self.fieldList_con):
            if val[0] == 'T' or val[0] == 'FIELD':
                self.items_con.setCurrentIndex(i)
            if val[0] == 'TIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATATIME':
                self.items1_con.setCurrentIndex(i)
            if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                self.items2_con.setCurrentIndex(i)
            if val[0] == 'PR' or val[0] == 'Pr' or val[0] == 'pr':
                self.items3_con = QgsFieldComboBox()
                self.items3_con.setLayer(con_layer)
                self.items3_con.setCurrentIndex(i)
                gridLayout.addWidget(self.items3_con, 2, 4)

        label, label1, label2, label_reg, label_con = QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel()
        label.setText('Поле поля')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        label1.setText('Поле времени')
        label1.setAlignment(Qt.AlignCenter)
        label1.setFont(QFont('MS Shell Dlg 2', 10))
        label2.setText('Поле высот датчика')
        label2.setAlignment(Qt.AlignCenter)
        label2.setFont(QFont('MS Shell Dlg 2', 10))
        label_reg.setText('Reg')
        label_reg.setAlignment(Qt.AlignRight)
        label_reg.setFont(QFont('MS Shell Dlg 2', 10))
        label_con.setText('Con')
        label_con.setAlignment(Qt.AlignRight)
        label_con.setFont(QFont('MS Shell Dlg 2', 10))
        self.dlg = QDialog()

        
        gridLayout.setVerticalSpacing(10)
        gridLayout.setHorizontalSpacing(30)
        gridLayout.addWidget(label, 0, 1)
        gridLayout.addWidget(self.items_reg, 1, 1)
        gridLayout.addWidget(self.items_con, 2, 1)
        gridLayout.addWidget(label1, 0, 2)
        gridLayout.addWidget(self.items1_reg, 1, 2)
        gridLayout.addWidget(self.items1_con, 2, 2)
        gridLayout.addWidget(label2, 0, 3)
        gridLayout.addWidget(self.items2_reg, 1, 3)
        gridLayout.addWidget(self.items2_con, 2, 3)
        gridLayout.addWidget(label_reg, 1, 0)
        gridLayout.addWidget(label_con, 2, 0)

        self.dlg.setWindowTitle("Fields selection")

        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(self.ControlOK)
        btnBox.rejected.connect(self.rejectDlg)
        gridLayout.addWidget(btnBox, 3, 3)
        self.dlg.setLayout(gridLayout)
        self.dlg.exec_()        

    def ControlOK(self):
        self.dlg.close()
        tic = time.perf_counter()
        check_fields = []
        check_fields.append([self.items_reg.currentField(), self.items1_reg.currentField(), self.items2_reg.currentField()])
        check_fields.append([self.items_con.currentField(), self.items1_con.currentField(), self.items2_con.currentField()])

        try:
            pr_col = self.items3_reg.currentField()
        except:
            pr_col = None

        layer_list = []
        layer_list.append(self.dlg_UAV.MapLayer_CB.currentLayer())
        layer_list.append(self.dlg_UAV.MapLayer_control_CB.currentLayer())
        dist_ctrl = float(self.dlg_UAV.dist_control.text())
        square_len = float(self.dlg_UAV.square_len.text())
        f0 = layer_list[0].featureCount()
        f1 = layer_list[1].featureCount()

        if f0 == 0 or f1 == 0:
            mbox.setText('Нет точек в одном из слоев')
            mbox.show()
            return

        f_sum = f0 + f1
        extent = layer_list[1].extent()
        xmax = extent.xMaximum() + 50
        ymax = extent.yMaximum() + 50
        xmin = extent.xMinimum() - 50
        ymin = extent.yMinimum() - 50
        len_a = xmax - xmin
        len_b = ymax - ymin
        
        rows = int(len_b // square_len + 1)
        cols = int(len_a // square_len + 1)
        square_count = (rows + 1) * cols

        print('square_count', square_count)
        fields_list = []
        Distarr = []


        # Reg and Control points array
        for i in range(2):
            features = layer_list[i].getFeatures()
            fields = []
            for j, feature in enumerate(features):
                self.progress(j, f_sum, 1000, 'Load Data: ')

                T = float(feature.attribute(check_fields[i][0]))
                Time = feature.attribute(check_fields[i][1])
                Alt = float(feature.attribute(check_fields[i][2]))

                if pr_col != None:
                    pr = feature.attribute(pr_col)
                else:
                    pr = None

                geom = feature.geometry()
                geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
                if geom.type() == QgsWkbTypes.PointGeometry:
                    if geomSingleType:
                        xy = geom.asPoint()
                        point = QgsPoint(xy)
                    else:
                        xy = geom.asMultiPoint()
                        point = QgsPoint(xy[0])

                fields.append([T, Time, point, Alt, pr])
            fields_list.append(fields)

        # Squares
        squares = []
        for _ in range(square_count):
            squares.append([])

        for i, fld in enumerate(fields_list[0]):
            self.progress(i, len(fields_list[0]), 100, 'Calc Squares: ')

            if ((xmin - dist_ctrl) < fld[2].x() < (xmax + dist_ctrl)) and ((ymin - dist_ctrl) < fld[2].y() < (ymax + dist_ctrl)):
                x_shift = fld[2].x() - xmin
                y_shift = fld[2].y() - ymin
                col = int(abs(x_shift // square_len) + 1)
                row = int(abs(y_shift // square_len) + 1)
                square_num = (row - 1) * cols + col
                try:
                    squares[square_num - 1].append(fld)
                except IndexError:
                    print(square_num, cols, col, row)

        # Calc controls
        self.fin = []

        for j, ctrl in enumerate(fields_list[1]):
            self.progress(j, len(fields_list[1]), 100, 'Calc Controls: ')

            x_ctrl = ctrl[2].x()
            y_ctrl = ctrl[2].y()
            x_shift = x_ctrl - xmin
            y_shift = y_ctrl - ymin
            col = int(abs(x_shift // square_len) + 1)
            row = int(abs(y_shift // square_len) + 1)
            square_num = (row - 1) * cols + col

            pr = ctrl[-1]

            # Edge conditions
            for i in squares[square_num - 1]:
                UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # L
            if (square_len * (col-1) - dist_ctrl) < x_shift < (square_len * (col-1) + dist_ctrl) and square_num > 1:
                for i in squares[square_num - 2]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # R
            if (square_len * col - dist_ctrl) < x_shift < (square_len * col + dist_ctrl) and square_num < square_count:
                for i in squares[square_num]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # B
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for i in squares[square_num - 1 - cols]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # T
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols:
                for i in squares[square_num - 1 + cols]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)

            # T - 1
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols:
                for i in squares[square_num - 1 + cols - 1]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # T + 1
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols and square_num - 1 + cols + 1 < square_count:
                for i in squares[square_num - 1 + cols + 1]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # B - 1
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for i in squares[square_num - 1 - cols - 1]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # B + 1
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for i in squares[square_num - 1 - cols + 1]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
       
        #Create points layer
        try:
            if isinstance(self.fin[0][2], str) == True:
                f_type = QVariant.String
            else:
                f_type = QVariant.Double
        except IndexError:
            mbox.setText("Охваты слоев в разных СК")
            mbox.show()
            return

        pnt = QgsVectorLayer("PointZ", "Ctrl_points", "memory")
        crs = layer_list[0].crs()
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        pr.addAttributes([QgsField('T_reg', QVariant.Double, 'double', 8, 3), 
                          QgsField('T_con', QVariant.Double, 'double', 8, 3),
                          QgsField('TIME', f_type),
                          QgsField('TIME_con', f_type),
                          QgsField('x_reg', QVariant.Double, 'double', 20, 7),
                          QgsField('y_reg', QVariant.Double, 'double', 20, 7),
                          QgsField('x_con', QVariant.Double, 'double', 20, 7),
                          QgsField('y_con', QVariant.Double, 'double', 20, 7),
                          QgsField('Alt_reg', QVariant.Double, 'double', 7, 3),
                          QgsField('Alt_con', QVariant.Double, 'double', 7, 3),
                          QgsField('Alt_err', QVariant.Double, 'double', 7, 3),
                          QgsField('Alt_errabs', QVariant.Double, 'double', 7, 3),
                          QgsField('Dist', QVariant.Double, 'double', 8, 3),
                          QgsField('T_err', QVariant.Double, 'double', 8, 3),
                          QgsField('T_err_abs', QVariant.Double, 'double', 8, 3),
                          ])
        if pr_col != None:
            pr.addAttributes([QgsField('PR', QVariant.Int)])
        pnt.updateFields()
        fet = QgsFeature()
        
        
        # Sort
        sort_ctrl_index = self.dlg_UAV.sort_ctrl_CB.currentIndex()
        if sort_ctrl_index == 0:
            ctr_ind = 4 # Sort X
        else:
            ctr_ind = 5 # Sort Y
        
        self.fin.sort(key = lambda x: (x[-1], x[ctr_ind], -x[-4])) # Sort X or Y

        xxx = list(zip(*self.fin))[4]
        yyy = list(zip(*self.fin))[5]
        

        columns_condition = [xxx, yyy]

        arr = np.array(columns_condition, dtype='float64')
        att_T = arr.T

        idx = att_T[:-1] == att_T[1:]
        idx = ~idx
        mask = np.prod(idx, axis=1)


        self.fin = list(compress(self.fin, mask))


        # Create points
        for i, l in enumerate(self.fin):
            self.progress(i, len(self.fin), 1000, 'Rendering: ')
            attrs = [l[0], l[1], l[2], l[3], l[4], l[5], l[6], l[7], l[8], l[9], l[10], l[11], l[12], l[13], l[14], l[15]]
            fet.setGeometry(QgsPoint(l[4], l[5], l[8]))
            fet.setAttributes(attrs)
            pr.addFeatures([fet])
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)

        file_path = self.dlg_UAV.mQgsFileWidget.filePath()
        lay = self.iface.activeLayer()
        if file_path != "":
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "ESRI Shapefile"
            options.layerName = lay.name()
            QgsVectorFileWriter.writeAsVectorFormatV3(lay, file_path, QgsCoordinateTransformContext(), options)
            vlayer = QgsVectorLayer(file_path+'.shp', "Ctrl_points_saved", "ogr")
            QgsProject.instance().addMapLayer(vlayer)
            QgsProject.instance().removeMapLayers([lay.id()])

        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(self.fin)))
        mboxi.show()
        mboxi.exec_()



    def add_n_profile(self, data, proc, tic, rect):
        if proc == 0:
            tic = time.perf_counter()
            try:
                layer = self.vlayer
            except AttributeError:
                mbox.setText("Нужно загрузить слой в Load Data")
                mbox.show()
                return
    
            extent = layer.extent()
            crs = layer.crs()
    
            if crs.authid() == 'EPSG:4326':
                mbox.setText("СК слоя должна быть прямоугольной")
                mbox.show()
                return
    
            xmax = extent.xMaximum()
            ymax = extent.yMaximum()
            xmin = extent.xMinimum()
            ymin = extent.yMinimum()
    
            if self.dlg_UAV.time_CB.currentText() == '':
                mbox.setText("Нужно выбрать поле времени")
                mbox.show()
                return
            
            attrs = copy.deepcopy(self.data)


        elif proc == 3:
            if self.dlg_UAV.process_list.item(1).checkState() != Qt.Checked:
                crs = self.vlayer.crs()
            else:
                crs = self.dlg_UAV.mQgsProjectionSelectionWidget.crs()
            fields_count = len(self.fieldList)
            len_f = len(data[0])
            sclice_range = len_f - fields_count

            attrs = [x for x in data]

            xmin = min(attrs, key=lambda i : i[-2])[-2]
            xmax = max(attrs, key=lambda i : i[-2])[-2]
            ymin = min(attrs, key=lambda i : i[-1])[-1]
            ymax = max(attrs, key=lambda i : i[-1])[-1]


        time_index = self.dlg_UAV.time_CB.currentIndex() - 1
        attrs.sort(key=lambda x: x[time_index], reverse=False)

        dist_pr = float(self.dlg_UAV.dist_PR.text())
        width_line = float(self.dlg_UAV.width_line.text())
        
        len_a = xmax - xmin
        len_b = ymax - ymin
        centerXY = [xmin + len_a / 2, ymin + len_b / 2]

        rect_count = int(len_a // dist_pr)

        # Define angles
        for i in range(1, len(attrs)):
            self.progress(i, len(attrs), 1000, 'Numerate: define angles: ')
            x0 = attrs[i-1][-2]
            y0 = attrs[i-1][-1]
            x1 = attrs[i][-2]
            y1 = attrs[i][-1]
            dx = x1 - x0
            dy = y1 - y0

            if dy == 0:
                dy = 0.00000001

            tga = dx / dy
            deg = math.degrees(math.atan(tga))
            dist = ((x1 - x0)**2 + (y1 - y0)**2)**0.5
            attrs[i-1].extend([dist, deg])

        attrs[i].extend([dist, deg])

        # Define angle lines
        if len(attrs) >= 20000:
            gr_len = 20
        else:
            gr_len = 10

        band = []
        fi = []
        Means = []
        c = 0
        for i in attrs:
            if 1.2 < i[-2] < 60:
                c += 1
                band.append(i[-1])
            if c % gr_len == 0 and c > 0 and len(band) != 0:
                fi.append(band)
                band = []
        fi.append(band)

        if len(fi[-1]) == 0:
            fi = fi[:-1]

        a = np.array(fi[:-1])
        flatten = np.absolute(a.flatten())
        med_flat = np.median(flatten)

        if 88.5 <= med_flat <= 90:
            npDeg = -90
            print('deg = 90')
        else:
            Sums = []
            direct = []

            for i in fi:
                Sums = []

                for j in range(1, len(i)):
                    if abs(i[j] - i[j-1]) >= 178.5: # For near 90 angle
                        if i[j-1] > 0:
                            direct.append(i[j-1] - 90)
                        else:
                            direct.append(i[j-1] + 90)
                    else:
                        Sums.append(i[j])
                Means.append(np.mean(Sums))
    
            print('len_dir', len(direct))
            print('med_dir', np.median(direct))
    
            npDeg = -np.median(Means)
            print('deg1', npDeg, len(Means))
            filtered = list(filter(lambda x: ((-npDeg - 7.5) < x < (-npDeg + 7.5)), Means))
            npDeg = -np.median(filtered)
            print('deg2', npDeg, len(filtered))
    
            Means = []
            gg = []
            band = []
    
            for i in attrs:
                if (1.2 < i[-2] < 60) and (-npDeg - 7.5 <  i[-1] < -npDeg + 7.5):
                    c += 1
                    band.append(i[-1])
                if c % int(gr_len + 10) == 0 and c > 0 and len(band) != 0:
                    gg.append(band)
                    band = []
            gg.append(band)
    
            Sums = []
            for i in gg:
                Sums.append(np.mean(i))
    
            if not np.isnan(-np.median(Sums)):
                npDeg = -np.median(Sums)
                print('deg3', npDeg, len(Sums))
            
            if len(attrs) >= 10000:
                filtered = list(filter(lambda x: ((-npDeg - 0.05) < x < (-npDeg + 0.05)), Sums))
                if len(filtered) > 4:
                    npDeg = -np.median(filtered)
                    print('deg4', npDeg, len(filtered))
    
            if len(direct) >= len(attrs) / 3:
                if np.median(direct) > 0:
                    npDeg = np.median(direct) + 90
                else:
                    npDeg = np.median(direct) - 90
                print('deg_dir', npDeg)

        

        # Define rectangles
        cos = math.cos(math.radians(npDeg))
        sin = math.sin(math.radians(npDeg))
        
        zero_points = []
        for point in attrs:
            x = point[-4]
            y = point[-3]
            X = (x - centerXY[0]) * cos + (y - centerXY[1]) * sin + centerXY[0]
            Y = -(x - centerXY[0]) * sin + (y - centerXY[1]) * cos + centerXY[1]
            zero_points.append([X, Y, *point])

        # Def extent zero points
        xmin = list(map(min, *zero_points))[0] - dist_pr / 2
        xmax = list(map(max, *zero_points))[0]
        ymin = list(map(min, *zero_points))[1] - 1
        ymax = list(map(max, *zero_points))[1] + 1
        shift_x = (dist_pr - width_line) / 2

        len_a = xmax - xmin
        rect_count = int(len_a // dist_pr + 1)
        rects = []
        pt = []

        for i in range(rect_count):
            self.progress(i, rect_count, 1, 'Numerate: ')

            xy0 = QgsPointXY(xmin + i * dist_pr + shift_x, ymin)
            xy1 = QgsPointXY(xmin + (i + 1) * dist_pr - shift_x, ymin)
            xy2 = QgsPointXY(xmin + (i + 1) * dist_pr - shift_x, ymax)
            xy3 = QgsPointXY(xmin + i * dist_pr + shift_x, ymax)

            px0_turn = cos * (xy0[0]-centerXY[0]) - sin * (xy0[1]-centerXY[1]) + centerXY[0]
            py0_turn = sin * (xy0[0]-centerXY[0]) + cos * (xy0[1]-centerXY[1]) + centerXY[1]
            px1_turn = cos * (xy1[0]-centerXY[0]) - sin * (xy1[1]-centerXY[1]) + centerXY[0]
            py1_turn = sin * (xy1[0]-centerXY[0]) + cos * (xy1[1]-centerXY[1]) + centerXY[1]
            px2_turn = cos * (xy2[0]-centerXY[0]) - sin * (xy2[1]-centerXY[1]) + centerXY[0]
            py2_turn = sin * (xy2[0]-centerXY[0]) + cos * (xy2[1]-centerXY[1]) + centerXY[1]
            px3_turn = cos * (xy3[0]-centerXY[0]) - sin * (xy3[1]-centerXY[1]) + centerXY[0]
            py3_turn = sin * (xy3[0]-centerXY[0]) + cos * (xy3[1]-centerXY[1]) + centerXY[1]
            p0 = QgsPointXY(px0_turn, py0_turn)
            p1 = QgsPointXY(px1_turn, py1_turn)
            p2 = QgsPointXY(px2_turn, py2_turn)
            p3 = QgsPointXY(px3_turn, py3_turn)

            rects.append([p0, p1, p2, p3])

            x0 = xmin + i * dist_pr + shift_x
            x1 = xmin + (i + 1) * dist_pr - shift_x

            filtered = list(filter(lambda x: x0 < x[0] < x1, zero_points))

            for num, point in enumerate(filtered):
                point.insert(-4, i+1)
                pt.append(point[2:])

        # Add polygons
        if rect == 1:
            poly = QgsVectorLayer("Polygon", "Rect", "memory")
            poly.setCrs(crs)
            pr = poly.dataProvider()
            pr.addAttributes([QgsField("PR", QVariant.Double)])
            poly.updateFields()
            fet = QgsFeature()
            
            for i in range(rect_count):
                fet.setGeometry(QgsGeometry.fromPolygonXY([rects[i]]))
                fet.setAttributes([i+1])
                pr.addFeatures([fet])
            poly.updateExtents()
            QgsProject.instance().addMapLayer(poly)
            self.dlg_UAV.progressBar.setValue(0)
            self.dlg_UAV.progressBar.setFormat(None)
            return

        # Sort
        if 0 <= npDeg <= 30:
            pt.sort(key = lambda x: (x[-5], -x[-3]))
        elif -30 <= npDeg < 0:
            pt.sort(key = lambda x: (x[-5], x[-3]))
        else:
            pt.sort(key = lambda x: (x[-5], x[-4]))


        # Add points
        if proc == 0:
            pnt = QgsVectorLayer('Point', layer.name() + '_Num', 'memory')
        elif proc == 3:
            if self.dlg_UAV.process_list.item(3).checkState() != Qt.Checked:
                name_0 = self.vlayer_proc.name()
                pnt = QgsVectorLayer('Point', name_0 + '_Num', 'memory')
            else:
                proc = 4
                self.control_separator(pt, proc, tic)
                return


        pnt.setCrs(crs)
        pr = pnt.dataProvider()

        for i in self.fieldList:
            if i[1] == 10: # String
                pr.addAttributes([QgsField(i[0], QVariant.String, 'string', 0, 0)])
            elif i[1] == 6: # Double
                pr.addAttributes([QgsField(i[0], QVariant.Double, 'double', i[2], i[3])])
            elif i[1] == 2: # Int
                pr.addAttributes([QgsField(i[0], QVariant.Int, 'int', i[2])])
            else:
                pr.addAttributes([QgsField(i[0], i[1])])

        pr.addAttributes([QgsField('PR', QVariant.Int)])
        pnt.updateFields()
        fet = QgsFeature()


        for i, val in enumerate(pt):
            self.progress(i, len(pt), 1000, 'Rendering: ')
            fet.setGeometry(QgsPoint(val[-4], val[-3]))
            #fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(val[-4], val[-3])))
            fet.setAttributes(pt[i][:-4])
            pr.addFeatures([fet])

        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(pt)))
        mboxi.show()
        mboxi.exec_()



    def control_separator(self, data, proc, tic):
        if proc == 0:
            tic = time.perf_counter()
            time_index = self.dlg_UAV.time_CB.currentIndex() - 1
            pr_index = self.dlg_UAV.pr_CB.currentIndex() - 1
        
            try:
                Time = self.data[0][time_index]
            except AttributeError:
                mbox.setText("Нужно загрузить слой в Load Data")
                mbox.show()
                return
    
            if self.dlg_UAV.pr_CB.currentText() == '':
                mbox.setText("Нужно выбрать поле номера профиля в Load Data")
                mbox.show()
                return

            data_sep = self.data

        elif proc == 4:
            fields_count = len(self.fieldList)
            time_index = self.dlg_UAV.time_CB.currentIndex() - 1
            Time = data[0][time_index]

            pr_index = fields_count
            data_sep = [point[:-2] for point in data]

        UAVProcess.timeForm(self, Time, var=0)

        controls = []
        regs = []
        c = 0

        regs.append(data_sep[0])

        time_float = isinstance(data_sep[0][time_index], float)
        time_float = isinstance(data_sep[0][time_index], float) or (isinstance(data_sep[0][time_index], str) and self._is_float_string(data_sep[0][time_index]))
        time_int = isinstance(data_sep[0][time_index], int)

        dist_test = float(self.dlg_UAV.dist_test.text())
        print(time_float)

        if time_float or time_int: # RAD
            for i in range(1, len(data_sep)):
                self.progress(i, len(data_sep), 1000, 'Separate: ')
    
                TimeSec0 = regs[-1][time_index]
                TimeSec1 = data_sep[i][time_index]
                dist = ((data_sep[i][-2] - regs[-1][-2])**2 + (data_sep[i][-1] - regs[-1][-1])**2)**0.5
    
                if abs(float(TimeSec1)) - abs(float(TimeSec0)) > 12 and data_sep[i][pr_index] == data_sep[i-1][pr_index] and dist <= dist_test:
                    controls.append(data_sep[i])
                else:
                    regs.append(data_sep[i])
        else: # MAG
            for i in range(1, len(data_sep)):
                self.progress(i, len(data_sep), 1000, 'Separate: ')
    
                TimeSec0 = datetime.strptime(regs[-1][time_index], self.time_form).timestamp()
                TimeSec1 = datetime.strptime(data_sep[i][time_index], self.time_form).timestamp()
                dist = ((data_sep[i][-2] - regs[-1][-2])**2 + (data_sep[i][-1] - regs[-1][-1])**2)**0.5
    
                if abs(TimeSec1) - abs(TimeSec0) > 3 and data_sep[i][pr_index] == data_sep[i-1][pr_index] and dist <= dist_test:
                    controls.append(data_sep[i])
                else:
                    regs.append(data_sep[i])


        # Filter dist
        c = 0
        section = []
        controls_cut = []
        if len(controls) > 0:
            controls_cut.append(controls[0])
            for i in range(1, len(controls)):
                if controls[i][pr_index] == controls[c][pr_index]:
                    dist = ((controls[i][-2] - controls[i-1][-2])**2 + (controls[i][-1] - controls[i-1][-1])**2)**0.5
                    if dist < 60:
                        controls_cut.append(controls[i])
                    else:
                        if len(controls_cut) > 1:
                            segment_dist = ((controls_cut[-1][-2] - controls_cut[0][-2])**2 + (controls_cut[-1][-1] - controls_cut[0][-1])**2)**0.5
                            if segment_dist > 299:
                                section.extend(controls_cut)
                        controls_cut = []
                else:
                    if len(controls_cut) > 1:
                        segment_dist = ((controls_cut[-1][-2] - controls_cut[0][-2])**2 + (controls_cut[-1][-1] - controls_cut[0][-1])**2)**0.5
                        if segment_dist > 299:
                            section.extend(controls_cut)
                    controls_cut = []
                    c = i

        # Add points
        if proc == 0:
            crs = self.vlayer.crs()
            name_save_r = self.vlayer.name()+ '_Reg'
            name_save_c = self.vlayer.name()+ '_Ctrl'
            pnt = QgsVectorLayer('Point', name_save_r, 'memory')
            pnt_ctrls = QgsVectorLayer('Point', name_save_c, 'memory')
        elif proc == 4:
            name_0 = self.vlayer_proc.name()
            name_save_r = name_0 + '_Reg'
            name_save_c = name_0 + '_Ctrl'
            pnt = QgsVectorLayer('Point', name_save_r, 'memory')
            pnt_ctrls = QgsVectorLayer('Point', name_save_c, 'memory')
            
            if self.dlg_UAV.process_list.item(1).checkState() != Qt.Checked:
                crs = self.vlayer.crs()
            else:
                crs = self.dlg_UAV.mQgsProjectionSelectionWidget.crs()

        names_save = [name_save_r, name_save_c]
        
        pnt.setCrs(crs)
        pnt_ctrls.setCrs(crs)
        pr = pnt.dataProvider()
        pr_ctrls = pnt_ctrls.dataProvider()

        for i in self.fieldList:
            if i[1] == 10: # String
                pr.addAttributes([QgsField(i[0], QVariant.String, 'string', 0, 0)])
                pr_ctrls.addAttributes([QgsField(i[0], QVariant.String, 'string', 0, 0)])
            elif i[1] == 6: # Double
                pr.addAttributes([QgsField(i[0], QVariant.Double, 'double', i[2], i[3])])
                pr_ctrls.addAttributes([QgsField(i[0], QVariant.Double, 'double', i[2], i[3])])
            elif i[1] == 2: # Int
                pr.addAttributes([QgsField(i[0], QVariant.Int, 'int', i[2])])
                pr_ctrls.addAttributes([QgsField(i[0], QVariant.Int, 'int', i[2])])
            else:
                pr.addAttributes([QgsField(i[0], i[1])])
                pr_ctrls.addAttributes([QgsField(i[0], i[1])])

        if proc == 4:
            pr.addAttributes([QgsField('PR', QVariant.Int)])
            pr_ctrls.addAttributes([QgsField('PR', QVariant.Int)])

        pnt.updateFields()
        pnt_ctrls.updateFields()
        fet = QgsFeature()


        for i, val in enumerate(regs):
            self.progress(i, len(regs), 1000, 'Rendering: ')
            fet.setGeometry(QgsPoint(val[-2], val[-1]))
            fet.setAttributes(val[:-2])
            pr.addFeatures([fet])
        pnt.updateExtents()

        for i, val in enumerate(section):
            fet.setGeometry(QgsPoint(val[-2], val[-1]))
            fet.setAttributes(val[:-2])
            pr_ctrls.addFeatures([fet])
        pnt_ctrls.updateExtents()

        QgsProject.instance().addMapLayer(pnt)
        QgsProject.instance().addMapLayer(pnt_ctrls)

        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(regs)))
        mboxi.show()
        mboxi.exec_()

    def _is_float_string(self, value):
        """Проверяет, можно ли преобразовать строку в float"""
        try:
            float(value)
            return True
        except (ValueError, TypeError):
            return False


    def plots(self, arg):

        PR = int(self.dlg_UAV.pr_num.text())
        step_interp = float(self.dlg_UAV.step_interp.text())
        step_average = int(self.dlg_UAV.Spline_CB.currentText())

        if self.dlg_UAV.pr_CB.currentText() == '':
            mbox.setText("Нужно загрузить слой в Load Data и выбрать столбец профиля")
            mbox.show()
            return
        if self.dlg_UAV.field1_CB.currentText() == '':
            mbox.setText("Нужно загрузить слой в Load Data и выбрать столбец поля")
            mbox.show()
            return

        pr_index = self.dlg_UAV.pr_CB.currentIndex() - 1
        T0_index = self.dlg_UAV.field1_CB.currentIndex() - 1
        T1_index = self.dlg_UAV.field2_CB.currentIndex() - 1
        alt1_index = self.dlg_UAV.alt1_CB.currentIndex() - 1
        alt2_index = self.dlg_UAV.alt2_CB.currentIndex() - 1

        # List profiles
        if not self.dlg_UAV.save_all_check.isChecked():
            profiles = [PR]
        else:
            directory = self.dlg_UAV.mQgsFileWidget_2.filePath()
            profiles = []
            profiles.append(self.data[0][pr_index])
            for i in range(1, len(self.data)):
                if self.data[i][pr_index] != self.data[i-1][pr_index]:
                    profiles.append(self.data[i][pr_index])

        # Сycle PR  
        for p, profile in enumerate(profiles):
            self.dlg_UAV.progressBar.setValue(int((p/len(profiles))*100))
            self.dlg_UAV.progressBar.setFormat('Profile № ' + str(p))
            QApplication.processEvents()

            filtered = list(filter(lambda x: x[pr_index] == profile, self.data))
            if len(filtered) == 0:
                mbox.setText('Профиль ' + str(profile) + ' не найден')
                mbox.show()
                return
    
            # Lists of self.data
            T0, T1, dists, alt1, alt2 = [], [], [], [], []
            for i in filtered:
                T0.append(i[T0_index])
                T1.append(i[T1_index])
                alt1.append(i[alt1_index])
                alt2.append(i[alt2_index])
                if len(T0) == 1:
                    x0, y0 = i[-2], i[-1]
                x1, y1 = i[-2], i[-1]
                dist = ((x1 - x0)**2 + (y1 - y0)**2)**0.5 
                dists.append(dist)
    
            # Interpolate
            T0_interp, T1_interp, dists_interp, alt_interp, alt2_interp = [], [], [], [], []
            try:
                dist_interp1 = interp.interp1d(dists, T0, fill_value = "extrapolate")
                dist_interp2 = interp.interp1d(dists, T1, fill_value = "extrapolate")
                dist_interp3 = interp.interp1d(dists, alt1, fill_value = "extrapolate")
                dist_interp4 = interp.interp1d(dists, alt2, fill_value = "extrapolate")
                for i in range(int(dists[-1] // step_interp + 1)):
                    interpolated = dist_interp1(step_interp * i)
                    T0_interp.append(interpolated)
                       
                    interpolated = dist_interp2(step_interp * i)
                    T1_interp.append(interpolated)
                    dists_interp.append(step_interp * i)
                        
                    interpolated = dist_interp3(step_interp * i)
                    alt_interp.append(interpolated)
                        
                    interpolated = dist_interp4(step_interp * i)
                    alt2_interp.append(interpolated)
            except IndexError:
                mbox.setText("Нет выбранного значения в таблице")
                mbox.show()
                return
    
            # Average
            T0_aver = pd.Series(T0_interp).rolling(window=step_average).mean().iloc[step_average-1:].values
            T1_aver = pd.Series(T1_interp).rolling(window=step_average).mean().iloc[step_average-1:].values
   
            summ = 0
            for i in range(len(T0_aver)):
                dev = (T0_aver[i] - T1_aver[i]) ** 2
                summ += dev
            dev = round((summ / len(T0_aver)) ** 0.5, 3)
    
            # Def dists
            for i in range(int(step_average // 2)):
                del dists_interp[0]
                del dists_interp[-1]
                del alt_interp[0]
                del alt_interp[-1]
                del alt2_interp[0]
                del alt2_interp[-1]

            # Remove empty
            arr = [T0_aver[0]]
            ccc = 0
            for i in range(1, len(T0_aver)):
                delta = round(T0_aver[i] - T0_aver[i-1], 8)
                arr.append(delta)

            arr = np.array(arr, dtype='float64')
            m = stats.mode(arr)[0]
            m_n = stats.mode(arr)[1]


            if m_n > 10:
                mask = arr == m
            else:
                mask = np.zeros_like(arr, dtype=bool)

            T0_aver_0 = np.where(~mask, T0_aver, np.nan)
            T1_aver_0 = np.where(~mask, T1_aver, np.nan)
            alt_interp_0 = np.where(~mask, alt_interp, np.nan)
            alt2_interp_0 = np.where(~mask, alt2_interp, np.nan)


            # Plots
            fig, axs = plt.subplots(1, 1, figsize = [18, 12]) # Figure
            if alt1_index != -1:
                axs1 = axs.twinx()
                axs1.plot(dists_interp, alt_interp_0, linewidth = 1, color='g', label = self.fieldList[alt1_index][0])
                axs1.set_ylabel(self.fieldList[alt1_index][0], fontsize = 25, rotation = 90, labelpad = 24)
                axs1.tick_params(axis='both', which='major', labelsize=18)
                axs1.legend(loc=(0.9, 1.001), fontsize = 16)
            if alt2_index != -1:
                axs1.plot(dists_interp, alt2_interp_0, linewidth = 1, color='m', label = self.fieldList[alt2_index][0])
                axs1.legend(loc=(0.9, 1.001), fontsize = 16)
    
            plt.subplots_adjust(hspace=.20)
            axs.plot(dists_interp, T0_aver_0, linewidth = 1.8, label = 'Рядовые измерения')
            if T1_index != -1:
                axs.plot(dists_interp, T1_aver_0, linewidth = 1.8, label = 'Контрольные измерения')
                plt.suptitle('Контрольный профиль №' + str(profile) + ' (СКО = ' + str(dev) + ')', y = 0.94, fontsize = 20)
            else:
                plt.suptitle('Профиль №' + str(profile), y = 0.94, fontsize = 30)
            axs.set_xlim(dists_interp[0], dists_interp[-1])
            axs.set_xlabel('Расстояние, м', labelpad = 20, fontsize = 25)
            axs.set_ylabel('T, нТл', fontsize = 25, rotation = 90, labelpad = 24)
            axs.tick_params(axis='both', which='major', labelsize=18)
            axs.legend(loc=(0, 1), fontsize = 16)
            plt.grid(True)
            if not self.dlg_UAV.save_all_check.isChecked():
                plt.show()
            else:
                plt.savefig(directory + '/' + 'PR_' + str(profile))
                plt.close()
                plt.clf()

        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)




    def export(self):
        if self.dlg_UAV.mQgsFileWidget_5.filePath() != '':
            # Получаем поля слоя
            file_path = self.dlg_UAV.mQgsFileWidget_5.filePath()
            layer = self.iface.activeLayer()
            fields = layer.fields()
            field_names = [field.name() for field in fields]

            if not file_path.endswith('.txt'):
                file_path += '.txt'
            
            # Открываем файл для записи
            with open(file_path, 'w', encoding='utf-8') as txt_file:
                # Записываем заголовки (разделённые пробелами, с новой строкой в конце)
                txt_file.write('\t'.join(field_names) + '\n')
                
                # Записываем атрибуты каждой фичи (каждая на новой строке, без пустых строк)
                for feature in layer.getFeatures():
                    attributes = feature.attributes()
                    # Преобразуем атрибуты в строки и объединяем пробелами
                    row_str = '\t'.join(str(attr) for attr in attributes)
                    txt_file.write(row_str + '\n')

        mboxi.setText('Готово')
        mboxi.show()
        mboxi.exec_()


    #--------------------------------------------------------------------------
    # Run plugin
    #--------------------------------------------------------------------------

    def run_UAV(self):
        self.dlg_UAV = UAVProcessDialog(parent = self.iface.mainWindow())

        self.time_form = None
        self.time_form_var = None

        # show the dialog
        self.dlg_UAV.show()
        self.dlg_UAV.progressBar.setFormat(None)

        # Set current index in Time CB
        self.cfg_path = self.plugin_dir + '/cfg.ini'

        with open(self.cfg_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            try:
                self.dlg_UAV.d1_CB.setCurrentIndex(int(cfg[0][1]))
                self.dlg_UAV.d2_CB.setCurrentIndex(int(cfg[1][1]))
                self.dlg_UAV.d3_CB.setCurrentIndex(int(cfg[2][1]))
                self.dlg_UAV.t1_CB.setCurrentIndex(int(cfg[3][1]))
                self.dlg_UAV.t2_CB.setCurrentIndex(int(cfg[4][1]))
                self.dlg_UAV.t3_CB.setCurrentIndex(int(cfg[5][1]))
                self.dlg_UAV.t4_CB.setCurrentIndex(int(cfg[6][1]))
                self.dlg_UAV.d1_var_CB.setCurrentIndex(int(cfg[0][1]))
                self.dlg_UAV.d2_var_CB.setCurrentIndex(int(cfg[1][1]))
                self.dlg_UAV.d3_var_CB.setCurrentIndex(int(cfg[2][1]))
                self.dlg_UAV.t1_var_CB.setCurrentIndex(int(cfg[3][1]))
                self.dlg_UAV.t2_var_CB.setCurrentIndex(int(cfg[4][1]))
                self.dlg_UAV.t3_var_CB.setCurrentIndex(int(cfg[5][1]))
                self.dlg_UAV.t4_var_CB.setCurrentIndex(int(cfg[6][1]))
            except IndexError:
                pass



        self.dlg_UAV.d1_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.d2_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.d3_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.t1_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.t2_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.t3_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.t4_CB.currentIndexChanged.connect(self.change_cfg)
        
        self.dlg_UAV.d1_var_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.d2_var_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.d3_var_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.t1_var_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.t2_var_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.t3_var_CB.currentIndexChanged.connect(self.change_cfg)
        self.dlg_UAV.t4_var_CB.currentIndexChanged.connect(self.change_cfg)
        
        

        # Buttons click
        self.dlg_UAV.run_process.clicked.connect(lambda: self.run_process(data = 0, proc = 0, tic = 0))
        self.dlg_UAV.open_files.clicked.connect(self.load_files)
        self.dlg_UAV.merge_coord_time.clicked.connect(self.merge_coord_time)
        self.dlg_UAV.variations.clicked.connect(lambda: self.variations(data = 0, proc = 0, tic = 0))
        self.dlg_UAV.check_var.clicked.connect(self.check_var)
        self.dlg_UAV.add_IGRF.clicked.connect(self.add_IGRF)
        self.dlg_UAV.load_layer_data.clicked.connect(self.load_layer_data)
        self.dlg_UAV.cut_points.clicked.connect(lambda: self.cut_points(data = 0, proc = 0, tic = 0))
        self.dlg_UAV.LinesFromPoints.clicked.connect(self.LinesFromPoints)
        self.dlg_UAV.Control.clicked.connect(self.Control)
        self.dlg_UAV.control_separator.clicked.connect(lambda: self.control_separator(data = 0, proc = 0, tic = 0))
        self.dlg_UAV.add_rects.clicked.connect(lambda: self.add_n_profile(data = 0, proc = 0, tic = 0, rect = 1))
        self.dlg_UAV.add_n_PR.clicked.connect(lambda: self.add_n_profile(data = 0, proc = 0, tic = 0, rect = 0))
        self.dlg_UAV.plot.clicked.connect(self.plots)
        self.dlg_UAV.export_txt.clicked.connect(self.export)
        # Filters
        self.dlg_UAV.MapLayer_CB.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.dlg_UAV.MapLayer_control_CB.setFilters(QgsMapLayerProxyModel.PointLayer)


    def change_cfg(self):
        with open(self.cfg_path, 'w') as f:
            f.write('mag_f1' + '\t' + str(self.dlg_UAV.d1_CB.currentIndex()) + '\n')
            f.write('mag_f2' + '\t' + str(self.dlg_UAV.d2_CB.currentIndex()) + '\n')
            f.write('mag_f3' + '\t' + str(self.dlg_UAV.d3_CB.currentIndex()) + '\n')
            f.write('mag_f4' + '\t' + str(self.dlg_UAV.t1_CB.currentIndex()) + '\n')
            f.write('mag_f5' + '\t' + str(self.dlg_UAV.t2_CB.currentIndex()) + '\n')
            f.write('mag_f6' + '\t' + str(self.dlg_UAV.t3_CB.currentIndex()) + '\n')
            f.write('mag_f7' + '\t' + str(self.dlg_UAV.t4_CB.currentIndex()) + '\n')
            f.write('var_f1' + '\t' + str(self.dlg_UAV.d1_var_CB.currentIndex()) + '\n')
            f.write('var_f2' + '\t' + str(self.dlg_UAV.d2_var_CB.currentIndex()) + '\n')
            f.write('var_f3' + '\t' + str(self.dlg_UAV.d3_var_CB.currentIndex()) + '\n')
            f.write('var_f4' + '\t' + str(self.dlg_UAV.t1_var_CB.currentIndex()) + '\n')
            f.write('var_f5' + '\t' + str(self.dlg_UAV.t2_var_CB.currentIndex()) + '\n')
            f.write('var_f6' + '\t' + str(self.dlg_UAV.t3_var_CB.currentIndex()) + '\n')
            f.write('var_f7' + '\t' + str(self.dlg_UAV.t4_var_CB.currentIndex()) + '\n')