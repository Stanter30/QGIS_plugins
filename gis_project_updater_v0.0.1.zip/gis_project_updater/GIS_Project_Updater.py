# -*- coding: utf-8 -*-
"""
        begin                : 2024-03-06

"""
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import *

from .resources import *

# Import the code for the dialog
from .GIS_Project_Updater_dialog import GIS_Project_UpdaterDialog
import shutil
import os.path
import glob

class GIS_Project_Updater:

    def __init__(self, iface):

        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'GIS_Project_Updater_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&GIS Project Updater')
        self.toolbar = self.iface.addToolBar(u'GIS Project Updater')
        self.toolbar.setObjectName(u'GIS Project Updater')

        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message): return QCoreApplication.translate('GIS_Project_Updater', message)


    def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)

        return action

    def initGui(self):
        icon_path = ':/plugins/GIS_Project_Updater/icon.png'
        self.add_action(icon_path, text=self.tr(u'GIS Project Updater'), callback=self.run, parent=self.iface.mainWindow())

        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&GIS Project Updater'), action)
            self.iface.removeToolBarIcon(action)



    #----------------------------------------------------------------------
    def export_prj_OK(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Замена проекта")
        mbox.setText("Заменить проект в указанной папке?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.export_prj)
        mbox.exec_()


    def export_prj(self, buttonOK):
        if buttonOK.text() == "OK":

            dst_path = self.dlg_prj_updater.s_FileWidget.filePath()+'\\*'
            home_path = QgsProject.instance().homePath()
            
            slash_cnt = dst_path.count('\\')
            print(dst_path, slash_cnt)

            files = glob.glob(dst_path)

            if dst_path != '\\*' and slash_cnt > 2:

                for f in files:
                    print('del', f)
                    os.remove(f)

                os.rmdir(dst_path[:-1])

                print('home', home_path)
                shutil.copytree(home_path, dst_path[:-1])

            else: print('Not file')

        else: print('Reject')

    #----------------------------------------------------------------------

    def run(self):

        self.dlg_prj_updater = GIS_Project_UpdaterDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_prj_updater.show()
        # Buttons click
        self.dlg_prj_updater.export_prj.clicked.connect(self.export_prj_OK)
