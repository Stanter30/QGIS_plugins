# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Geoprocess
                                 A QGIS plugin
 Geoprocess
                              -------------------
        begin                : 2024-04-01
        git sha              : $Format:%H$
        copyright            : (C) 2024 by SSG
        email                : stanter30@gmail.com
 ***************************************************************************/
"""
import win32gui
import win32con
from win32gui import GetWindowText, GetForegroundWindow
import win32com.client
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time
import os.path
import math
import processing
from qgis.analysis import *
from qgis.core import *
from qgis.gui import *
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .Geoprocess_dialog import profilesDialog
from .Geoprocess_dialog import export_waypointsDialog



class Message:

    def msg(self):
        mbox=QMessageBox()
        mbox.setWindowTitle("Неправильный источник данных")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

    def info(self):
        mbox=QMessageBox()
        mbox.setWindowTitle("Информация")
        mbox.setIcon(QMessageBox.Information)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

mbox=Message().msg()
mboxi=Message().info()

class Geoprocess:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor."""
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'Geoprocess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Waypointer')
        self.toolbar = self.iface.addToolBar(u'Waypointer')
        self.toolbar.setObjectName(u'Waypointer')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None

        self.pt = None


    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        return QCoreApplication.translate('Waypointer', message)


    def tool_gridding(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def tool_layers_operations(self, icon2_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon2_path)
        action2 = QAction(icon, text, parent)
        action2.triggered.connect(callback)
        action2.setEnabled(enabled_flag)

        if status_tip is not None:
            action2.setStatusTip(status_tip)
        if whats_this is not None:
            action2.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action2)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action2)

        self.actions.append(action2)
        return action2


    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/Waypointer/gridding.png'
        icon2_path = ':/plugins/Waypointer/layers.png'
        self.tool_gridding(icon_path, text=self.tr(u'Waypointer_Creation Lines'), callback=self.run_gridding, parent=self.iface.mainWindow())
        self.tool_layers_operations(icon2_path, text=self.tr(u'Waypointer_Export'), callback=self.run_layers_operations, parent=self.iface.mainWindow())


        # will be set False in run()
        self.first_start = True

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&Waypointer'), action)
            self.iface.removeToolBarIcon(action)

    def rejectDlg(self):
        self.dlg.close()

    def Exit(self):
        self.iface.messageBar().clearWidgets()

    def progress(self, i, f, proc_freq, proc_text):
        if i % proc_freq == 0:
            try:
                self.dlg_grid.progressBar.setValue(int((i/f)*100))
                self.dlg_grid.progressBar.setFormat(proc_text + str(int((i/f)*100)) + ' %')
            except:
                self.dlg_export.progressBar.setValue(int((i/f)*100))
                self.dlg_export.progressBar.setFormat(proc_text + str(int((i/f)*100)) + ' %')
            QApplication.processEvents()
    #--------------------------------------------------------------------------
    #--------------------------------------------------------------------------
    # First Window
    #--------------------------------------------------------------------------

    def CreatePoints(self):
        point0 = QgsVectorLayer("Point", "Home_Point", "memory")
        crs = QgsProject.instance().crs()
        point0.setCrs(crs)
        point0.updateExtents()
        QgsProject.instance().addMapLayer(point0)
        point0.startEditing()
        # Push add line
        hwnd = win32gui.FindWindow(None, 'Building profiles')
        parent_hwnd = win32gui.GetParent(hwnd)
        text_parent = win32gui.GetWindowText(parent_hwnd)
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.AppActivate(text_parent)
        shell.SendKeys("^.")

    def CreateLines(self):
        lin0 = QgsVectorLayer("LineString", "New_Line", "memory")
        crs = QgsProject.instance().crs()
        lin0.setCrs(crs)
        lin0.dataProvider().addAttributes([QgsField('ID', QVariant.Int)])
        lin0.updateExtents()
        QgsProject.instance().addMapLayer(lin0)
        lin0.startEditing()
        # Push add line
        hwnd = win32gui.FindWindow(None, 'Building profiles')
        parent_hwnd = win32gui.GetParent(hwnd)
        text_parent = win32gui.GetWindowText(parent_hwnd)
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.AppActivate(text_parent)
        shell.SendKeys("^.")


    def Grid(self):
        
        path = self.dlg_grid.mQgsFileWidget.filePath()
        layer_template = self.dlg_grid.layer_template.text()       

        if self.check_correct() == -1: return

        num_fly = int(self.dlg_grid.num_fly.text())
        layer_counter_start = int(self.dlg_grid.layer_counter.text()) - 1
        num_points = int(self.dlg_grid.num_points.text())
        radius = float(self.dlg_grid.radius.text())

        try:
            hp_layer = self.dlg_grid.home_point.currentLayer()
    
            features = hp_layer.getFeatures()
        
            for feature in features:
                geom = feature.geometry()
                geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
                if geomSingleType:
                    x = geom.asPoint().x()
                    y = geom.asPoint().y()
                else:
                    x = geom.asMultiPoint()[0][0]
                    y = geom.asMultiPoint()[0][1]
                break
    
            hp_coord = (x, y)
        except:
            pass

        Step_PK = float(self.dlg_grid.Step_PK.text())
        Step_PR = float(self.dlg_grid.Step_PR.text())
        Num_PR = int(self.dlg_grid.Num_PR.text())
        OffsetPK = float(self.dlg_grid.Offset_PK.text())
        OffsetPR = float(self.dlg_grid.Offset_PR.text())
        len_pr = float(self.dlg_grid.len_pr.text())
        Start_PK = 1
        Start_PR = 1
        SNP = 1
        SNPk = 1
        line_layer = self.iface.activeLayer()

        if line_layer==None or line_layer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выделен слой с линией-вектором"); mbox.exec_(); return
        if line_layer.featureCount() == 0:
            mbox.setText("Нужно нарисовать линию-вектор в активном слое линий"); mbox.exec_(); return
        features = line_layer.getFeatures()

        for feature in features:
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.LineGeometry:
                if geomSingleType:
                    xy=geom.asPolyline()
                    point1x=xy[0][0]; point1y=xy[0][1]; point2x=xy[1][0]; point2y=xy[1][1];
                    lenght=geom.length()
                else:
                    xy=geom.asMultiPolyline()
                    point1x=xy[0][0].x(); point1y=xy[0][0].y(); point2x=xy[0][1].x(); point2y=xy[0][1].y();
                    lenght=geom.length()
            else:
                mbox.setText("Должен быть выделен слой с линией-вектором")
                mbox.show()
                mbox.exec_()
                return


        fly_shift = Step_PR * Num_PR
        for k in range(num_fly):
            # Calculate Values
            layer_counter_start += 1
            d = point2x-point1x
            h = point2y-point1y
            cosa = d/lenght
            sina = h/lenght
            point1xx = (point1x+OffsetPK*cosa)+(OffsetPR+fly_shift*k)*sina
            point1yy = (point1y+OffsetPK*sina)-(OffsetPR+fly_shift*k)*cosa
            point2xx = (point2x+OffsetPK*cosa)+(OffsetPR+fly_shift*k)*sina
            point2yy = (point2y+OffsetPK*sina)-(OffsetPR+fly_shift*k)*cosa

            num_PK = int(abs(len_pr) / abs(Step_PK))+1
            
            f = num_PK * Num_PR

    
            crs = line_layer.crs()
            targetCrs = QgsCoordinateReferenceSystem('EPSG:4326')
            transformContext = QgsProject.instance().transformContext()
            xform = QgsCoordinateTransform(crs, targetCrs, transformContext)
    

            # Calculate and Add attributes in array
            gridArray = []

            for j in range (1, Num_PR+1):
                for i in range (1, num_PK+1):
                    self.progress(j*num_PK+i, f, 10000, 'Calc: ')
    
                    XX = (point1xx+(i-1)*Step_PK*cosa)+Step_PR*sina*(j-1)
                    YY = (point1yy+(i-1)*Step_PK*sina)-Step_PR*cosa*(j-1)
    
                    a = QgsPointXY(XX, YY)
                    xyTarget = xform.transform(a)
                    lat = xyTarget.y()
                    lon = xyTarget.x()
    
                    gridArray.append((j, i, XX, YY, lon, lat))


            # Create 8
            theta1 = np.linspace(0 , 2 * np.pi, num_points)
            theta2 = np.linspace(2 * np.pi, 0, num_points)

            x1 = radius * np.cos(theta1)
            y1 = radius * np.sin(theta1)
            x2 = radius * np.cos(theta2)
            y2 = radius * np.sin(theta2) 

            cos_turn = math.cos(math.radians(180))
            sin_turn = math.sin(math.radians(180))

            xy1 = []
            xy2 = []
            for i in range(len(x1)):
                xy1.append((x1[i], y1[i]))
                xy2.append((x2[i]*cos_turn + y2[i]*sin_turn, y2[i]*cos_turn - x2[i]*sin_turn))


            try:
                arr_8 = [xy1, xy2]
                xy = []
            
                for j in range(2):
                    for i in range(len(x1)):
                        x_t = hp_coord[0] + arr_8[j][i][0] + radius*2*j
                        y_t = hp_coord[1] + arr_8[j][i][1]
                        a = QgsPointXY(x_t, y_t)
                        xyTarget = xform.transform(a)
                        lat = xyTarget.y()
                        lon = xyTarget.x()
        
                        xy.append((x_t-radius, y_t, lon, lat))
    
                    if j == 0:
                        del xy[-1]
    
                a = QgsPointXY(xy[-1][0], xy[-1][1]+50)
                xyTarget = xform.transform(a)
                lat = xyTarget.y()
                lon = xyTarget.x()
    
                xy.append((xy[-1][0], xy[-1][1]+50, lon, lat))

            except:
                pass

                            
            # Create new Layer
            layer_name = layer_template + str(layer_counter_start) 
            grid_layer = QgsVectorLayer("Point", layer_name, "memory")
    
            pr = grid_layer.dataProvider()
            crs = line_layer.crs()
            if crs.authid() == "EPSG:4326":
                mbox.setText("Нельзя построить в системе координат WGS 84\nСистема координат слоя должна быть прямоугольной")
                mbox.show()
                mbox.exec_()
                return
            grid_layer.setCrs(crs)
    
            pr.addAttributes([QgsField('Name', QVariant.String), 
                              QgsField('PR', QVariant.Int),
                              QgsField('PK', QVariant.Int),
                              QgsField('ELEV', QVariant.Double,'double', 20, 3),
                              QgsField('LON', QVariant.Double,'double', 20, 7),
                              QgsField('LAT', QVariant.Double,'double', 20, 7),
                              QgsField('ROUTE', QVariant.Int),
                              ])
    
            grid_layer.updateFields()
    

            # Add attributes in new Layer
            fets = []
            if self.dlg_grid.build_8.isChecked():
                for i, val in enumerate(xy):
                    fet = QgsFeature()
                    fet.setGeometry(QgsPoint(val[0], val[1]))
                    attrs = ['∞', 0, i, None, val[2], val[3], 82]

                    fet.setAttributes(attrs)
                    fets.append(fet)
    

            for i, pt in enumerate(gridArray):
                self.progress(i, f, 5000, 'Rendering: ')

                fet = QgsFeature()
                fet.setGeometry(QgsPoint(pt[2], pt[3]))
                Name = str(pt[0])+', '+str(pt[1])
                attrs = [Name, pt[0], pt[1], None, pt[4], pt[5], 16]
                fet.setAttributes(attrs)
                fets.append(fet)


            pr.addFeatures(fets)
            grid_layer.updateExtents()
    
            QgsProject.instance().addMapLayer(grid_layer)


            if self.dlg_grid.save_check_btn.isChecked():
                options = QgsVectorFileWriter.SaveVectorOptions()
                options.driverName = "ESRI Shapefile"
                options.layerName = grid_layer.name()
                QgsVectorFileWriter.writeAsVectorFormatV3(grid_layer, path + '\\' + layer_name + '.shp', QgsCoordinateTransformContext(), options)
                vlayer = QgsVectorLayer(path + '\\' + layer_name + '.shp', layer_name, "ogr")
                QgsProject.instance().removeMapLayer(grid_layer)
                QgsProject.instance().addMapLayer(vlayer)


        if self.dlg_grid.remove_line_check_btn.isChecked():
            QgsProject.instance().removeMapLayer(line_layer)
        else:
            self.iface.setActiveLayer(line_layer)


        self.dlg_grid.progressBar.setValue(0)
        self.dlg_grid.progressBar.setFormat(None)
        self.iface.messageBar().pushMessage("Grid points created success", level=Qgis.Success, duration=5)


    #--------------------------------------------------------------------------
    # Second Window
    #--------------------------------------------------------------------------

    def import_layer(self, lay_index):
        print('import_layer')
        data = []
        fieldList = []

        if lay_index is False:
            vlayer = self.dlg_export.input_layer_CB.currentLayer()
        else:
            vlayer = self.dlg_export.input_layer_CB.layer(lay_index)
            print(lay_index)
            


        [fieldList.append(field.name()) for field in vlayer.fields()]
        features = vlayer.getFeatures()
        f = vlayer.featureCount()
        data.append(fieldList)

        crs = vlayer.crs()
        targetCrs = QgsCoordinateReferenceSystem('EPSG:4326')
        transformContext = QgsProject.instance().transformContext()
        xform = QgsCoordinateTransform(crs, targetCrs, transformContext)

        for i, feature in enumerate(features):
            self.progress(i, f, 500, 'Read Layer: ')

            attrs = feature.attributes()

            geom = feature.geometry()
            xy = geom.asPoint()

            x = xy.x()
            y = xy.y()

            xy_wgs = xform.transform(QgsPointXY(x, y))

            x_wgs = xy_wgs.x()
            y_wgs = xy_wgs.y()

            strAttrs = []
            for attr in attrs:
                try:
                    strAttrs.append(str(round(attr, 7)))
                except:
                    strAttrs.append(str(attr))

            strAttrs.append(str(x_wgs))
            strAttrs.append(str(y_wgs))

            data.append(strAttrs)

        vert = []
        for i in range(len(data)):
            vert.append(str(i+1))


        self.dlg_export.tableWidget.setRowCount(len(data)-1)
        self.dlg_export.tableWidget.setColumnCount(len(data[0]))
        self.dlg_export.tableWidget.setHorizontalHeaderLabels(data[0])
        self.dlg_export.tableWidget.setVerticalHeaderLabels(vert)

        for i in range(1, len(data)):
            self.progress(i, f, 500, 'Fill Table: ')
            self.dlg_export.tableWidget.setItem(i-1, 0, QTableWidgetItem(data[i][0]))
            self.dlg_export.tableWidget.setItem(i-1, 1, QTableWidgetItem(data[i][1]))
            self.dlg_export.tableWidget.setItem(i-1, 2, QTableWidgetItem(data[i][2]))
            self.dlg_export.tableWidget.setItem(i-1, 3, QTableWidgetItem(data[i][3]))
            self.dlg_export.tableWidget.setItem(i-1, 4, QTableWidgetItem(data[i][-2]))
            self.dlg_export.tableWidget.setItem(i-1, 5, QTableWidgetItem(data[i][-1]))
            self.dlg_export.tableWidget.setItem(i-1, 6, QTableWidgetItem(data[i][6]))

        self.dlg_export.tableWidget.setColumnWidth(0, 35)
        self.dlg_export.tableWidget.setColumnWidth(1, 35)
        self.dlg_export.tableWidget.setColumnWidth(2, 35)
        self.dlg_export.tableWidget.setColumnWidth(3, 60)
        self.dlg_export.tableWidget.setColumnWidth(4, 70)
        self.dlg_export.tableWidget.setColumnWidth(5, 70)
        self.dlg_export.tableWidget.setColumnWidth(6, 50)

        self.dlg_export.progressBar.setValue(0)
        self.dlg_export.progressBar.setFormat(None)


    def bind_elev(self, lay_index):
        print('bind')

        rlayer = self.dlg_export.input_rlayer_CB.currentLayer()

        if lay_index is False:
            vlayer = self.dlg_export.input_layer_CB.currentLayer()
        else:
            vlayer = self.dlg_export.input_layer_CB.layer(lay_index)

        test_none = 0

        features = vlayer.getFeatures()

        vlayer.startEditing()
        

        if vlayer.type() != QgsMapLayerType.VectorLayer:
            mbox.setText("Должен быть выбран векторный слой с точками")
            mbox.show()
            mbox.exec_()
            return

        vpr = vlayer.dataProvider()
        rpr = rlayer.dataProvider()

        for i, field in enumerate(vlayer.fields()):
            if field.name() == "ELEV":
                f_elev = i
            if field.name() == "LON":
                f_lon = i
            if field.name() == "LAT":
                f_lat = i
    
        for i in features:
            geom = i.geometry()
            if geom.type() == 1 or geom.type() == 2:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                mbox.exec_()
                return
            features = vlayer.getFeatures()
            break
        if not rlayer.type() == QgsMapLayerType.RasterLayer:
            mbox.setText("В окне DEM должен быть выбран растровый слой рельефа")
            mbox.show()
            mbox.exec_()
            return
        vcrs = vlayer.crs()
        rcrs = rlayer.crs()
        if vcrs != rcrs:
            mbox.setText("Проекции растра и точек не совпадают")
            mbox.show()
            mbox.exec_()
            return
        path = vpr.dataSourceUri()
        pp = path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
        if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
            mbox.setText("Работает только с шейп файлами")
            mbox.show()
            mbox.exec_()
            return

        xy = geom.asPoint()
        try:
            ident = rpr.identify(QgsPointXY(xy.x(), xy.y()), 1)
            IFV = 1
        except:
            IFV = QgsRaster.IdentifyFormatValue


        targetCrs = QgsCoordinateReferenceSystem('EPSG:4326')
        transformContext = QgsProject.instance().transformContext()
        xform = QgsCoordinateTransform(vcrs, targetCrs, transformContext)

        for i, feature in enumerate(features):
            geom = feature.geometry()
    
            xy = geom.asPoint()
            x = xy.x()
            y = xy.y()
            ident = rpr.identify(QgsPointXY(x, y), IFV)

            xy_wgs = xform.transform(QgsPointXY(x, y))
            x_wgs = xy_wgs.x()
            y_wgs = xy_wgs.y()

            if ident.results()=={}:
                mbox.setText("Недоступный источник растра во вкладке DEM")
                mbox.show()
                mbox.exec_()
                return
    
            z = ident.results()[1]
    
            if z == None:
                test_none = 1
    
            ids = feature.id()
            attr_value = {f_elev : z, f_lon : x_wgs, f_lat : y_wgs}
            vpr.changeAttributeValues({ids:attr_value})

        vlayer.updateFields()
        vlayer.commitChanges()
        self.dlg_export.progressBar.setValue(0)

        self.import_layer(lay_index)
        
        if test_none == 1:
            mbox.setText("Есть пустые значения высот")
            mbox.show()
            mbox.exec_()
            return

        if lay_index is False:
            self.iface.messageBar().pushMessage("Elevation added in current layer", level=Qgis.Success, duration=4)



    def modify(self, cor):
        print('modify')

        self.mod = 1

        home_alt = float(self.dlg_export.home_alt.text())
        flight_alt = float(self.dlg_export.flight_alt.text())

        # Get input data
        col_cnt = self.dlg_export.tableWidget.columnCount()
        row_cnt = self.dlg_export.tableWidget.rowCount()

        input_data_dir = []
        input_data_rev = []
        new_dir = 0
        for i in range(row_cnt):
            line = []
            for j in range(col_cnt):
                item = self.dlg_export.tableWidget.item(i, j).text()
                line.append(item)

            if int(line[1]) % 2 != 0:
                if new_dir == 1:
                    input_data_rev.reverse()
                    input_data_dir.extend(input_data_rev)
                    input_data_rev = []
                input_data_dir.append(line)
                new_dir = 0
            elif int(line[1]) % 2 == 0:

                new_dir = 1
                input_data_rev.append(line)

        if new_dir == 1:
            input_data_rev.reverse()
            input_data_dir.extend(input_data_rev)


        # Modify data for waypoint
        vert = []
        self.modify_data = []
        self.modify_data.append(('0', '1', '0', '16', '0', '0', '0', '0', '0', '0', '0', '1'))
        for i, line in enumerate(input_data_dir):
            if cor == None:
                alt_rel = str(round(float(line[3]) - home_alt + flight_alt, 3))
            else:
                alt_rel = str(cor[i])
            self.modify_data.append((str(i), '0', '3', line[6], '0', '0', '0', '0', line[5], line[4], alt_rel, '1'))
            vert.append(str(i+1))
        self.modify_data.append((str(i+1), '0', '3', '20', '0', '0', '0', '0', '0', '0', '0', '1'))


        self.dlg_export.tableWidget_2.setRowCount(len(self.modify_data))
        self.dlg_export.tableWidget_2.setColumnCount(12)
        self.dlg_export.tableWidget_2.setVerticalHeaderLabels(vert)
        #self.dlg_export.tableWidget_2.horizontalHeader().setDefaultSectionSize(60)    
        for i in range(8):
            self.dlg_export.tableWidget_2.setColumnWidth(i, 30)
        self.dlg_export.tableWidget_2.setColumnWidth(8, 70)
        self.dlg_export.tableWidget_2.setColumnWidth(9, 70)
        self.dlg_export.tableWidget_2.setColumnWidth(10, 50)
        self.dlg_export.tableWidget_2.setColumnWidth(11, 30)

        for i in range(len(self.modify_data)):
            for j in range(len(self.modify_data[0])):
                self.dlg_export.tableWidget_2.setItem(i, j, QTableWidgetItem(self.modify_data[i][j]))



    def export_waypoints(self, lay_index):
        print('export')
        if self.dlg_export.mQgsFileWidget.filePath() == '':
            mbox.setText("Нужно выбрать путь к папке для сохранения")
            mbox.show()
            mbox.exec_()
            return

        if lay_index is False:
            vlayer_name = self.dlg_export.input_layer_CB.currentLayer().name()
        else:
            vlayer_name = self.dlg_export.input_layer_CB.layer(lay_index).name()

        directory = self.dlg_export.mQgsFileWidget.filePath() + '/'
        path = directory + vlayer_name + '.waypoints'

        strr = 'QGC WPL 110' 

        with open(path, 'w', encoding = 'Windows-1251') as f:
            f.write(strr + '\n')
            line = []
            for i in self.modify_data:
                line = '\t'.join(i)
                f.write(line + '\n')

        self.iface.messageBar().pushMessage("Waypoints file has been created", level=Qgis.Success, duration=6)


    def correction(self, lay_index):

        self.modify(cor=None)

        if self.mod == 1:
            dist_arr, dist_delta, dem_alt, fly_alt, minmax, delta_alt, delta_alt_0, delta_grad, skew, nools, minmax_grad, delta_grad_mm = self.fly_alt(lay_index)
    
            coef = float(self.dlg_export.correct_coef.text())
            flight_alt_0 = float(self.dlg_export.flight_alt.text())
            home_alt = float(self.dlg_export.home_alt.text())
    
            fly_alt_correct = []

            cnt = 0
            for i in range(1, len(skew)-1):
                x0 = skew[i-1]
                x1 = skew[i]
                x2 = skew[i+1]
                

                if x2 < 0 and x0 < 0 and x1 < 0:
                    d = round((abs((x2+x0)/2))-abs(x1), 3)
                elif x2 > 0 and x0 > 0 and x1 > 0:
                    d = round((abs((x2+x0)/2))-abs(x1), 3)
                elif x2 < 0 and x0 < 0 and x1 > 0:
                    d = round((abs((x2+x0)/2))+abs(x1), 3)
                elif x2 > 0 and x0 > 0 and x1 < 0:
                    d = round((abs((x2+x0)/2))+abs(x1), 3)
                else:
                    d = round((abs((x2+x0)/2))-abs(x1), 3)


                test = round((abs(x2)-abs(x0))/2, 3)
                
                if abs(d) > 29 and abs(test) < 15:
                    cnt += 1
                    skew[i] = round((x2+x0)/2, 3)
                else:
                    cnt = 0

    
            for i, alt in enumerate(skew):
                correct_item = (flight_alt_0*coef/100) * abs(alt/100)
                fly_alt_correct.append(round(fly_alt[i]+correct_item-home_alt, 3))


            if self.dlg_export.smooth_btn.isChecked():
                fly_alt_correct_spline = []
                fly_alt_correct_spline.append(np.mean([fly_alt_correct[0], fly_alt_correct[1]]))
                for i in range(1, len(fly_alt_correct)-1):
                    val = np.mean([fly_alt_correct[i-1], fly_alt_correct[i], fly_alt_correct[i+1]])
                    fly_alt_correct_spline.append(val)
                fly_alt_correct_spline.append(np.mean([fly_alt_correct[-1], fly_alt_correct[-2]]))
                fly_alt_correct = fly_alt_correct_spline
        
    
            self.modify(fly_alt_correct)

            self.mod = 0
        else:
            pass


    def fly_alt(self, lay_index):
        # Get input data
        home_alt = float(self.dlg_export.home_alt.text())
        col_cnt = self.dlg_export.tableWidget.columnCount()
        row_cnt = self.dlg_export.tableWidget.rowCount()
        col_2_cnt = self.dlg_export.tableWidget_2.columnCount()
        row_2_cnt = self.dlg_export.tableWidget_2.rowCount()

        if lay_index is False:
            layer = self.dlg_export.input_layer_CB.currentLayer()
        else:
            layer = self.dlg_export.input_layer_CB.layer(lay_index)



        # dist
        crs = QgsCoordinateReferenceSystem('EPSG:4326')
        targetCrs = layer.crs()
        transformContext = QgsProject.instance().transformContext()
        xform = QgsCoordinateTransform(crs, targetCrs, transformContext)

        gridArray = []
        for i in range(1, row_2_cnt-1):
            line = []
            for j in range(col_2_cnt):
                item = self.dlg_export.tableWidget_2.item(i, j).text()
                line.append(item)


            a = QgsPointXY(float(line[-3]), float(line[-4]))

            xyTarget = xform.transform(a)

            XX = xyTarget.x()
            YY = xyTarget.y()

            gridArray.append((XX, YY, float(line[-2]))) 

        
        dist_arr = [0]
        dist_delta = [0]

        dist = 0
        for i in range(1, len(gridArray)):
            x0 = gridArray[i-1][0]
            x1 = gridArray[i][0]
            y0 = gridArray[i-1][1]
            y1 = gridArray[i][1]
            dist += ((x1-x0)**2+(y1-y0)**2)**0.5
            dist_arr.append(round(dist, 1))
            dist_delta.append(((x1-x0)**2+(y1-y0)**2)**0.5)


        input_data_dir = []
        input_data_rev = []
        new_dir = 0

        for i in range(row_cnt):
            line = []
            for j in range(col_cnt):
                item = self.dlg_export.tableWidget.item(i, j).text()
                line.append(item)

            if int(line[1]) % 2 != 0:
                if new_dir == 1:
                    input_data_rev.reverse()
                    input_data_dir.extend(input_data_rev)
                    input_data_rev = []
                input_data_dir.append((int(line[1]), int(line[2]), float(line[3])))
                new_dir = 0
            elif int(line[1]) % 2 == 0:

                new_dir = 1
                input_data_rev.append((int(line[1]), int(line[2]), float(line[3])))

        if new_dir == 1:
            input_data_rev.reverse()
            input_data_dir.extend(input_data_rev)

        dem_alt = []
        fly_alt = []


        dem_alt = [round(i[2], 3) for i in input_data_dir]

        for i in range(1, row_2_cnt-1):
            line = []
            for j in range(col_2_cnt):
                item = self.dlg_export.tableWidget_2.item(i, j).text()
                line.append(item)

            fly_alt.append(round((home_alt + float(line[-2])), 3))

        minmax = [min(dem_alt), max(dem_alt), min(fly_alt), max(fly_alt)]
        delta_alt = max(minmax) - min(minmax)

        delta_alt_0 = [0]
        delta_grad = [0]
        skew = [0]
        nools = [0]

        for i in range(1, len(fly_alt)):
            alt0 = fly_alt[i-1]
            alt1 = fly_alt[i]
            kat_x = dist_delta[i]
            kat_y = alt1 - alt0
            if kat_x == 0:
                kat_x = 0.00000001
            tga = kat_y / kat_x
            deg = math.degrees(math.atan(tga))
            delta_grad.append(round(deg, 2))
            skew.append(round((kat_y/dist_delta[i])*100, 2))
            delta_alt_0.append(round(alt1 - alt0, 3))
            nools.append(0)
        

        minmax_grad = [min(delta_grad), max(delta_grad)]
        delta_grad_mm = max(delta_grad) - min(delta_grad)

        return dist_arr, dist_delta, dem_alt, fly_alt, minmax, delta_alt, delta_alt_0, delta_grad, skew, nools, minmax_grad, delta_grad_mm
        

    def graphics(self):
        
        dist_arr, dist_delta, dem_alt, fly_alt, minmax, delta_alt, delta_alt_0, delta_grad, skew, nools, minmax_grad, delta_grad_mm = self.fly_alt(False)

        dist_fly = 0
        for i, val in enumerate(dist_delta):
            d = (val**2 + delta_alt_0[i]**2)**0.5
            dist_fly += d

        dist_fly = int(dist_fly)


        # Plot
        plt.style.use("dark_background")

        for param in ['text.color', 'axes.labelcolor', 'xtick.color', 'ytick.color']:
            plt.rcParams[param] = '0.9'  # very light grey
        
        for param in ['figure.facecolor', 'axes.facecolor', 'savefig.facecolor']:
            plt.rcParams[param] = '#212946'  # bluish dark grey
        
        colors_1 = [
            '#08F7FE',  # teal/cyan
            '#00ff41',  # matrix green
        ]

        colors_rev_1 = [
            '#00ff41',  # matrix green
            '#08F7FE',  # teal/cyan
        ]

        colors_2 = [
            '#F5D300',  # yellow
            '#FE53BB',  # pink
        ]

        colors_rev_2 = [
            '#FE53BB',  # pink
            '#F5D300',  # yellow
        ]
        



        df = pd.DataFrame({'DEM': dem_alt, 'fly' : fly_alt, 'dist': dist_arr})
        dfx = pd.DataFrame({'DEM': dem_alt, 'fly' : fly_alt})

        df_grad = pd.DataFrame({'incline': delta_grad, 'flat' : nools, 'dist': dist_arr})
        df_grad_x = pd.DataFrame({'incline': delta_grad, 'flat' : nools})

        fig = None
        fig, ax = plt.subplots(2, 1, figsize=[12, 6], sharex=True)
        plt.subplots_adjust(top=0.97, bottom=0.1, left=0.06, right=0.96, hspace=0.1)
        
        
        # Redraw the data with low alpha and slighty increased linewidth:
        n_shades = 10
        diff_linewidth = 1.05
        alpha_value = 0.3 / n_shades
        
        # First plot
        df.plot(x='dist', y=['fly', 'DEM'], marker='o', markersize=0.8, linewidth=0.5, color=colors_1, ax=ax[0])

        for n in range(1, n_shades+1):
        
            df.plot(x='dist', 
                    y=['fly', 'DEM'],
                    marker='o',
                    markersize=2,
                    linewidth=1+(diff_linewidth*n),
                    alpha=alpha_value,
                    legend=False,
                    ax=ax[0],
                    color=colors_1)
            
        # Color the areas below the lines:
        for column, color in zip(dfx, colors_rev_1):

            ax[0].fill_between(x=df['dist'].values,
                            y1=dfx[column].values,
                            y2=[0] * len(dfx),
                            color=color,
                            alpha=0.1)
            

        ax[0].annotate('Fly dist: ' + str(dist_fly), xy=(0.02, 0.92), xycoords='axes fraction', fontsize=11)
        ax[0].grid(color='#2A3459')
        ax[0].set_ylabel('Высота, м')
            
        ax[0].set_xlim([0, dist_arr[-1]])
        ax[0].set_ylim(min(minmax)-delta_alt/20, max(minmax)+delta_alt/20)



        # Second plot
        df_grad.plot(x='dist', y=['flat', 'incline'], marker='o', markersize=0.8, linewidth=0.5, color=colors_2, ax=ax[1])

        for n in range(1, n_shades+1):
        
            df_grad.plot(x='dist', 
                    y=['flat', 'incline'],
                    marker='o',
                    markersize=2,
                    linewidth=1+(diff_linewidth*n),
                    alpha=alpha_value,
                    legend=False,
                    ax=ax[1],
                    color=colors_2)
            
        # Color the areas below the lines:
        for column, color in zip(df_grad_x, colors_rev_2):

            ax[1].fill_between(x=df_grad['dist'].values,
                            y1=df_grad_x[column].values,
                            y2=[0] * len(df_grad_x),
                            color=color,
                            alpha=0.1)
            
        ax[1].grid(color='#2A3459')
        ax[1].set_ylabel('Угол, °')
            
        ax[1].set_xlim([0, dist_arr[-1]])
        ax[1].set_ylim(minmax_grad[0]-delta_grad_mm/20, minmax_grad[1]+delta_grad_mm/20)
        
        plt.show()


    def select_layers(self):
        layer = self.dlg_export.input_layer_CB.currentLayer()
        dem = self.dlg_export.input_rlayer_CB.currentLayer()

        layers_cnt = self.dlg_export.input_layer_CB.count()

        layers = [(self.dlg_export.input_layer_CB.layer(i), self.dlg_export.input_layer_CB.layer(i).id()) for i in range(layers_cnt)]

        
        label = QtWidgets.QLabel()
        label.setText('Выбор слоев')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        self.dlg = QDialog()

        layout = QVBoxLayout()
        self.dlg.setWindowTitle("Layer selection")
        self.dlg.resize(400, 600)
        layout.addWidget(label)

        # List widget 
        self.listWidget = QListWidget()
        
        self.listWidget.setSelectionMode(3)

        for i in range(layers_cnt):
            self.listWidget.addItem(layers[i][0].name())


        layout.addWidget(self.listWidget)
        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)

        btnBox.accepted.connect(self.select_layers_OK)
        btnBox.rejected.connect(self.rejectDlg)
        
        layout.addWidget(btnBox)
        self.dlg.setLayout(layout)
        self.dlg.exec_()

    def select_layers_OK(self):
        self.dlg.close()

        selectedLayers = self.listWidget.selectedItems()

        all_items = [self.listWidget.item(x) for x in range(self.listWidget.count())]

        lay_indexes = []
        for i, item in enumerate(all_items):
            item.isSelected()
            if item.isSelected() == True:
                lay_indexes.append(i)


        for i in lay_indexes:
            self.bind_elev(i)
            self.modify(cor=None)

            if self.dlg_export.correct_selection.isChecked():
                self.correction(i)

            self.export_waypoints(i)


        mboxi.setText(str(len(lay_indexes)) + " waypoints files saved")
        mboxi.show()
        mboxi.exec_()





    #--------------------------------------------------------------------------
    def run_gridding(self):
        self.dlg_grid = profilesDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_grid.show()
        # Buttons click
        self.dlg_grid.Grid.clicked.connect(self.Grid)
        self.dlg_grid.CreateLine.clicked.connect(self.CreateLines)
        self.dlg_grid.CreatePoint.clicked.connect(self.CreatePoints)

        self.dlg_grid.home_point.setFilters(QgsMapLayerProxyModel.PointLayer)

        self.cfg_lines_path = self.plugin_dir + '/cfg_lines.ini'
        self.cfg_lines_path_path = self.plugin_dir + '/cfg_lines_path.ini'

    
        with open(self.cfg_lines_path_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            try:
                self.dlg_grid.mQgsFileWidget.setFilePath(cfg[0][1])
            except IndexError:
                pass

        with open(self.cfg_lines_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            try:
                self.dlg_grid.Step_PK.setText(cfg[0][1])
                self.dlg_grid.len_pr.setText(cfg[1][1])
                self.dlg_grid.Offset_PK.setText(cfg[2][1])
                self.dlg_grid.Step_PR.setText(cfg[3][1])
                self.dlg_grid.Num_PR.setText(cfg[4][1])
                self.dlg_grid.Offset_PR.setText(cfg[5][1])
                self.dlg_grid.num_fly.setText(cfg[6][1])
                self.dlg_grid.layer_template.setText(cfg[7][1])
                self.dlg_grid.layer_counter.setText(cfg[8][1])
                self.dlg_grid.save_check_btn.setCheckState(int(cfg[9][1]))
                self.dlg_grid.remove_line_check_btn.setCheckState(int(cfg[10][1]))
                self.dlg_grid.build_8.setCheckState(int(cfg[11][1]))
                self.dlg_grid.num_points.setText(cfg[12][1])
                self.dlg_grid.radius.setText(cfg[13][1])
            except IndexError:
                pass

        self.dlg_grid.Step_PK.textChanged.connect(self.check_correct)
        self.dlg_grid.len_pr.textChanged.connect(self.check_correct)
        self.dlg_grid.Offset_PK.textChanged.connect(self.check_correct)
        self.dlg_grid.Step_PR.textChanged.connect(self.check_correct)
        self.dlg_grid.Num_PR.textChanged.connect(self.check_correct)
        self.dlg_grid.Offset_PR.textChanged.connect(self.check_correct)
        self.dlg_grid.num_fly.textChanged.connect(self.check_correct)
        self.dlg_grid.layer_template.textChanged.connect(self.check_correct)
        self.dlg_grid.layer_counter.textChanged.connect(self.check_correct)
        self.dlg_grid.save_check_btn.stateChanged.connect(self.check_correct)
        self.dlg_grid.remove_line_check_btn.stateChanged.connect(self.check_correct)
        self.dlg_grid.build_8.stateChanged.connect(self.check_correct)
        self.dlg_grid.num_points.textChanged.connect(self.check_correct)
        self.dlg_grid.radius.textChanged.connect(self.check_correct)

        self.dlg_grid.closeEvent = self.closeEvent



    def run_layers_operations(self):
        self.dlg_export = export_waypointsDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_export.show()
        # Buttons click
        self.dlg_export.import_layer.clicked.connect(self.import_layer)
        self.dlg_export.bind_elev.clicked.connect(self.bind_elev)
        self.dlg_export.modify.clicked.connect(lambda: self.modify(cor=None))
        self.dlg_export.export_layer.clicked.connect(self.export_waypoints)
        self.dlg_export.graphic.clicked.connect(self.graphics)
        self.dlg_export.correct.clicked.connect(self.correction)
        self.dlg_export.mass_export.clicked.connect(self.select_layers)

        self.dlg_export.input_layer_CB.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.dlg_export.input_rlayer_CB.setFilters(QgsMapLayerProxyModel.RasterLayer)


        self.cfg_path = self.plugin_dir + '/cfg.ini'

        with open(self.cfg_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            try:
                self.dlg_export.home_alt.setText(cfg[0][1])
                self.dlg_export.flight_alt.setText(cfg[1][1])
                self.dlg_export.correct_coef.setText(cfg[2][1])
                self.dlg_export.mQgsFileWidget.setFilePath(cfg[3][1])
            except IndexError:
                pass

        self.dlg_export.home_alt.textChanged.connect(self.check_correct_2)
        self.dlg_export.flight_alt.textChanged.connect(self.check_correct_2)
        self.dlg_export.correct_coef.textChanged.connect(self.check_correct_2)

        self.dlg_export.closeEvent = self.closeEvent2


    def check_correct(self):
        if not self.dlg_grid.Step_PK.text().isdigit():
            try: a = float(self.dlg_grid.Step_PK.text())
            except: self.dlg_grid.Step_PK.setText('0')
            return
        if not self.dlg_grid.Step_PR.text().isdigit():
            try: a = float(self.dlg_grid.Step_PR.text())
            except: self.dlg_grid.Step_PR.setText('0')
            return
        if not self.dlg_grid.Num_PR.text().isdigit():
            self.dlg_grid.Num_PR.setText('0')
            return
        if not self.dlg_grid.len_pr.text().isdigit():
            try: a = float(self.dlg_grid.len_pr.text())
            except: self.dlg_grid.len_pr.setText('0')
            return
        if not self.dlg_grid.Offset_PK.text().isdigit():
            try: a = float(self.dlg_grid.Offset_PK.text())
            except: self.dlg_grid.Offset_PK.setText('0')
            return
        if not self.dlg_grid.Offset_PR.text().isdigit():
            try: a = float(self.dlg_grid.Offset_PR.text())
            except: self.dlg_grid.Offset_PR.setText('0')
            return
        if not self.dlg_grid.num_fly.text().isdigit():
            self.dlg_grid.num_fly.setText('0')
            return
        if not self.dlg_grid.layer_counter.text().isdigit():
            self.dlg_grid.layer_counter.setText('0')
            return
        if not self.dlg_grid.num_points.text().isdigit():
            self.dlg_grid.num_points.setText('0')
            return
        if not self.dlg_grid.radius.text().isdigit():
            try: a = float(self.dlg_grid.radius.text())
            except: self.dlg_grid.radius.setText('0')
            return

    def check_correct_2(self):
        if not self.dlg_export.home_alt.text().isdigit():
            try: a = float(self.dlg_export.home_alt.text())
            except: self.dlg_export.home_alt.setText('0')
            return
        if not self.dlg_export.flight_alt.text().isdigit():
            try: a = float(self.dlg_export.flight_alt.text())
            except: self.dlg_export.flight_alt.setText('0')
            return
        if not self.dlg_export.correct_coef.text().isdigit():
            try: a = float(self.dlg_export.correct_coef.text())
            except: self.dlg_export.correct_coef.setText('0')
            return

            
    def closeEvent(self, event):
        print("Close 1")
        with open(self.cfg_lines_path, 'w') as f:
            f.write('Step_PK' + '\t' + self.dlg_grid.Step_PK.text() + '\n')
            f.write('len_pr' + '\t' + self.dlg_grid.len_pr.text() + '\n')
            f.write('Offset_PK' + '\t' + self.dlg_grid.Offset_PK.text() + '\n')
            f.write('Step_PR' + '\t' + self.dlg_grid.Step_PR.text() + '\n')
            f.write('Num_PR' + '\t' + self.dlg_grid.Num_PR.text() + '\n')
            f.write('Offset_PR' + '\t' + self.dlg_grid.Offset_PR.text() + '\n')
            f.write('num_fly' + '\t' + self.dlg_grid.num_fly.text() + '\n')
            f.write('layer_template' + '\t' + self.dlg_grid.layer_template.text() + '\n')
            f.write('layer_counter' + '\t' + self.dlg_grid.layer_counter.text() + '\n')
            f.write('save_check' + '\t' + str(self.dlg_grid.save_check_btn.checkState()) + '\n')
            f.write('remove_check' + '\t' + str(self.dlg_grid.remove_line_check_btn.checkState()) + '\n')
            f.write('build_check' + '\t' + str(self.dlg_grid.build_8.checkState()) + '\n')
            f.write('num_points' + '\t' + self.dlg_grid.num_points.text() + '\n')
            f.write('radius' + '\t' + self.dlg_grid.radius.text() + '\n')

        with open(self.cfg_lines_path_path, 'w') as f:
            f.write('path' + '\t' + self.dlg_grid.mQgsFileWidget.filePath() + '\n')

    def closeEvent2(self, event):
        print("Close 2")
        with open(self.cfg_path, 'w') as f:
            f.write('home_alt' + '\t' + self.dlg_export.home_alt.text() + '\n')
            f.write('flight_alt' + '\t' + self.dlg_export.flight_alt.text() + '\n')
            f.write('coef' + '\t' + self.dlg_export.correct_coef.text() + '\n')
            f.write('path' + '\t' + self.dlg_export.mQgsFileWidget.filePath() + '\n')
