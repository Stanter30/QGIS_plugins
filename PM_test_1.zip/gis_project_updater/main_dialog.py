# -*- coding: utf-8 -*-

import os

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets

FORM_CLASS_main, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'main.ui'))
FORM_CLASS_fact, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'fact.ui'))

class main_dialog(QtWidgets.QDialog, FORM_CLASS_main):
    def __init__(self, parent=None):
        super(main_dialog, self).__init__(parent)
        self.setupUi(self)

class fact_create_dialog(QtWidgets.QDialog, FORM_CLASS_fact):
    def __init__(self, parent=None):
        super(fact_create_dialog, self).__init__(parent)
        self.setupUi(self)

