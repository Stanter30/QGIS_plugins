# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QAction

from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPoint,
    QgsPointXY,
    QgsRasterLayer,
    QgsFillSymbol,
    QgsLineSymbol,
    QgsSingleSymbolRenderer,
    QgsCoordinateReferenceSystem
)
import processing
# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .RasterSlicer_dialog import RasterSlicerDialog
import os.path


class RasterSlicer:

    def __init__(self, iface):

        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'RasterSlicer_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&RasterSlicer')

        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        return QCoreApplication.translate('RasterSlicer', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):


        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Adds plugin icon to Plugins toolbar
            self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/RasterSlicer/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'RasterSlicer'),
            callback=self.run,
            parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&RasterSlicer'),
                action)
            self.iface.removeToolBarIcon(action)



    #////////////////////////////////////////////////////////////////////////////////////
    def func(self):

        self.rlayer = self.iface.activeLayer()
        window_size = int(self.dlg.lineEdit.text())

        # Получаем размеры пикселей
        pixel_size_x = self.rlayer.rasterUnitsPerPixelX()  # Размер пикселя по оси X
        pixel_size_y = self.rlayer.rasterUnitsPerPixelY()  # Размер пикселя по оси Y

        extent = self.rlayer.extent()

        min_x = extent.xMinimum()  # Минимальная координата X
        max_x = extent.xMaximum()  # Максимальная координата X
        min_y = extent.yMinimum()  # Минимальная координата Y
        max_y = extent.yMaximum()  # Максимальная координата Y

        center_coords = (min_x + 0.12425 + (max_x - min_x)/2, min_y + 0.3215 + (max_y - min_y)/2)

        bottom_left_x = center_coords[0]  # Минимальная X
        bottom_left_y = center_coords[1]  # Минимальная Y
        width = pixel_size_x * window_size + pixel_size_x - 0.2  # Ширина полигона
        height = pixel_size_y * window_size + pixel_size_x - 0.2 # Высота полигона

        print(width, height)

        crs = self.rlayer.crs()
        self.layer = QgsVectorLayer(f"Polygon?crs={crs.authid()}", "Temporary Polygon", "memory")

        # Определяем полигон с заданными размерами
        points = [
        QgsPointXY(bottom_left_x, bottom_left_y),
        QgsPointXY(bottom_left_x + width, bottom_left_y),
        QgsPointXY(bottom_left_x + width, bottom_left_y + height),
        QgsPointXY(bottom_left_x, bottom_left_y + height),
        QgsPointXY(bottom_left_x, bottom_left_y)  # Замыкаем полигон
        ]

        polygon = QgsGeometry.fromPolygonXY([points])

        feature = QgsFeature()
        feature.setGeometry(polygon)

        self.layer.dataProvider().addFeatures([feature])
        self.layer.updateExtents()

        rndr = self.layer.renderer()                   # object to change rendering
        sym = rndr.symbol().symbolLayer(0)

        sym.setFillColor(QColor(255, 255, 255, 0))

        sym.setStrokeWidth(1.5)
        sym.setStrokeColor(QColor(255, 0, 0, 255))


        self.layer.triggerRepaint()

        QgsProject.instance().addMapLayer(self.layer)

    def func_2(self):

        crs = self.rlayer.crs().authid()
        parameter = {'INPUT':self.rlayer,'MASK':self.layer,'SOURCE_CRS':QgsCoordinateReferenceSystem(crs),'TARGET_CRS':QgsCoordinateReferenceSystem(crs),'TARGET_EXTENT':None,'NODATA':None,'ALPHA_BAND':False,'CROP_TO_CUTLINE':True,'KEEP_RESOLUTION':False,'SET_RESOLUTION':False,'X_RESOLUTION':None,'Y_RESOLUTION':None,'MULTITHREADING':False,'OPTIONS':None,'DATA_TYPE':0,'EXTRA':'','OUTPUT':'TEMPORARY_OUTPUT'}
        result = processing.run("gdal:cliprasterbymasklayer", parameter)['OUTPUT'] 

        lyr = QgsRasterLayer(result, "Нарезка")
        QgsProject.instance().addMapLayer(lyr)

    #////////////////////////////////////////////////////////////////////////////////////


    def run(self):

        if self.first_start == True:
            self.first_start = False
            self.dlg = RasterSlicerDialog(parent = self.iface.mainWindow())

        self.dlg.btn_1.clicked.connect(self.func)
        self.dlg.btn_2.clicked.connect(self.func_2)


        self.dlg.show()

