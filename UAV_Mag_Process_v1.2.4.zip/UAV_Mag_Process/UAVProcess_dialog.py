# -*- coding: utf-8 -*-
"""
/***************************************************************************
 UAVProcessDialog
                                 A QGIS plugin
 UAVProcess
                             -------------------
        begin                : 2023-08-04
        git sha              : $Format:%H$
        copyright            : (C) 2023 by Tereshkin S.A.
        email                : Stanter30@gmail.com
 ***************************************************************************/
"""

import os

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'UAVProcess_dialog_base.ui'))


class UAVProcessDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent = None):
        """Constructor."""
        super(UAVProcessDialog, self).__init__(parent)
        self.setupUi(self)
