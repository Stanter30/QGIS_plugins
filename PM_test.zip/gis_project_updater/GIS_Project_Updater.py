# -*- coding: utf-8 -*-
"""
        begin                : 2024-03-06

"""
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from PyQt5 import QtGui, QtCore, QtWidgets
from qgis.core import *

from .resources import *

# Import the code for the dialog
from .main_dialog import main_dialog
import os.path
import glob

class GIS_Project_Updater:

    def __init__(self, iface):

        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'GIS_Project_Updater_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&GIS Project Updater')
        self.toolbar = self.iface.addToolBar(u'GIS Project Updater')
        self.toolbar.setObjectName(u'GIS Project Updater')

        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message): return QCoreApplication.translate('GIS_Project_Updater', message)


    def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)

        return action

    def initGui(self):
        icon_path = ':/plugins/GIS_Project_Updater/icon.png'
        self.add_action(icon_path, text=self.tr(u'GIS Project Updater'), callback=self.run, parent=self.iface.mainWindow())

        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&GIS Project Updater'), action)
            self.iface.removeToolBarIcon(action)



    #----------------------------------------------------------------------
    def pushButton(self):
        layer = QgsVectorLayer("Point", "New_Points", "memory")
        crs = QgsProject.instance().crs()
        layer.setCrs(crs)
        layer.updateExtents()
        pr = layer.dataProvider()
        pr.addAttributes([QgsField('Name', QVariant.String)])
        layer.updateFields()
        QgsProject.instance().addMapLayer(layer)


        fields = layer.fields()
        field_index = fields.indexFromName('Name')

        # Widget type
        #config = {'IsMultiline': True, 'UseHtml': False}
        #widget_setup = QgsEditorWidgetSetup('TextEdit', config)
        #layer.setEditorWidgetSetup(field_index, widget_setup)

        list_values = {"red":"1", "green":"2"}
        config = {'map' : list_values}
        widget_setup = QgsEditorWidgetSetup('ValueMap', config)
        layer.setEditorWidgetSetup(field_index, widget_setup)

        # Default value
        default_value = QgsDefaultValue()
        default_value.setExpression("'Your value'")
        layer.setDefaultValueDefinition(field_index, default_value)


    def create_facts(self):
        layer = QgsVectorLayer("Point", "New_Points", "memory")
        crs = QgsProject.instance().crs()
        layer.setCrs(crs)
        layer.updateExtents()
        pr = layer.dataProvider()
        pr.addAttributes([QgsField('Name', QVariant.String)])

        layer.updateFields()
        QgsProject.instance().addMapLayer(layer)

    def add_attr_to_tree(self):
        tree = self.dlg_prj_updater.treeWidget
        tree.setSelectionMode(3)
        tree.setColumnCount(1)
        tree.setHeaderLabels(['Элемент'])

        parent = QtWidgets.QTreeWidgetItem(tree) 
        tree.addTopLevelItem(parent)
        parent.setText(0, 'elem')



    #----------------------------------------------------------------------

    def run(self):

        self.dlg_prj_updater = main_dialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_prj_updater.show()
        # Buttons click
        self.dlg_prj_updater.add_attr.clicked.connect(self.add_attr_to_tree)


        self.dlg_prj_updater.pushButton.clicked.connect(self.pushButton)
        
