# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Geoprocess
                                 A QGIS plugin
 Geoprocess
                              -------------------
        begin                : 2023-04-01
        git sha              : $Format:%H$
        copyright            : (C) 2023 by SSG
        email                : stanter30@gmail.com
 ***************************************************************************/
"""
import wx
import win32gui
import win32con
from win32gui import GetWindowText, GetForegroundWindow
import win32com.client
import subprocess
import sys
import etc
import json
from array import *
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from time import sleep
import operator
import time
import os.path
import math
import processing
from osgeo import osr, gdal, ogr
from operator import itemgetter, attrgetter, methodcaller
from itertools import groupby
from qgis.analysis import *
from qgis.core import *
from qgis.core.additions.edit import edit
from qgis.gui import *
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtCore import QSettings, QTranslator, QVariant, QCoreApplication, Qt, QRectF
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QApplication, QAction, QProgressBar, QMessageBox, QHBoxLayout, QVBoxLayout, QSizePolicy, QPushButton, QDialog, QGridLayout, QDialogButtonBox, QMainWindow, QWidget
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtCore import QThread, QMetaMethod, QObject, pyqtSignal
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QWidget, QPushButton, QApplication, QMainWindow, QMenuBar, QMenu, QAction, QVBoxLayout
from PyQt5.QtWidgets import *
from qgis.gui import QgsLayerTreeView, QgsMapCanvas, QgsMapCanvasItem, QgsMessageBar, QgsVertexMarker, QgsRubberBand

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .Geoprocess_dialog import griddingDialog
from .Geoprocess_dialog import layers_operationsDialog
from .Geoprocess_dialog import geometryDialog
from .Geoprocess_dialog import warpDialog
from .Geoprocess_dialog import classesDialog
from .Geoprocess_dialog import exportDialog


class Message:

    def msg(self):
        mbox=QMessageBox()
        mbox.setWindowTitle("Неправильный источник данных")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

    def info(self):
        mbox=QMessageBox()
        mbox.setWindowTitle("Информация")
        mbox.setIcon(QMessageBox.Information)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

mbox=Message().msg()
mboxi=Message().info()

class Geoprocess:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor."""
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'Geoprocess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&UGT')
        self.toolbar = self.iface.addToolBar(u'UGT')
        self.toolbar.setObjectName(u'UGT')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        return QCoreApplication.translate('UGT', message)


    def tool_gridding(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def tool_layers_operations(self, icon2_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon2_path)
        action2 = QAction(icon, text, parent)
        action2.triggered.connect(callback)
        action2.setEnabled(enabled_flag)

        if status_tip is not None:
            action2.setStatusTip(status_tip)
        if whats_this is not None:
            action2.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action2)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action2)

        self.actions.append(action2)
        return action2

    def tool_geometry(self, icon3_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon3_path)
        action3 = QAction(icon, text, parent)
        action3.triggered.connect(callback)
        action3.setEnabled(enabled_flag)

        if status_tip is not None:
            action3.setStatusTip(status_tip)
        if whats_this is not None:
            action3.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action3)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action3)

        self.actions.append(action3)
        return action3

    def tool_warp(self, icon4_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon4_path)
        action4 = QAction(icon, text, parent)
        action4.triggered.connect(callback)
        action4.setEnabled(enabled_flag)

        if status_tip is not None:
            action4.setStatusTip(status_tip)
        if whats_this is not None:
            action4.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action4)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action4)

        self.actions.append(action4)
        return action4

    def tool_classes(self, icon5_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon5_path)
        action5 = QAction(icon, text, parent)
        action5.triggered.connect(callback)
        action5.setEnabled(enabled_flag)

        if status_tip is not None:
            action5.setStatusTip(status_tip)
        if whats_this is not None:
            action5.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action5)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action5)

        self.actions.append(action5)
        return action5

    def tool_export(self, icon6_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon6_path)
        action6 = QAction(icon, text, parent)
        action6.triggered.connect(callback)
        action6.setEnabled(enabled_flag)

        if status_tip is not None:
            action5.setStatusTip(status_tip)
        if whats_this is not None:
            action5.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action6)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action6)

        self.actions.append(action6)
        return action6

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/Geoprocess/gridding.png'
        icon2_path = ':/plugins/Geoprocess/layers.png'
        icon3_path = ':/plugins/Geoprocess/geometry.png'
        icon4_path = ':/plugins/Geoprocess/warp.png'
        icon5_path = ':/plugins/Geoprocess/classify.png'
        icon6_path = ':/plugins/Geoprocess/export.png'
        self.tool_gridding(icon_path, text=self.tr(u'UGT_Creation Grid'), callback=self.run_gridding, parent=self.iface.mainWindow())
        self.tool_layers_operations(icon2_path, text=self.tr(u'UGT_Layers Operations'), callback=self.run_layers_operations, parent=self.iface.mainWindow())
        self.tool_geometry(icon3_path, text=self.tr(u'UGT_Geometry'), callback=self.run_geometry, parent=self.iface.mainWindow())
        self.tool_warp(icon4_path, text=self.tr(u'UGT_Warp'), callback=self.run_warp, parent=self.iface.mainWindow())
        self.tool_classes(icon5_path, text=self.tr(u'UGT_Classification'), callback=self.run_classes, parent=self.iface.mainWindow())
        self.tool_export(icon6_path, text=self.tr(u'UGT_Export'), callback=self.run_export, parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&Geoprocess'), action)
            self.iface.removeToolBarIcon(action)

    def rejectDlg(self):
        self.dlg.close()

    def Exit(self):
        self.iface.messageBar().clearWidgets()
    #--------------------------------------------------------------------------
    #--------------------------------------------------------------------------
    # Gridding
    #--------------------------------------------------------------------------
    def Grid(self):
        tic = time.perf_counter()
        if self.dlg_grid.groupBox_3D.isChecked():
            Step_Z = float(self.dlg_grid.Step_Z.text())
            Layers_num = int(self.dlg_grid.Layers_num.text())
            MaxZ = float(self.dlg_grid.Max_Z.text())
        else:
            Layers_num = 1
        Prefix = self.dlg_grid.Prefix.text()
        Step_PK = float(self.dlg_grid.Step_PK.text())
        Step_PR = float(self.dlg_grid.Step_PR.text())
        Num_PR = int(self.dlg_grid.Num_PR.text())
        OffsetPK = float(self.dlg_grid.Offset_PK.text())
        OffsetPR = float(self.dlg_grid.Offset_PR.text())
        Start_PK = float(self.dlg_grid.N_First_PK.text())
        Start_PR = self.dlg_grid.N_First_PR.text()
        SNP = self.dlg_grid.Step_N_PR.text()
        SNPk = self.dlg_grid.Step_N_PK.text()
        layer = self.iface.activeLayer()
        if self.dlg_grid.Raster_CB.currentLayer() != None:
            rlayer = self.dlg_grid.Raster_CB.currentLayer()
            rpr = rlayer.dataProvider()
        elif self.dlg_grid.groupBox_3D.isChecked() and not self.dlg_grid.ReliefButton_3.isChecked():
            mbox.setText("Должен быть выбран растр с рельефом в поле DEM"); mbox.exec_(); return
        if layer==None or layer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран слой с линией-вектором"); mbox.exec_(); return
        if layer.featureCount() == 0:
            mbox.setText("Нужно нарисовать линию-вектор в активном слое линий"); mbox.exec_(); return
        features = layer.getFeatures()

        for feature in features:
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.LineGeometry:
                if geomSingleType:
                    xy=geom.asPolyline()
                    point1x=xy[0][0]; point1y=xy[0][1]; point2x=xy[1][0]; point2y=xy[1][1];
                    lenght=geom.length()
                else:
                    xy=geom.asMultiPolyline()
                    point1x=xy[0][0].x(); point1y=xy[0][0].y(); point2x=xy[0][1].x(); point2y=xy[0][1].y();
                    lenght=geom.length()
            else:
                mbox.setText("Должен быть выбран слой с вектором")
                mbox.show()
                mbox.exec_()
                return

        # Calculate Values
        d = point2x-point1x
        h = point2y-point1y
        cosa = d/lenght
        sina = h/lenght
        point1x = (point1x+OffsetPK*cosa)+OffsetPR*sina
        point1y = (point1y+OffsetPK*sina)-OffsetPR*cosa
        point2x = (point2x+OffsetPK*cosa)+OffsetPR*sina
        point2y = (point2y+OffsetPK*sina)-OffsetPR*cosa
        Amount_PK = int(lenght / Step_PK)+1
        
        try:
            ident = rpr.identify(QgsPointXY(point1x, point1y), 1)
            IFV = 1
        except:
            IFV = QgsRaster.IdentifyFormatValue

        f = Amount_PK * Num_PR * Layers_num
        ff = f

        # Calculate and Add attributes in array
        gridArray = list()
        if Layers_num == 1:
            for j in range (1, Num_PR+1):
                for i in range (1, Amount_PK+1):
                    ff -= 1
                    if ff % 10000 == 0:
                        self.dlg_grid.progressBar.setValue(int(((f-ff)/f)*50))
                        QApplication.processEvents()
                    if SNP.isnumeric() and SNPk.isnumeric() and Start_PR.isnumeric():
                        PR = int(float(Start_PR)+j*float(SNP)-1*float(SNP))
                        PK = int(float(Start_PK)+i*float(SNPk)-1*float(SNPk))
                    elif Start_PR.find('-') != -1 and Start_PR[1:].isnumeric():
                        PR = int(float(Start_PR)+j*float(SNP)-1*float(SNP))
                        PK = int(float(Start_PK)+i*float(SNPk)-1*float(SNPk))
                    else:
                        PR = round(float(Start_PR)+j*float(SNP)-1*float(SNP), 6)
                        PK = round(float(Start_PK)+i*float(SNPk)-1*float(SNPk), 6)   
                    XX = (point1x+(i-1)*float(Step_PK)*cosa)+(float(Step_PR)*sina*(j-1))
                    YY = (point1y+(i-1)*float(Step_PK)*sina)-(float(Step_PR)*cosa*(j-1))
                    gridArray.append((PR, PK, XX, YY))
        else:
            for k in range (0, Layers_num):
                for j in range (1, Num_PR+1):
                    for i in range (1, Amount_PK+1):
                        ff -= 1
                        if ff % 10000 == 0:
                            self.dlg_grid.progressBar.setValue(int(((f-ff)/f)*50))
                            QApplication.processEvents()
                        if SNP.isnumeric() and Start_PR.isnumeric():
                            PR = int(float(Start_PR) + j * float(SNP) - 1 * float(SNP))
                        else: 
                            PR = round(float(Start_PR) + j * float(SNP) - 1 * float(SNP), 6)
                        PK = int(Start_PK) + i - 1
                        XX = (point1x+(i-1)*float(Step_PK)*cosa)+(float(Step_PR)*sina*(j-1))
                        YY = (point1y+(i-1)*float(Step_PK)*sina)-(float(Step_PR)*cosa*(j-1))
                        if self.dlg_grid.ReliefButton.isChecked():
                            ident = rpr.identify(QgsPointXY(XX, YY), IFV)
                            z = ident.results()[1]
                            ZZ = z - Step_Z * k
                        elif self.dlg_grid.ReliefButton_2.isChecked():
                            ident = rpr.identify(QgsPointXY(XX, YY), IFV)
                            z = ident.results()[1]
                            ZZ = MaxZ - Step_Z * k
                            if ZZ > z:
                                continue
                        elif self.dlg_grid.ReliefButton_reverse.isChecked():
                            ident = rpr.identify(QgsPointXY(XX, YY), IFV)
                            z = ident.results()[1]
                            ZZ = MaxZ - Step_Z * k
                            if ZZ < z:
                                continue
                        else:
                            ZZ = MaxZ - Step_Z * k
                        gridArray.append((PR, PK, XX, YY, ZZ))
                        
        # Create new Layer
        if Layers_num == 1:
            grid = QgsVectorLayer("Point", "New_Grid", "memory")
        else:
            grid = QgsVectorLayer("PointZ", "New_Grid", "memory")
        pr = grid.dataProvider()
        crs = layer.crs()
        if crs.authid() == "EPSG:4326":
            mbox.setText("Нельзя построить в системе координат WGS 84\nСистема координат слоя должна быть прямоугольной")
            mbox.show()
            mbox.exec_()
            return
        grid.setCrs(crs)
        if Prefix != "":
            pr.addAttributes([QgsField('Name', QVariant.String), 
                              QgsField('PR', QVariant.String),
                              QgsField('PK', QVariant.String),
                              QgsField('X', QVariant.Double,'double', 20, 7),
                              QgsField('Y', QVariant.Double,'double', 20, 7)
                              ])
        elif SNP.isnumeric() and Start_PR.isnumeric():
            pr.addAttributes([QgsField('Name', QVariant.String), 
                              QgsField('PR', QVariant.Int),
                              QgsField('PK', QVariant.Int),
                              QgsField('X', QVariant.Double,'double', 20, 7),
                              QgsField('Y', QVariant.Double,'double', 20, 7)
                              ])
            grid.updateFields()
        else:
            pr.addAttributes([QgsField('Name', QVariant.String), 
                              QgsField('PR', QVariant.Double),
                              QgsField('PK', QVariant.Double),
                              QgsField('X', QVariant.Double,'double', 20, 7),
                              QgsField('Y', QVariant.Double,'double', 20, 7)
                              ])
        if Layers_num != 1:
            pr.addAttributes([QgsField('Zc', QVariant.Double)])
        grid.updateFields()

        # Add attributes in new Layer
        fet = QgsFeature()
        ff = f / 2
        if Layers_num == 1:
            for i in gridArray:
                ff -= 0.5
                if ff % 5000 == 0:
                    self.dlg_grid.progressBar.setValue(int(((f-ff)/f)*100))
                    QApplication.processEvents()
                fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(i[2],i[3])))
                Name = str(i[0])+', '+str(i[1])
                prof = i[0]
                pick = i[1]
                if Prefix != "":
                    Name = Prefix + '-' + (f'{i[0]:04}') + '-' + (f'{i[1]:04}')
                    prof = (f'{i[0]:04}')
                    pick = (f'{i[1]:04}')
                fet.setAttributes([Name, prof, pick, i[2], i[3]])
                pr.addFeatures([fet])
            grid.updateExtents()
        else:
            for i in gridArray:
                ff -= 0.5
                if ff % 5000 == 0:
                    self.dlg_grid.progressBar.setValue(int(((f-ff)/f)*100))
                    QApplication.processEvents()
                fet.setGeometry(QgsPoint(i[2], i[3], i[4]))
                Name = str(i[0])+', '+str(i[1])
                prof = i[0]
                pick = i[1]
                fet.setAttributes([Name, prof, pick, i[2], i[3], i[4]])
                pr.addFeatures([fet])
            grid.updateExtents()
        QgsProject.instance().addMapLayer(grid)
        toc = time.perf_counter()
        print(f"time: {toc - tic:0.3f} секунд")
        self.iface.setActiveLayer(layer)
        self.dlg_grid.progressBar.setValue(int(0))
        self.iface.messageBar().pushMessage("Grid points created success", 
            level=Qgis.Success, duration=5)

    def Insert_Void(self):
        vlayer = self.iface.activeLayer()
        if vlayer == None or vlayer.type() == QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран векторный слой")
            mbox.show()
            mbox.exec_()
            return
        self.items = QgsFieldComboBox()
        self.items.setLayer(vlayer)    

        label = QtWidgets.QLabel()
        label.setText('Поле с высотой ячеек')
        label.setAlignment(Qt.AlignBottom|Qt.AlignHCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        label_2 = QtWidgets.QLabel()
        label_2.setText('Инкремент высот, м')
        label_2.setAlignment(Qt.AlignBottom|Qt.AlignHCenter)
        label_2.setFont(QFont('MS Shell Dlg 2', 10))
        label_3 = QtWidgets.QLabel()
        label_3.setText('Значения')
        label_3.setAlignment(Qt.AlignBottom|Qt.AlignHCenter)
        label_3.setFont(QFont('MS Shell Dlg 2', 10))

        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(self.Insert_VoidOK)
        btnBox.rejected.connect(self.rejectDlg)

        self.LineEdit = QLineEdit()
        self.LineEdit.setAlignment(Qt.AlignCenter)
        self.LineEdit.setText('10')
        self.LineEdit_2 = QLineEdit()
        self.LineEdit_2.setAlignment(Qt.AlignCenter)
        self.LineEdit_2.setText('0')

        gridLayout = QGridLayout()
        gridLayout.setVerticalSpacing(10)
        gridLayout.setHorizontalSpacing(30)
        gridLayout.addWidget(label, 0, 0)
        gridLayout.addWidget(label_2, 0, 1)
        gridLayout.addWidget(label_3, 0, 2)
        gridLayout.addWidget(self.items, 1, 0)
        gridLayout.addWidget(self.LineEdit, 1, 1)
        gridLayout.addWidget(self.LineEdit_2, 1, 2)
        gridLayout.addWidget(btnBox, 2, 2)

        self.dlg = QDialog()
        self.dlg.setWindowTitle("Options")
        self.dlg.resize(350, 100)
        self.dlg.setLayout(gridLayout)
        self.dlg.exec_()

    def Insert_VoidOK(self):
        tic = time.perf_counter()
        self.dlg.close()
        vlayer = self.iface.activeLayer()
        f = vlayer.featureCount()
        features = vlayer.getFeatures()
        ZField = self.items.currentField()
        inc = float(self.LineEdit.text())
        air = self.LineEdit_2.text()
        fieldList = []
        fetList = []
        New_fetList = []
        [fieldList.append(field.name()) for field in vlayer.fields()]
        if not (any(i == "X" for i in fieldList) and any(i == "Y" for i in fieldList)):
            mbox.setText("Нужно выбрать точечный слой содержащий поля X и Y") 
            mbox.exec_() 
            return
        for count, field in enumerate(fieldList):
            if field == ZField:
                Zc_index = count
            elif field == 'X':
                X_index = count
            elif field == 'Y':
                Y_index = count
        ff = f
        for feature in features:
            ff -= 1
            if ff % 1000 == 0:
                self.dlg_grid.progressBar.setValue(int(((f-ff)/f)*50))
                QApplication.processEvents()
            fetList.append(feature.attributes())
        fetList.sort(key=operator.itemgetter(X_index, Y_index, Zc_index), reverse=0) 
        Zarr = np.array([s[Zc_index] for s in fetList])
        Zarr = [round(float(x), 3) for x in Zarr]
        maxZc = float(np.max(Zarr))
        features = vlayer.getFeatures()
         # Define Zc0
        for count, fet in enumerate(fetList):
            if count == len(fetList)-1:
                break
            if not (fetList[count+1][X_index]==fetList[count][X_index] and fetList[count+1][Y_index]==fetList[count][Y_index]):
                relief_Fet = float(fetList[count][Zc_index])
                while relief_Fet < maxZc+inc:
                    relief_Fet += inc
                    New_fetList.append((fetList[count][X_index], fetList[count][Y_index], relief_Fet))
         #Create points layer
        pnt = QgsVectorLayer("PointZ", "New_points", "memory")
        crs = vlayer.crs()
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        [pr.addAttributes([QgsField(field, QVariant.String)]) for field in fieldList]
        pnt.updateFields()
        fet = QgsFeature()
         # Insert first
        ff = f/2
        for i in range(len(fetList)):
            ff -= 0.5
            if ff % 1000 == 0:
                self.dlg_grid.progressBar.setValue(int(((f-ff)/f)*100))
                QApplication.processEvents()
            attrs = fetList[i]
            fet.setGeometry(QgsPoint(float(fetList[i][X_index]), float(fetList[i][Y_index]), float(fetList[i][Zc_index])))
            fet.setAttributes(attrs)
            pr.addFeatures([fet])
        pnt.updateExtents()
         # Insert Void
        ff = f
        for j in range(len(New_fetList)):
            ff -= 1
            if ff % 1000 == 0:
                self.dlg_grid.progressBar.setValue(int(((f-ff)/f)*100/len(fieldList)))
                QApplication.processEvents()
            attrs=[]
            for i in range(len(fieldList)):
                if fieldList[i] == 'X':
                    attrs.extend([New_fetList[j][0]])
                elif fieldList[i] == 'Y':
                    attrs.extend([New_fetList[j][1]])
                elif fieldList[i] == ZField:
                    attrs.extend([New_fetList[j][2]])
                else:
                    attrs.extend([air])
            fet.setGeometry(QgsPoint(New_fetList[j][0], New_fetList[j][1], New_fetList[j][2]))
            fet.setAttributes(attrs)
            pr.addFeatures([fet])
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_grid.progressBar.setValue(int(0))
        toc = time.perf_counter()
        ttt=f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt)
        mboxi.show()
        mboxi.exec_()

    #--------------------------------------------------------------------------
    # Layers
    #--------------------------------------------------------------------------
    def CreatePoints(self):
        point0 = QgsVectorLayer("Point", "New_Points", "memory")
        crs = QgsProject.instance().crs()
        point0.setCrs(crs)
        point0.updateExtents()
        QgsProject.instance().addMapLayer(point0)
        point0.startEditing()
        # Push add line
        hwnd = win32gui.FindWindow(None, 'Layers Operations')
        parent_hwnd = win32gui.GetParent(hwnd)
        text_parent = win32gui.GetWindowText(parent_hwnd)
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.AppActivate(text_parent)
        shell.SendKeys("^.") 

    def CreateLines(self):
        lin0 = QgsVectorLayer("LineString", "New_Line", "memory")
        crs = QgsProject.instance().crs()
        lin0.setCrs(crs)
        lin0.dataProvider().addAttributes([QgsField('ID', QVariant.Int)])
        lin0.updateExtents()
        QgsProject.instance().addMapLayer(lin0)
        lin0.startEditing()
        # Push add line
        hwnd = win32gui.FindWindow(None, 'Grid Creation')
        if hwnd == 0:
            hwnd = win32gui.FindWindow(None, 'Layers Operations')
        parent_hwnd = win32gui.GetParent(hwnd)
        text_parent = win32gui.GetWindowText(parent_hwnd)
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.AppActivate(text_parent)
        shell.SendKeys("^.")

    def CreatePolygons(self):
        pol0 = QgsVectorLayer("Polygon", "New_Polygon", "memory")
        crs = QgsProject.instance().crs()
        pol0.setCrs(crs)
        pol0.updateExtents()
        QgsProject.instance().addMapLayer(pol0)
        pol0.startEditing()
        # Push add line
        hwnd = win32gui.FindWindow(None, 'Layers Operations')
        parent_hwnd = win32gui.GetParent(hwnd)
        text_parent = win32gui.GetWindowText(parent_hwnd)
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.AppActivate(text_parent)
        shell.SendKeys("^.")

    def DeleteLayers(self, event):
        layers = self.iface.layerTreeView().selectedLayers()
        for layer in layers:
            if layer.type()==QgsMapLayerType.RasterLayer:
                QgsProject.instance().removeMapLayer(layer)
            else:
                layer.commitChanges()
                QgsProject.instance().removeMapLayer(layer)
        self.iface.mapCanvas().refresh()

    def ClearLayer(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Удаление!")
        mbox.setText("Удалить все поля и объекты слоя?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.ClearLayerOK)
        mbox.exec_()
        
    def ClearLayerOK(self, buttonOK):
        if buttonOK.text()=="OK":
            layer = self.iface.activeLayer()
            pr = layer.dataProvider()
            path = pr.dataSourceUri()
            pp=path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
            if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
                mbox.setText("Работает только с шейп файлами")
                mbox.show()
                mbox.exec_()
                return
            a = layer.fields().count()
            f = layer.featureCount()
            layer.startEditing()
            for i in range(a):
                pr.deleteAttributes([0])
                layer.updateFields()
            for i in layer.getFeatures():
                q=i.id()
                pr.deleteFeatures([q])
            layer.commitChanges()
            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage("All objects removed from current layer", 
                level=Qgis.Success, duration=4)

    def DeleteFields(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Удаление!")
        mbox.setText("Удалить все поля из слоя?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.DeleteFieldsOK)
        mbox.exec_()

    def DeleteFieldsOK(self, buttonOK):
        if buttonOK.text()=="OK":
            layer = self.iface.activeLayer()
            layer.commitChanges()
            pr = layer.dataProvider()
            path = pr.dataSourceUri()
            pp=path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
            if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
                mbox.setText("Работает только с шейп файлами")
                mbox.show()
                mbox.exec_()
                return
            a = layer.fields().count()
            layer.startEditing()
            for i in range(a):
                pr.deleteAttributes([0])
            layer.commitChanges()
            self.iface.messageBar().pushMessage("All fields removed from current layer", 
            level=Qgis.Success, duration=5)

    def LayerToSHP(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Слои в SHP")
        mbox.setText("Конвертировать выбранные слои?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.LayerToSHPOK)
        mbox.exec_() 

    def LayerToSHPOK(self, buttonOK):
        if buttonOK.text() == "OK":
            tic = time.perf_counter()
            alayer = self.iface.activeLayer()
            if alayer.type() == QgsMapLayerType.RasterLayer:
                mbox.setText("Конвертировать можно только векторные слои")
                mbox.show()
                mbox.exec_()
                return
            layers = self.iface.layerTreeView().selectedLayers()
            c = 0
            for layer in layers:
                c+=1
                arr = []
                for field in layer.fields():
                    arr.append((field.name(), field.type()))
                name = layer.name()+'_Shp'
                for feature in layer.getFeatures():
                    geom = feature.geometry()
                    if geom.type() == 0:
                        gm = "Point"
                    elif geom.type() == 1:
                        gm = "LineString"
                    else:
                        gm = "Polygon"
                fet = QgsFeature()
                crs = layer.crs()
                ShpLayer = QgsVectorLayer(gm, name, "memory")
                spr = ShpLayer.dataProvider()
                ShpLayer.setCrs(crs)
                for i in arr:
                    spr.addAttributes([QgsField(i[0], i[1])])
                ShpLayer.updateFields()
                f = layer.featureCount()
                ff = f
                if layer.type() == QgsMapLayerType.RasterLayer:
                    mbox.setText("Конвертировать можно только векторные слои")
                    mbox.show()
                    mbox.exec_()
                    return
                features = layer.getFeatures()
                #Add features:     
                for feature in features:
                    ff -= 1
                    if ff%1000 == 0:
                        self.dlg_layers.progressBar.setValue(int(((f-ff)/f)*100))
                        QApplication.processEvents()
                    geom = feature.geometry()
                    if geom.type() == 0:
                        geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
                        if geomSingleType:
                            x = geom.asPoint().x()
                            y = geom.asPoint().y()
                        else:
                            x = geom.asMultiPoint()[0][0]
                            y = geom.asMultiPoint()[0][1]
                        attrs = feature.attributes()
                        fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                        fet.setAttributes(attrs)
                        spr.addFeatures([fet])
                    else:
                        attrs = feature.attributes()
                        fet.setGeometry(geom)
                        fet.setAttributes(attrs)
                        spr.addFeatures([fet])
                        ShpLayer.updateFields()
                ShpLayer.updateFields()
                ShpLayer.updateExtents()
                self.dlg_layers.progressBar.setValue(int(0))
                QgsProject.instance().addMapLayer(ShpLayer)
            toc = time.perf_counter()
            ttt=f"Время: {toc - tic:0.2f} сек"
            mboxi.setText(ttt+'\n'+"Конвертировано слоев: "+str(c))
            mboxi.show()
            mboxi.exec_()
            print(f"time: {toc - tic:0.3f} секунд")   

    def MergeLayers(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Объединение слоев")
        mbox.setText("Объединить выбранные слои?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.MergeLayersOK)
        mbox.exec_()

    def MergeLayersOK(self, buttonOK):
        if buttonOK.text() == "OK":
            alayer = self.iface.activeLayer()
            fieldList = []
            if alayer.type() == QgsMapLayerType.RasterLayer:
                mbox.setText("Объединить можно только векторные слои")
                mbox.show()
                mbox.exec_()
                return
            [fieldList.append((field.name(), field.type())) for field in alayer.fields()]
            for feature in alayer.getFeatures():
                geom = feature.geometry()
                if geom.type() == 0:
                    gm = "Point"
                    name = "Merge_points"
                elif geom.type() == 1:
                    gm = "LineString"
                    name = "Merge_lines"
                else:
                    gm = "Polygon"
                    name = "Merge_polygons"
            fet = QgsFeature()
            crs = alayer.crs()
            MergeLayer = QgsVectorLayer(gm, name, "memory")
            mpr = MergeLayer.dataProvider()
            MergeLayer.setCrs(crs)

            for i in fieldList:
                mpr.addAttributes([QgsField(i[0], i[1])])

            MergeLayer.updateFields()
            layers = self.iface.layerTreeView().selectedLayers()
            for layer in layers:
                f = layer.featureCount()
                ff = f
                if layer.type() == QgsMapLayerType.RasterLayer:
                    mbox.setText("Объединить можно только векторные слои")
                    mbox.show()
                    mbox.exec_()
                    return
                features = layer.getFeatures()

                #Add features:     
                for feature in features:
                    ff -= 1
                    if ff % 1000 == 0:
                        self.dlg_layers.progressBar.setValue(int(((f-ff)/f)*100))
                        QApplication.processEvents()
                    geom = feature.geometry()
                    if geom.type() == 0:
                        geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
                        if geomSingleType:
                            x = geom.asPoint().x()
                            y = geom.asPoint().y()
                        else:
                            x = geom.asMultiPoint()[0][0]
                            y = geom.asMultiPoint()[0][1]
                        attrs = feature.attributes()
                        fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                        fet.setAttributes(attrs)
                        mpr.addFeatures([fet])
                    else:
                        attrs = feature.attributes()
                        fet.setGeometry(geom)
                        fet.setAttributes(attrs)
                        mpr.addFeatures([fet])
                        MergeLayer.updateFields()
                MergeLayer.updateFields()
                MergeLayer.updateExtents()
            self.dlg_layers.progressBar.setValue(int(0))
            QgsProject.instance().addMapLayer(MergeLayer)

    def GetInfoLayer(self):
        mbox = QMessageBox()
        font = QtGui.QFont()
        font.setFamily("HelveticaNeueCyr")
        font.setPointSize(10)
        font.setStyleStrategy(QtGui.QFont.PreferAntialias)
        mbox.setWindowTitle("Информация о слое")
        mbox.setIcon(QMessageBox.Information)
        mbox.setStandardButtons(QMessageBox.Ok)
        mbox.setFont(font)
        typen=[0,1,2,3,17,4,5,6,7,8,9,10,11,12,100,1001,1002,1003,1017,1004,1005,1006,1007,1008,1009,1010,1011,1012,
               2001,2002,2003,2017,2004,2005,2006,2007,2008,2009,2010,2011,2012,3001,3002,3003,3004,3005,3006,3007,3008, 
               3009,3010,3011,3012,3017,0x80000001,0x80000002,0x80000003,0x80000004,0x80000005,0x80000006]
        types=['Unknown','Point','LineString','Polygon','Triangle','MultiPoint','MultiLineString','MultiPolygon','GeometryCollection',
'CircularString','CompoundCurve','CurvePolygon','MultiCurve','MultiSurface','NoGeometry','PointZ','LineStringZ',
'PolygonZ','TriangleZ','MultiPointZ','MultiLineStringZ','MultiPolygonZ','GeometryCollectionZ','CircularStringZ',
'CompoundCurveZ','CurvePolygonZ','MultiCurveZ','MultiSurfaceZ','PointM','LineStringM','PolygonM','TriangleM','MultiPointM',
'MultiLineStringM','MultiPolygonM','GeometryCollectionM','CircularStringM','CompoundCurveM','CurvePolygonM','MultiCurveM',
'MultiSurfaceM','PointZM','LineStringZM','PolygonZM','MultiPointZM','MultiLineStringZM','MultiPolygonZM','GeometryCollectionZM',
'CircularStringZM','CompoundCurveZM','CurvePolygonZM','MultiCurveZM','MultiSurfaceZM','TriangleZM','Point25D','LineString25D',
'Polygon25D','MultiPoint25D','MultiLineString25D','MultiPolygon25D']
        layer = self.iface.activeLayer()
        if layer==None:
            print("ИНФОРМАЦИЯ О СЛОЕ:")
            print("Слой без типа")
            return
        crs = layer.crs()
        extent = layer.extent().toString()
        xMin=round(layer.extent().xMinimum(), 5)
        xMax=round(layer.extent().xMaximum(), 5)
        yMin=round(layer.extent().yMinimum(), 5)
        yMax=round(layer.extent().yMaximum(), 5)
        e="Охват слоя:"+'\n'+str(xMin)+', '+str(yMin)+'\n'+str(xMax)+', '+str(yMax)
        if layer.type()==QgsMapLayerType.RasterLayer:
            print("ИНФОРМАЦИЯ О СЛОЕ:")
            if crs.authid()=="":
                p="СК слоя не задана"
                print(p)
            else:
                p="СК слоя: "+crs.authid()
                print(p)
            r="Разрешение в пикселях: "+str(layer.width())+" x "+str(layer.height())
            print(r)
            print(e)
            mbox.setText(p+'\n'+r+'\n'+e)
            mbox.show()
            mbox.exec_()
            return
        gtype = layer.wkbType()
        for i in typen:
            if i == gtype:
                index = typen.index(i)
                typ=types[index]
        features = layer.getFeatures()
        fc=layer.featureCount()
        if fc == 0:
            mbox.setText("Пустой векторный слой")
            mbox.show()
            mbox.exec_()
            return
        arr = []
        print("ИНФОРМАЦИЯ О СЛОЕ:")
        for feature in features:
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.PointGeometry:
                if crs.authid()=="":
                    p="СК слоя не задана"
                    print(p)
                else:
                    p="СК слоя: "+crs.authid()
                    print(p)
                tg="Тип геометрии: "+typ
                pc="Количество точек: "+str(fc)
                print(tg), print(pc), print(e)
                mbox.setText(p+'\n'+tg+'\n'+pc+'\n'+e)
                mbox.show()
                mbox.exec_()
                return
                if geomSingleType:
                    x = geom.asPoint()
                else:
                    x = geom.asMultiPoint()
            elif geom.type() == QgsWkbTypes.LineGeometry:
                if geomSingleType:
                    x = geom.asPolyline()
                    arr.append(geom.length())
                else:
                    x = geom.asMultiPolyline()
                    arr.append(geom.length())
            elif geom.type() == QgsWkbTypes.PolygonGeometry:
                if geomSingleType:
                    x = geom.asPolygon()
                    arr.append(geom.area())
                else:
                    x = geom.asMultiPolygon()
                    arr.append(geom.area())
            else:
                print("Unknown or invalid geometry")
            attrs = feature.attributes()
        if geom.type() == QgsWkbTypes.LineGeometry:
            if crs.authid()=="":
                p="СК слоя не задана"
                print(p)
            else:
                p="СК слоя: "+crs.authid()
                print(p)
            tg="Тип геометрии: "+typ
            lc="Количество линий: "+str(fc)
            le="Общая длина: "+str(sum(arr))+" м"
            print(tg), print(lc), print(le), print(e)
            mbox.setText(p+'\n'+tg+'\n'+lc+'\n'+le+'\n'+e)
            mbox.show()
            mbox.exec_()
        elif geom.type() == QgsWkbTypes.PolygonGeometry:
            if crs.authid()=="":
                p="СК слоя не задана"
                print(p)
            else:
                p="СК слоя: "+crs.authid()
                print(p)
            tg="Тип геометрии: "+typ
            pc="Количество полигонов: "+str(fc)
            ar="Общая площадь: "+str(sum(arr))+" кв.м"
            print(pc), print(tg), print(ar), print(e)
            mbox.setText(p+'\n'+tg+'\n'+pc+'\n'+ar+'\n'+e)
            mbox.show()
            mbox.exec_()  


    #--------------------------------------------------------------------------
    # Geometry
    #--------------------------------------------------------------------------
    def GetGeometryXY(self):
        tic = time.perf_counter()
        vlayer = self.iface.activeLayer()
        vlayer.startEditing()
        crs = vlayer.crs()
        if vlayer==None or vlayer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран слой с точками")
            mbox.show()
            mbox.exec_()
            return
        for i in vlayer.getFeatures():
            if i.geometry().type() == 1 or i.geometry().type() == 2:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                mbox.exec_()
                return
            break
        arr=[]
        f = vlayer.featureCount()
        ff=f
        features=vlayer.getFeatures()
        vpr = vlayer.dataProvider()
        path = vpr.dataSourceUri()
        pp=path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
        if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
            mbox.setText("Работает только с шейп файлами")
            mbox.show()
            mbox.exec_()
            return
        fc = vlayer.fields().count()
        if fc == fc+1:
            vpr.deleteAttributes([fc])
            vlayer.updateFields()
        arr = list()
        if vlayer.providerType()=="memory":
            for field in vlayer.fields():
                if field.name()=="X" or field.name()=="Y" or field.name()=="X_WGS84" or field.name()=="Y_WGS84":
                    mbox.setText('Поле X или Y уже есть в таблице')
                    mbox.show()
                    mbox.exec_()
                    return
        for field in vlayer.fields():
            arr.append(field.name())
        vpr.addAttributes([QgsField('X', QVariant.Double,'double', 20, 7), QgsField('Y', QVariant.Double,'double', 20, 7)])
        for i in features:
            ff-=1
            if ff%200==0:
                self.dlg_geometry.progressBar.setValue(int(((f-ff)/f)*100))
                QApplication.processEvents()
            geom = i.geometry()
            if not geom.type() == 0:
               continue
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geomSingleType:
                xy = geom.asPoint()
                attr_value={ fc : xy.x(), fc+1 : xy.y() }
            else:
                xy = geom.asMultiPoint()
                attr_value={ fc : xy[0].x(), fc+1 : xy[0].y() }
            id=i.id()
            vpr.changeAttributeValues({id:attr_value})
        vlayer.updateFields()
        vlayer.commitChanges()
        self.dlg_geometry.progressBar.setValue(int(0))
        self.iface.messageBar().pushMessage("XY coord added in current layer", 
            level=Qgis.Success, duration=5)
        toc = time.perf_counter()
        print(f"time: {toc - tic:0.3f} секунд")
        mboxi.setText("Координаты добавлены")
        mboxi.show()
        mboxi.exec_()

    def GetTargetXY(self):
        tic = time.perf_counter()
        targetCrs = self.dlg_geometry.Projection_SW.crs().authid()
        vlayer = self.iface.activeLayer()
        vlayer.startEditing()
        crs = vlayer.crs()
        transformContext = QgsProject.instance().transformContext()
        xform = QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem(targetCrs), transformContext)
        if vlayer==None or vlayer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран слой с точками")
            mbox.show()
            mbox.exec_()
            return
        for i in vlayer.getFeatures():
            if i.geometry().type() == 1 or i.geometry().type() == 2:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                mbox.exec_()
                return
            break
        arr=[]
        f = vlayer.featureCount()
        ff=f
        features=vlayer.getFeatures()
        BarStep = 100/f
        vlayer.commitChanges()
        vpr = vlayer.dataProvider()
        path = vpr.dataSourceUri()
        pp=path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
        if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
            mbox.setText("Работает только с шейп файлами")
            mbox.show()
            mbox.exec_()
            return
        fc = vlayer.fields().count()
        if fc == fc+1:
            vpr.deleteAttributes([fc])
            vlayer.updateFields()
        arr = list()
        for field in vlayer.fields():
            arr.append(field.name())
        if any(i == 'X_'+targetCrs for i in arr):
            mbox.setText('Поле X_'+targetCrs+' уже есть в таблице')
            vlayer.commitChanges()
            mbox.show()
            mbox.exec_()
            return
        vpr.addAttributes([QgsField('X_'+targetCrs, QVariant.Double, 'double', 20, 7), QgsField('Y_'+targetCrs, QVariant.Double, 'double', 20, 7)])
        for i in features:
            ff-=1
            if ff%200==0:
                self.dlg_geometry.progressBar.setValue(int(((f-ff)/f)*100))
                QApplication.processEvents()
            geom = i.geometry()
            if not geom.type() == 0:
               continue
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geomSingleType:
                xy = geom.asPoint()
                xyTarget=xform.transform(QgsPointXY(xy))
                attr_value={ fc : xyTarget.x(), fc+1 : xyTarget.y() }
            else:
                xy = geom.asMultiPoint()
                xyTarget=xform.transform(QgsPointXY(xy[0]))
                attr_value={ fc : xyTarget[0].x(), fc+1 : xyTarget[0].y() }
            id=i.id()
            vpr.changeAttributeValues({id:attr_value})
        vlayer.updateFields()
        vlayer.commitChanges()
        self.dlg_geometry.progressBar.setValue(int(0))
        self.iface.messageBar().pushMessage("XY coord added in current layer", 
            level=Qgis.Success, duration=5)
        toc = time.perf_counter()
        print(f"time: {toc - tic:0.3f} секунд")
        mboxi.setText("Координаты добавлены")
        mboxi.show()
        mboxi.exec_()
        
    def GetElevationZ(self):
        tic = time.perf_counter()
        rlayer = self.dlg_geometry.Raster_CB.currentLayer()
        vlayer = self.iface.activeLayer()
        vlayer.startEditing()
        if vlayer.type() != QgsMapLayerType.VectorLayer:
            mbox.setText("Должен быть выбран векторный слой с точками")
            mbox.show()
            mbox.exec_()
            return
        f = vlayer.featureCount()
        ff=f
        features = vlayer.getFeatures()

        geom = vlayer.getFeature(1).geometry()
        geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
        if geomSingleType:
            xy = geom.asPoint()
            try:
                ident = rpr.identify(QgsPointXY(xy.x(), xy.y()), 1)
                IFV = 1
            except:
                IFV = QgsRaster.IdentifyFormatValue
        else:
            xy = geom.asMultiPoint()
            try:
                ident = rpr.identify(QgsPointXY(xy[0].x(), xy[0].y()), 1)
                IFV = 1
            except:
                IFV = QgsRaster.IdentifyFormatValue

        fc = vlayer.fields().count()
        vpr = vlayer.dataProvider()
        rpr = rlayer.dataProvider()
        if vlayer.providerType()=="memory":
            for field in vlayer.fields():
                if field.name()=="Z":
                    mbox.setText('Поле Z уже есть в таблице')
                    mbox.show()
                    mbox.exec_()
                    return
        for i in vlayer.getFeatures():
            if i.geometry().type() == 1 or i.geometry().type() == 2:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                mbox.exec_()
                return
            break
        if not rlayer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("В окне DEM должен быть выбран растровый слой рельефа")
            mbox.show()
            mbox.exec_()
            return
        vcrs = vlayer.crs()
        rcrs = rlayer.crs()
        if not vcrs==rcrs:
            mbox.setText("Проекции растра и точек не совпадают")
            mbox.show()
            mbox.exec_()
            return
        path = vpr.dataSourceUri()
        pp=path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
        if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
            mbox.setText("Работает только с шейп файлами")
            mbox.show()
            mbox.exec_()
            return
        vpr.addAttributes([QgsField('Z', QVariant.Double,'double', 20, 3)])
        for i in features:
            ff-=1
            if ff%200==0:
                self.dlg_geometry.progressBar.setValue(int(((f-ff)/f)*100))
                QApplication.processEvents()
            geom = i.geometry()
            if not geom.type() == 0:
               continue
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geomSingleType:
                xy = geom.asPoint()
                ident = rpr.identify(QgsPointXY(xy.x(), xy.y()), IFV)
            else:
                xy = geom.asMultiPoint()
                ident = rpr.identify(QgsPointXY(xy[0].x(), xy[0].y()), IFV)
            if ident.results()=={}:
                vlayer.startEditing()
                c=0
                for field in vlayer.fields():
                    if field.name()=='Z':
                        vpr.deleteAttributes([c])
                        vlayer.commitChanges()
                    c+=1
                vlayer.updateFields()
                vlayer.commitChanges()
                mbox.setText("Недоступный источник растра во вкладке DEM")
                mbox.show()
                mbox.exec_()
                return
            z=ident.results()[1]
            ids=i.id()
            attr_value={ fc : z }
            vpr.changeAttributeValues({ids:attr_value})
        vlayer.updateFields()
        vlayer.commitChanges()
        self.dlg_geometry.progressBar.setValue(int(0))
        self.iface.messageBar().pushMessage("Elevation added in current layer", 
            level=Qgis.Success, duration=5)
        toc = time.perf_counter()
        print(f"time: {toc - tic:0.3f} секунд")
        mboxi.setText("Координаты добавлены")
        mboxi.show()
        mboxi.exec_()

    def DMScoord(self):
        tic = time.perf_counter()
        targetCrs = 'EPSG:4326'
        vlayer = self.iface.activeLayer()
        vlayer.startEditing()
        crs = vlayer.crs()
        transformContext = QgsProject.instance().transformContext()
        xform = QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem(targetCrs), transformContext)
        if vlayer==None or vlayer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран слой с точками")
            mbox.show()
            mbox.exec_()
            return
        for i in vlayer.getFeatures():
            if i.geometry().type() == 1 or i.geometry().type() == 2:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                mbox.exec_()
                return
            break
        arr=[]
        f = vlayer.featureCount()
        ff=f
        features=vlayer.getFeatures()
        vpr = vlayer.dataProvider()
        path = vpr.dataSourceUri()
        pp=path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
        if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
            mbox.setText("Работает только с шейп файлами")
            mbox.show()
            mbox.exec_()
            return
        fc = vlayer.fields().count()
        if fc == fc+1:
            vpr.deleteAttributes([fc])
            vlayer.updateFields()
        arr = list()
        for field in vlayer.fields():
            arr.append(field.name())
        if any(i == 'lat' for i in arr):
            mbox.setText('Поле lat уже есть в таблице')
            vlayer.commitChanges()
            mbox.show()
            mbox.exec_()
            return
        vpr.addAttributes([QgsField('lat', QVariant.String), QgsField('lon', QVariant.String)])
        for i in features:
            ff-=1
            if ff%200==0:
                self.dlg_geometry.progressBar.setValue(int(((f-ff)/f)*100))
                QApplication.processEvents()
            geom = i.geometry()
            if not geom.type() == 0:
               continue
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geomSingleType:
                xy = geom.asPoint()
                xyTarget=xform.transform(QgsPointXY(xy))
                X=xyTarget.x()
                Y=xyTarget.y()
                mx = math.modf(xyTarget.x())
                my = math.modf(xyTarget.y())
                if X >= 0:
                    ln = 'E'
                else:
                    ln = 'W'
                if Y >= 0:
                    lt = 'N'
                else:
                    lt = 'S'
                glon = abs(int(mx[1]))
                mlon = abs(int(math.modf(mx[0]/0.01666666)[1]))
                slon = abs(round((math.modf(mx[0]/0.01666666)[0])/0.01666666, 3))
                glat = abs(int(my[1]))
                mlat = abs(int(math.modf(my[0]/0.01666666)[1]))
                slat = abs(round((math.modf(my[0]/0.01666666)[0])/0.01666666, 3))
                lon=(ln+str(glon)+'°'+str(mlon)+"'"+str(slon)+'"')
                lat=(lt+str(glat)+'°'+str(mlat)+"'"+str(slat)+'"')
                attr_value={ fc : lat, fc+1 : lon }
            else:
                xy = geom.asMultiPoint()
                xyTarget=xform.transform(QgsPointXY(xy[0]))
                X=xyTarget.x()
                Y=xyTarget.y()
                mx = math.modf(xyTarget.x())
                my = math.modf(xyTarget.y())
                if X >= 0:
                    ln = 'E'
                else:
                    ln = 'W'
                if Y >= 0:
                    lt = 'N'
                else:
                    lt = 'S'
                glon = abs(int(mx[1]))
                mlon = abs(int(math.modf(mx[0]/0.01666666)[1]))
                slon = abs(round((math.modf(mx[0]/0.01666666)[0])/0.01666666, 3))
                glat = abs(int(my[1]))
                mlat = abs(int(math.modf(my[0]/0.01666666)[1]))
                slat = abs(round((math.modf(my[0]/0.01666666)[0])/0.01666666, 3))
                lon=(ln+str(glon)+'°'+str(mlon)+"'"+str(slon)+'"')
                lat=(lt+str(glat)+'°'+str(mlat)+"'"+str(slat)+'"')
                attr_value={ fc : lat, fc+1 : lon }
            id=i.id()
            vpr.changeAttributeValues({id:attr_value})
        vlayer.updateFields()
        vlayer.commitChanges()
        self.dlg_geometry.progressBar.setValue(int(0))
        self.iface.messageBar().pushMessage("lat lon coord added in current layer", 
            level=Qgis.Success, duration=5)
        toc = time.perf_counter()
        print(f"Время {toc - tic:0.3f} секунд")  
        mboxi.setText("Координаты добавлены")
        mboxi.show()
        mboxi.exec_()


    #--------------------------------------------------------------------------
    # Warp
    #-------------------------------------------------------------------------- 
    def setCrs(self):
        layers = self.iface.layerTreeView().selectedLayers()
        targetCrs = self.dlg_warp.Projection_SW.crs().authid()
        for layer in layers:
            layer.setCrs(QgsCoordinateReferenceSystem(targetCrs))
            crs = layer.crs()
        self.iface.mapCanvas().redrawAllLayers()

    def Warp(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Перепроецирование")
        mbox.setText("Перепроецировать выделенные слои?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.WarpOK)
        mbox.exec_()

    def WarpOK(self, buttonOK):
        tic = time.perf_counter()
        targetCrs = self.dlg_warp.Projection_SW.crs().authid()
        targetCrsStr = targetCrs[:targetCrs.find(':')]+targetCrs[targetCrs.find(':')+1:]
        crs = QgsCoordinateReferenceSystem(targetCrs)

        if buttonOK.text() == "OK":
            layers = self.iface.layerTreeView().selectedLayers()
            if len(layers) == 0:
                mbox.setText("Не выбран ни один слой")
                mbox.show()
                mbox.exec_()
                return
            BarStep = 100 / len(layers)
            c = 0
            for layer in layers:
                c += 1
                self.dlg_warp.progressBar.setValue(int(BarStep*c))
                QApplication.processEvents()
                pr = layer.dataProvider()
                inputCrs = layer.crs().authid()
                path = pr.dataSourceUri()
                if path.find('memory?') != -1:
                    parameter = {'INPUT': layer, 'TARGET_CRS': crs, 'OUTPUT': 'memory:{}'.format(layer.name()+'_'+targetCrsStr)}
                    result = processing.run('native:reprojectlayer', parameter)['OUTPUT'] 
                    QgsProject.instance().addMapLayer(result)
                    continue
                if path.find('|') != -1:
                    r = path.find('|')
                    path = path[:r]
                pp = path[len(path)-3] + path[len(path)-2] + path[len(path)-1]
                if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts") and len(layers)==1:
                    mbox.setText("Можно перепроецировать только шейп файлы и растры")
                    mbox.show()
                    mbox.exec_()
                    return
                elif (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
                    continue
                (Directory, File) = os.path.split(path)
                cnt = File.count(".")
                fn = ''
                for i in range(cnt):
                    fn0 = File.split(".")[i]
                    if i != cnt - 1:
                        fn = fn + fn0 + '.'
                    else:
                        fn = fn + fn0
                form = File.split(".")[cnt]
                out = Directory + "/" + fn + "_" + targetCrsStr + "." + form
                outfn = fn + "_" + targetCrsStr
                if os.path.isfile(out) == True:
                    for layerDel in QgsProject.instance().mapLayers().values():
                        if layerDel.name() == outfn:
                            QgsProject.instance().removeMapLayers([layerDel.id()])
                    self.iface.mapCanvas().refresh()
                    os.remove(out)
                vlayer = QgsVectorLayer(path, fn, "ogr")
                if not vlayer.isValid():
                    Res = self.dlg_warp.lineEdit_10.text()
                    noData = self.dlg_warp.lineEdit_19.text()
                    dataTypeIndex = self.dlg_warp.comboBox.currentIndex()
                    ot_dict = {0: 0, 1: gdal.GDT_Byte, 2: gdal.GDT_Int16, 3: gdal.GDT_UInt16, 4: gdal.GDT_Int32, 5: gdal.GDT_UInt32, 6: gdal.GDT_Float32, 7: gdal.GDT_Float64}
                    ot = ot_dict.get(dataTypeIndex)
                    if noData == '':
                        noData = None
                    if Res == '':
                        Res = None
                        resAlg = None
                    else:
                        resAlg = gdal.GRA_Cubic
                    extent = out.find('.')
                    out = out[:extent]+'.tif'
                    if layer.crs().authid().find('EPSG') == -1:
                        print('Other proj')

                    # Reprojection raster #
                    gdal.Warp(out, path, xRes=Res, yRes=Res, outputType=ot, dstNodata=noData, multithread=1, srcSRS=inputCrs, dstSRS=targetCrs, format='GTiff', resampleAlg=resAlg) 
                    if self.dlg_warp.ReprojectingButton.isChecked():
                        self.iface.addRasterLayer(out)
                    else:
                        layer.setDataSource(out, layer.name(), "gdal")
                else:

                    # Reprojection vector #
                    parameter = {'INPUT': path, 'TARGET_CRS': targetCrs, 'OUTPUT': out}
                    result = processing.run('native:reprojectlayer', parameter)
                    targetlayer = QgsVectorLayer(out, outfn, "ogr")
                    if self.dlg_warp.ReprojectingButton.isChecked():
                        QgsProject.instance().addMapLayer(targetlayer)
                    else:
                        layer.setDataSource(out, layer.name(), "ogr")
                        layer.updateExtents()

            self.dlg_warp.progressBar.setValue(int(0))
            toc = time.perf_counter()
            ttt = f"Время: {toc - tic:0.2f} сек"
            mboxi.setText(ttt+'\n'+"Перепроецированных слоев: "+str(c))
            mboxi.show()
            mboxi.exec_()

    def Translate(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Translate")
        mbox.setText("Преобразовать формат слоя?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.TranslateOK)
        mbox.exec_()

    def TranslateOK(self, buttonOK):
        tic = time.perf_counter()
        if buttonOK.text() == "OK":
            layers = self.iface.layerTreeView().selectedLayers()
            if len(layers) == 0:
                mbox.setText("Не выбран ни один слой")
                mbox.show()
                mbox.exec_()
                return
            BarStep = 100/len(layers)
            c = 0
            for layer in layers:
                c+=1
                self.dlg_warp.progressBar.setValue(int(BarStep*c))
                QApplication.processEvents()
                pr = layer.dataProvider()
                targetCrs = self.dlg_warp.Projection_SW.crs().authid()
                targetCrsStr = targetCrs[:targetCrs.find(':')]+targetCrs[targetCrs.find(':')+1:]
                crs = QgsCoordinateReferenceSystem(targetCrs)
                path = pr.dataSourceUri()
                if path.find('|') != -1:
                    r = path.find('|')
                    path = path[:r]
                (Directory, File) = os.path.split(path)
                cnt = File.count(".")
                fn = ''
                for i in range(cnt):
                    fn0 = File.split(".")[i]
                    if i != cnt-1:
                        fn = fn+fn0+'.'
                    else:
                        fn = fn+fn0
                form = File.split(".")[cnt]
                out = Directory +"/"+fn+"_"+'Trns'+"."+form
                outfn = fn+"_"+'Translate'
                if os.path.isfile(out) == True:
                    for layerDel in QgsProject.instance().mapLayers().values():
                        if layerDel.name() == outfn:
                            QgsProject.instance().removeMapLayers([layerDel.id()])
                    self.iface.mapCanvas().refresh()
                    os.remove(out)
                vlayer = QgsVectorLayer(path, fn, "ogr")
                if not (vlayer.isValid() or layer.type() == QgsMapLayerType.VectorLayer):
                    Res = self.dlg_warp.lineEdit_10.text()
                    noData = self.dlg_warp.lineEdit_19.text()
                    JPEG_Qual = str(self.dlg_warp.lineEdit_20.text())
                    dataTypeIndex = self.dlg_warp.comboBox.currentIndex()
                    ot_dict = {0: 0, 1: gdal.GDT_Byte, 2: gdal.GDT_Int16, 3: gdal.GDT_UInt16, 4: gdal.GDT_Int32, 5: gdal.GDT_UInt32, 6: gdal.GDT_Float32, 7: gdal.GDT_Float64}
                    ot = ot_dict.get(dataTypeIndex)
                    if noData == '':
                        noData = None
                    if Res == '':
                        Res = 0
                        resAlg = None
                    else:
                        resAlg = gdal.GRA_Cubic
                    extent = out.find('.')
                    if self.dlg_warp.GTiffbtn.isChecked():
                        extent_target = '.tif'
                        frmt = 'GTiff'
                        bl = None
                        co = None
                    else:
                        extent_target = '.jpg'
                        frmt = 'JPEG'
                        if layer.bandCount()>1:
                            bl = (1, 2, 3)
                        else:
                            bl = None
                        co = ('QUALITY='+JPEG_Qual, 'WORLDFILE=YES')
                        wf = '.jgw'
                    if layer.crs().authid().find('EPSG') == -1:
                        print('other proj')
                    kwargs = {'format': frmt, 'creationOptions': co, 'outputType': ot, 'bandList': bl, 'xRes': Res, 'yRes': Res, 'noData': noData, 'resampleAlg': resAlg}    
                    
                    # Translate raster #
                    out = out[:extent] + extent_target
                    print('path', path)
                    print('out', out)
                    index_path = path.rindex('.')
                    index_out = out.rindex('.')
                    new_path = path[:index_path] + extent_target
                    old_ext = path[index_path:]
                    new_ext = out[index_out:]

                    if old_ext != new_ext:
                        new_out = new_path
                        print('new path', new_path)
                        print('new out', new_out)
                    else:
                        new_out = out
                        print('new out', new_out)


                    if self.dlg_warp.owerwrite_button.isChecked():
                        QgsProject.instance().removeMapLayer(layer)
                        ds = gdal.Translate(new_out, path, **kwargs) 
                        ds = None
                        os.remove(path)
                        if new_out.find('_Trns') != -1:
                            index = new_out.rindex('_Trns')
                            new_t_out = new_out[:index] + extent_target
                            print('new t out', new_t_out)
                            os.rename(new_out, new_t_out)
                            self.iface.addRasterLayer(new_t_out)
                        else:
                            self.iface.addRasterLayer(new_out)
                    elif self.dlg_warp.ReprojectingButton.isChecked():
                        ds = gdal.Translate(out, path, **kwargs) 
                        ds = None
                        self.iface.addRasterLayer(out)
                    else:
                        ds = gdal.Translate(out, path, **kwargs)
                        layer.setDataSource(out, layer.name(), "gdal")

                    #if not self.dlg_warp.GTiffButton.isChecked():    
                    #    layer = self.iface.activeLayer()
                    #    Pix_X_Size = str(layer.rasterUnitsPerPixelX())
                    #    Pix_Y_Size = str(layer.rasterUnitsPerPixelY()*-1)
                    #    X_fpix = str(layer.extent().xMinimum()+layer.rasterUnitsPerPixelX()/2)
                    #    Y_fpix = str(layer.extent().yMaximum()-layer.rasterUnitsPerPixelY()/2)
                    #    out = out.replace(extent_target, "")
                    #    wld_file = open(out+wf, "w+")
                    #    wld_file.write(Pix_X_Size+'\n'+'0'+'\n'+'0'+'\n'+Pix_Y_Size+'\n'+X_fpix+'\n'+Y_fpix)
                    #    wld_file.close()
                else:
                    mbox.setText("Можно транслировать только растры")
                    mbox.show()
                    mbox.exec_()
                    return
            self.dlg_warp.progressBar.setValue(int(0))
            toc = time.perf_counter()
            ttt=f"Время: {toc - tic:0.2f} сек"
            mboxi.setText(ttt+'\n'+"Переформатированых слоев: "+str(c))
            mboxi.show()
            mboxi.exec_()


    #--------------------------------------------------------------------------
    # Classes
    #--------------------------------------------------------------------------    
    def Classes(self):
        vlayer = self.iface.activeLayer()
        if vlayer == None or vlayer.type() == QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран векторный слой")
            mbox.show()
            mbox.exec_()
            return
        fieldList = []
        [fieldList.append(field.name()) for field in vlayer.fields()]
        self.items = QgsFieldComboBox()
        self.items.setLayer(vlayer)    
        label = QtWidgets.QLabel()
        label.setText('Выбрать нужное поле')
        self.dlg = QDialog()
        layout = QVBoxLayout()
        self.dlg.setWindowTitle("Field selection")
        self.dlg.resize(180, 100)
        layout.addWidget(label)
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        layout.addWidget(self.items)
        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(self.acceptFields_Classes)
        btnBox.rejected.connect(self.rejectDlg)
        layout.addWidget(btnBox)
        self.dlg.setLayout(layout)
        self.dlg.exec_()

    def acceptFields_Classes(self):
        self.dlg.close()
        vlayer = self.iface.activeLayer()
        check = self.items.currentField()
        index = self.items.currentIndex()
        if vlayer.fields()[index].typeName() == "string":
            mbox.setText("Поле для классификации должно иметь числовой тип данных")
            mbox.show()
            mbox.exec_()
            return
        Geoprocess.ClassesOK(self, check) 

    def ClassesOK(self, check):
        vlayer = self.iface.activeLayer()
        Method_index = self.dlg_classes.methodBox.currentIndex()
        Methods = [QgsGraduatedSymbolRenderer.EqualInterval, QgsGraduatedSymbolRenderer.Quantile, QgsGraduatedSymbolRenderer.Jenks, QgsGraduatedSymbolRenderer.StdDev]
        classes = int(self.dlg_classes.Classes.text())
        firstSize = float(self.dlg_classes.First_Size.text())
        lastSize = float(self.dlg_classes.Last_Size.text())
        increment = lastSize - firstSize
        TargetField = check
        Symbol = QgsSymbol.defaultSymbol(vlayer.geometryType())
        ColorRamp = QgsCptCityColorRamp("grass/bcyr","", 0)
        Renderer = QgsGraduatedSymbolRenderer().createRenderer(vlayer, TargetField, classes, 1, Symbol, ColorRamp)
        Renderer.setClassAttribute(TargetField)
        Renderer.updateClasses(vlayer, Methods[Method_index], classes)
        vlayer.setRenderer(Renderer)
        symbols = vlayer.renderer().symbols(QgsRenderContext())
        if classes - len(symbols) != 0:
            mbox.setText("Поле для классификации должно иметь только числовые значения или число классов не соответствует")
            mbox.show()
            mbox.exec_()
            return
        for i in range(classes):
            size = firstSize + (increment * i) / (classes - 1)
            symbols[i].setSize(size)
        self.iface.mapCanvas().redrawAllLayers()
        self.iface.layerTreeView().refreshLayerSymbology(vlayer.id())
        QgsProject.instance().layerTreeRoot().findLayer(vlayer.id()).setExpanded(True)
        QgsProject.instance().layerTreeRoot().findLayer(vlayer.id()).isExpanded()
        vlayer.triggerRepaint()
 
    def Resize(self):
        vlayer = self.iface.activeLayer()
        if vlayer == None or vlayer.type() == QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран векторный слой")
            mbox.show()
            mbox.exec_()
            return
        classes = int(self.dlg_classes.Classes.text())
        firstSize = float(self.dlg_classes.First_Size.text())
        lastSize = float(self.dlg_classes.Last_Size.text())
        increment = lastSize - firstSize
        Symbol = QgsSymbol.defaultSymbol(vlayer.geometryType())
        symbols = vlayer.renderer().symbols(QgsRenderContext())
        for i in range(len(symbols)):
            size = firstSize + (increment * i) / (len(symbols) - 1)
            symbols[i].setSize(size)
        self.iface.mapCanvas().redrawAllLayers()
        self.iface.layerTreeView().refreshLayerSymbology(vlayer.id()) 


    def ColorRamp(self):
        new_dialog = QDialog()
        new_dialog.resize(800, 600)
        
        #style = QgsStyleV2().defaultStyle()
        
        color_ramp_combo_box = QgsColorRampComboBox(new_dialog)
        #color_ramp_combo_box.populate(style)
        new_dialog.show()

    #--------------------------------------------------------------------------
    # Export
    #--------------------------------------------------------------------------
    def Export_GPX(self):
        layer = self.iface.activeLayer()
        file_path = self.dlg_export.mQgsFileWidget.filePath()
        if file_path == "":
            mbox.setText("Должен быть выбран путь сохранения файла")
            mbox.show()
            return    
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPX"
        options.datasourceOptions = ["GPX_USE_EXTENSIONS=YES"]
        if self.dlg_export.checkBox.isChecked():
            options.onlySelectedFeatures = True
        else:
            options.onlySelectedFeatures = False
        
        QgsVectorFileWriter.writeAsVectorFormatV2(layer, file_path, QgsCoordinateTransformContext(), options)
        mboxi.setText("Слой экспортирован в " + file_path + ".gpx")
        mboxi.show()
        mboxi.exec_()

    def Export_KML(self):
        layer = self.iface.activeLayer()
        file_path = self.dlg_export.mQgsFileWidget.filePath()
        if file_path == "":
            mbox.setText("Должен быть выбран путь сохранения файла")
            mbox.show()
            return
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "KML"
        if self.dlg_export.checkBox.isChecked():
            options.onlySelectedFeatures = True
        else:
            options.onlySelectedFeatures = False
        
        QgsVectorFileWriter.writeAsVectorFormatV2(layer, file_path, QgsCoordinateTransformContext(), options)
        mboxi.setText("Слой экспортирован в " + file_path + ".kml")
        mboxi.show()
        mboxi.exec_()

    def Export_GPKG(self):
        layers = self.iface.layerTreeView().selectedLayers()
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        if self.dlg_export.checkBox.isChecked():
            options.onlySelectedFeatures = True
        else:
            options.onlySelectedFeatures = False

        cnt = 0
        for layer in layers:
            cnt += 1
            file_path = self.dlg_export.mQgsFileWidget.filePath()
            if file_path == "":
                mbox.setText("Должен быть выбран путь сохранения файла")
                mbox.show()
                return
            if cnt > 1:
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
            options.layerName = layer.name()
            QgsVectorFileWriter.writeAsVectorFormatV3(layer, file_path, QgsCoordinateTransformContext(), options)
            if QgsVectorFileWriter.writeAsVectorFormatV3(layer, file_path, QgsCoordinateTransformContext(), options) == QgsVectorFileWriter.NoError:
                print("Success!\n")
            else:
                print(QgsVectorFileWriter.writeAsVectorFormatV3(layer, file_path, QgsCoordinateTransformContext(), options))

        mboxi.setText("Слой экспортирован в " + file_path + ".gpkg")
        mboxi.show()
        mboxi.exec_()


    #--------------------------------------------------------------------------
    def run_gridding(self):
        self.dlg_grid = griddingDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_grid.show()
        # Buttons click
        self.dlg_grid.Grid.clicked.connect(self.Grid)
        self.dlg_grid.CreateLine.clicked.connect(self.CreateLines)
        self.dlg_grid.Insert_Void.clicked.connect(self.Insert_Void)
        # Filters
        self.dlg_grid.Raster_CB.setFilters(QgsMapLayerProxyModel.RasterLayer) 

    def run_layers_operations(self):
        self.dlg_layers = layers_operationsDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_layers.show()
        # Buttons click
        self.dlg_layers.CreatePoint.clicked.connect(self.CreatePoints)
        self.dlg_layers.CreateLine.clicked.connect(self.CreateLines)
        self.dlg_layers.CreatePolygon.clicked.connect(self.CreatePolygons)
        self.dlg_layers.DeleteLayers.clicked.connect(self.DeleteLayers)
        self.dlg_layers.ClearLayer.clicked.connect(self.ClearLayer)
        self.dlg_layers.DeleteFields.clicked.connect(self.DeleteFields)
        self.dlg_layers.LayerToSHP.clicked.connect(self.LayerToSHP)
        self.dlg_layers.MergeLayers.clicked.connect(self.MergeLayers)
        self.dlg_layers.GetInfoLayer.clicked.connect(self.GetInfoLayer)

    def run_geometry(self):
        self.dlg_geometry = geometryDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_geometry.show()
        # Buttons click
        self.dlg_geometry.GetGeometryXY.clicked.connect(self.GetGeometryXY)
        self.dlg_geometry.GetTargetXY.clicked.connect(self.GetTargetXY)
        self.dlg_geometry.GetElevationZ.clicked.connect(self.GetElevationZ)
        self.dlg_geometry.DMScoord.clicked.connect(self.DMScoord)
        # Filters
        self.dlg_geometry.Raster_CB.setFilters(QgsMapLayerProxyModel.RasterLayer) 
        self.dlg_geometry.Projection_SW.setCrs(QgsCoordinateReferenceSystem('EPSG:4326'))

    def run_warp(self):
        self.dlg_warp = warpDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_warp.show()
        # Buttons click
        self.dlg_warp.setCrs.clicked.connect(self.setCrs)
        self.dlg_warp.Warp.clicked.connect(self.Warp)
        self.dlg_warp.Trns.clicked.connect(self.Translate)
        # Filters
        self.dlg_warp.Projection_SW.setCrs(QgsCoordinateReferenceSystem('EPSG:4326'))

    def run_classes(self):
        self.dlg_classes = classesDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_classes.show()
        # Buttons click
        self.dlg_classes.Redraw.clicked.connect(self.Classes)
        self.dlg_classes.Resize.clicked.connect(self.Resize)
  
    def run_export(self):
        self.dlg_export = exportDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_export.show()
        # Buttons click
        self.dlg_export.Export_GPX.clicked.connect(self.Export_GPX)
        self.dlg_export.Export_KML.clicked.connect(self.Export_KML)
        self.dlg_export.Export_GPKG.clicked.connect(self.Export_GPKG)