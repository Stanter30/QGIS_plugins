# -*- coding: utf-8 -*-
"""
/***************************************************************************
 GeoprocessDialog
                                 A QGIS plugin
 Geoprocess
                             -------------------
        begin                : 2024-04-01
        git sha              : $Format:%H$
        copyright            : (C) 2024 by SSG
        email                : stanter30@gmail.com
 ***************************************************************************/
"""

import os
import sys

from qgis.PyQt import uic, QtWidgets, QtCore, QtGui
from PyQt5.QtCore import Qt
from PyQt5.Qt import *

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS_profiles, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'profiles.ui'))
FORM_CLASS_export_waypoints, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'export_waypoints.ui'))


class profilesDialog(QtWidgets.QDialog, FORM_CLASS_profiles):
    def __init__(self, parent=None):
        """Constructor."""
        super(profilesDialog, self).__init__(parent)
        self.setupUi(self)


class export_waypointsDialog(QtWidgets.QDialog, FORM_CLASS_export_waypoints):
    def __init__(self, parent=None):
        """Constructor."""
        super(export_waypointsDialog, self).__init__(parent)
        self.setupUi(self)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_C and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            copied_cells = sorted(self.tableWidget.selectedIndexes())
            copied_cells_2 = sorted(self.tableWidget_2.selectedIndexes())
            copy_text = ""

            print(len(self.tableWidget.selectedIndexes()))
            print(len(self.tableWidget_2.selectedIndexes()))


            if len(self.tableWidget.selectedIndexes()) != 0:
                max_column = copied_cells[-1].column()
    
                for c in copied_cells:
                    if self.tableWidget.item(c.row(), c.column()) == None:
                        continue
                    copy_text += self.tableWidget.item(c.row(), c.column()).text()
                    if c.column() == max_column:
                        copy_text += "\n"
                    else:
                        copy_text += "\t"
    

            if len(self.tableWidget_2.selectedIndexes()) != 0:
                max_column_2 = copied_cells_2[-1].column()
    
                for c in copied_cells_2:
                    if self.tableWidget_2.item(c.row(), c.column()) == None:
                        continue
                    copy_text += self.tableWidget_2.item(c.row(), c.column()).text()
                    if c.column() == max_column_2:
                        copy_text += "\n"
                    else:
                        copy_text += "\t"
                    
            QApplication.clipboard().setText(copy_text)

