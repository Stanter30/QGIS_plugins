# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

import os.path
from datetime import datetime
import numpy as np

from .resources import *
from .UAV_Spec_Process_dialog import UAV_Spec_ProcessDialog


class UAV_Spec_Process:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor"""
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'UAV_Spec_Process_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&UAV_Spec_Process')
        self.toolbar = self.iface.addToolBar(u'UAV_Spec_Process')
        self.toolbar.setObjectName(u'UAV_Spec_Process')

    def tr(self, message): return QCoreApplication.translate('UAV_Spec_Process', message)

    def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/UAV_Spec_Process/icon.png'
        self.add_action(icon_path, text=self.tr(u'UAV_Spec_Process'), callback=self.run, parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&UAV_Spec_Process'), action)
            self.iface.removeToolBarIcon(action)

    def progress(self, i, f, proc_freq, proc_text):
        """Progress bar value."""
        if i % proc_freq == 0:
            self.dlg_spectr.progressBar.setValue(int((i/f)*100))
            self.dlg_spectr.progressBar.setFormat(proc_text + str(int((i/f)*100)) + ' %')

            QtWidgets.QApplication.processEvents()



    def merge_gpx_data(self):
        files_all = []
        data_times = []
        data_vals = []
        data_gpx = []
        integrals = []
        data = []

        time_form = '%Y-%m-%d %H:%M:%S'

        root_gen = self.dlg_spectr.mQgsFileWidget.filePath()
        if len(root_gen) == 0:
            print('Нет пути')
            return

        for root, dirs, files in os.walk(root_gen):
            for file in files:
                if file.find('.dat') != -1 or file.find('.gpx') != -1:
                    files_all.append(root + '/' + file)



        for i, file in enumerate(files_all):
            self.progress(i, len(files_all), 20, 'Reading Data: ')
            # Read data
            if file.endswith(".dat") or file.endswith(".DAT"):
                time = file[-21:-17]+'-'+file[-17:-15]+'-'+file[-15:-13]+' '+file[-12:-10]+':'+file[-10:-8]+':'+file[-8:-6]
                time_sec = datetime.strptime(time, time_form).timestamp()
                #data_times.append(time_sec)
                data = []
                integ = []
                with open(file, 'r', encoding = 'Windows-1251') as file:
                    lines = file.readlines()
                    for line in lines:
                        val_str = line[9]
                        data.append(int(val_str))

                    int_np = np.array(data, dtype='int32')
                    #data_vals.append(data)
                    integrals.append((np.sum(int_np)/8192, time_sec))

            # Read GPX
            elif file.endswith(".gpx"):
                with open(file, 'r', encoding = 'Windows-1251') as file:
                    line = file.readline()
                    words = line.split('<trkpt ')
                    del words[0]
                    del words[-1]
        
                    for word in words:
                        lat_pos_start = word.find('lat="') + 5
                        lon_pos_start = word.find('lon="') + 5
                        ele_pos_start = word.find('ele>') + 4
                        time_pos_start = word.find('time>') + 5
                        lat_pos_end = word.find('" lon')
                        lon_pos_end = word.find('"><ele')
                        ele_pos_end = word.find('</ele>')
                        time_pos_end = word.find('+')
                        lat = float(word[lat_pos_start:lat_pos_end])
                        lon = float(word[lon_pos_start:lon_pos_end])
                        ele = float(word[ele_pos_start:ele_pos_end])
                        time = word[time_pos_start:time_pos_end]
                        time_f = time.replace('T', ' ')
                        try:
                            time_sec = datetime.strptime(time_f, '%Y-%m-%d %H:%M:%S').timestamp()
                        except:
                            continue
                        data0 = [lat, lon, ele, time_sec]
                        data_gpx.append(data0)


        
        
        integrals.sort(key=lambda x: x[-1], reverse=False)
        data_gpx.sort(key=lambda x: x[-1], reverse=False)

        # Transpose
        list_gpx = list(map(list, zip(*data_gpx)))
        # Cut bad data
        cut_data_gpx = []
        for i in range(1, len(list_gpx[0])):
            if list_gpx[-1][i] != list_gpx[-1][i-1]:
                cut_data_gpx.append(data_gpx[i])
        list_gpx = list(map(list, zip(*cut_data_gpx)))

        gpx_np = np.array(list_gpx, dtype='float64')
        int_np = np.array(integrals, dtype='float64').T


        print(gpx_np[-1][0], gpx_np[-1][-1])
        print(int_np[-1][0], int_np[-1][-1])




        




    #--------------------------------------------------------------------------
    # Run plugin
    #--------------------------------------------------------------------------

    def run(self):
        self.dlg_spectr = UAV_Spec_ProcessDialog()
        self.dlg_spectr.show()

        self.dlg_spectr.merge_gpx_data.clicked.connect(self.merge_gpx_data)
