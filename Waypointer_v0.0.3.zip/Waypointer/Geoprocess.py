# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Geoprocess
                                 A QGIS plugin
 Geoprocess
                              -------------------
        begin                : 2023-04-01
        git sha              : $Format:%H$
        copyright            : (C) 2023 by SSG
        email                : stanter30@gmail.com
 ***************************************************************************/
"""
import wx
import win32gui
import win32con
from win32gui import GetWindowText, GetForegroundWindow
import win32com.client
import subprocess
import sys
import etc
import json
from array import *
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from time import sleep
import operator
import time
import os.path
import math
import processing
from osgeo import osr, gdal, ogr
from operator import itemgetter, attrgetter, methodcaller
from itertools import groupby
from qgis.analysis import *
from qgis.core import *
from qgis.core.additions.edit import edit
from qgis.gui import *
from qgis.gui import QgsMapCanvas, QgsMapTool, QgsMapToolEmitPoint
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtCore import QSettings, QTranslator, QVariant, QCoreApplication, Qt, QRectF
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QApplication, QAction, QProgressBar, QMessageBox, QHBoxLayout, QVBoxLayout, QSizePolicy, QPushButton, QDialog, QGridLayout, QDialogButtonBox, QMainWindow, QWidget
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtCore import QThread, QMetaMethod, QObject, pyqtSignal
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QWidget, QPushButton, QApplication, QMainWindow, QMenuBar, QMenu, QAction, QVBoxLayout
from PyQt5.QtWidgets import *
from qgis.gui import QgsLayerTreeView, QgsMapCanvas, QgsMapCanvasItem, QgsMessageBar, QgsVertexMarker, QgsRubberBand

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .Geoprocess_dialog import profilesDialog
from .Geoprocess_dialog import export_waypointsDialog



class Message:

    def msg(self):
        mbox=QMessageBox()
        mbox.setWindowTitle("Неправильный источник данных")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

    def info(self):
        mbox=QMessageBox()
        mbox.setWindowTitle("Информация")
        mbox.setIcon(QMessageBox.Information)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

mbox=Message().msg()
mboxi=Message().info()

class Geoprocess:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor."""
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'Geoprocess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Waypointer')
        self.toolbar = self.iface.addToolBar(u'Waypointer')
        self.toolbar.setObjectName(u'Waypointer')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None

        self.pt = None


    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        return QCoreApplication.translate('Waypointer', message)


    def tool_gridding(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def tool_layers_operations(self, icon2_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon2_path)
        action2 = QAction(icon, text, parent)
        action2.triggered.connect(callback)
        action2.setEnabled(enabled_flag)

        if status_tip is not None:
            action2.setStatusTip(status_tip)
        if whats_this is not None:
            action2.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action2)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action2)

        self.actions.append(action2)
        return action2


    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/Waypointer/gridding.png'
        icon2_path = ':/plugins/Waypointer/layers.png'
        self.tool_gridding(icon_path, text=self.tr(u'Waypointer_Creation Lines'), callback=self.run_gridding, parent=self.iface.mainWindow())
        self.tool_layers_operations(icon2_path, text=self.tr(u'Waypointer_Export'), callback=self.run_layers_operations, parent=self.iface.mainWindow())


        # will be set False in run()
        self.first_start = True

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&Waypointer'), action)
            self.iface.removeToolBarIcon(action)

    def rejectDlg(self):
        self.dlg.close()

    def Exit(self):
        self.iface.messageBar().clearWidgets()
    #--------------------------------------------------------------------------
    #--------------------------------------------------------------------------
    # First Window
    #--------------------------------------------------------------------------

    def CreatePoints(self):
        point0 = QgsVectorLayer("Point", "Home_Point", "memory")
        crs = QgsProject.instance().crs()
        point0.setCrs(crs)
        point0.updateExtents()
        QgsProject.instance().addMapLayer(point0)
        point0.startEditing()
        # Push add line
        hwnd = win32gui.FindWindow(None, 'Building profiles')
        parent_hwnd = win32gui.GetParent(hwnd)
        text_parent = win32gui.GetWindowText(parent_hwnd)
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.AppActivate(text_parent)
        shell.SendKeys("^.")

    def CreateLines(self):
        lin0 = QgsVectorLayer("LineString", "New_Line", "memory")
        crs = QgsProject.instance().crs()
        lin0.setCrs(crs)
        lin0.dataProvider().addAttributes([QgsField('ID', QVariant.Int)])
        lin0.updateExtents()
        QgsProject.instance().addMapLayer(lin0)
        lin0.startEditing()
        # Push add line
        hwnd = win32gui.FindWindow(None, 'Building profiles')
        parent_hwnd = win32gui.GetParent(hwnd)
        text_parent = win32gui.GetWindowText(parent_hwnd)
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.AppActivate(text_parent)
        shell.SendKeys("^.")


    def Grid(self):
        path = self.dlg_grid.mQgsFileWidget.filePath()
        num_fly = int(self.dlg_grid.num_fly.text())
        layer_template = self.dlg_grid.layer_template.text()
        layer_counter_start = int(self.dlg_grid.layer_counter.text()) - 1
        num_points = int(self.dlg_grid.num_points.text())
        radius = float(self.dlg_grid.radius.text())


        try:
            hp_layer = self.dlg_grid.home_point.currentLayer()
    
            features = hp_layer.getFeatures()
        
            for feature in features:
                geom = feature.geometry()
                geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
                if geomSingleType:
                    x = geom.asPoint().x()
                    y = geom.asPoint().y()
                else:
                    x = geom.asMultiPoint()[0][0]
                    y = geom.asMultiPoint()[0][1]
                break
    
            hp_coord = (x, y)
        except:
            pass

        Step_PK = float(self.dlg_grid.Step_PK.text())
        Step_PR = float(self.dlg_grid.Step_PR.text())
        Num_PR = int(self.dlg_grid.Num_PR.text())
        OffsetPK = float(self.dlg_grid.Offset_PK.text())
        OffsetPR = float(self.dlg_grid.Offset_PR.text())
        len_pr = float(self.dlg_grid.len_pr.text())
        Start_PK = 1
        Start_PR = 1
        SNP = 1
        SNPk = 1
        line_layer = self.iface.activeLayer()

        if line_layer==None or line_layer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выделен слой с линией-вектором"); mbox.exec_(); return
        if line_layer.featureCount() == 0:
            mbox.setText("Нужно нарисовать линию-вектор в активном слое линий"); mbox.exec_(); return
        features = line_layer.getFeatures()

        for feature in features:
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.LineGeometry:
                if geomSingleType:
                    xy=geom.asPolyline()
                    point1x=xy[0][0]; point1y=xy[0][1]; point2x=xy[1][0]; point2y=xy[1][1];
                    lenght=geom.length()
                else:
                    xy=geom.asMultiPolyline()
                    point1x=xy[0][0].x(); point1y=xy[0][0].y(); point2x=xy[0][1].x(); point2y=xy[0][1].y();
                    lenght=geom.length()
            else:
                mbox.setText("Должен быть выделен слой с линией-вектором")
                mbox.show()
                mbox.exec_()
                return


        fly_shift = Step_PR * Num_PR
        for k in range(num_fly):
            # Calculate Values
            layer_counter_start += 1
            d = point2x-point1x
            h = point2y-point1y
            cosa = d/lenght
            sina = h/lenght
            point1xx = (point1x+OffsetPK*cosa)+(OffsetPR+fly_shift*k)*sina
            point1yy = (point1y+OffsetPK*sina)-(OffsetPR+fly_shift*k)*cosa
            point2xx = (point2x+OffsetPK*cosa)+(OffsetPR+fly_shift*k)*sina
            point2yy = (point2y+OffsetPK*sina)-(OffsetPR+fly_shift*k)*cosa

            num_PK = int(abs(len_pr) / abs(Step_PK))+1
            
            f = num_PK * Num_PR
            ff = f
    
            crs = line_layer.crs()
            targetCrs = QgsCoordinateReferenceSystem('EPSG:4326')
            transformContext = QgsProject.instance().transformContext()
            xform = QgsCoordinateTransform(crs, targetCrs, transformContext)
    

            # Calculate and Add attributes in array
            gridArray = []
            for j in range (1, Num_PR+1):
                for i in range (1, num_PK+1):
                    ff -= 1
                    if ff % 10000 == 0:
                        self.dlg_grid.progressBar.setValue(((f-ff)/f)*50)
                        QApplication.processEvents()
    
                    XX = (point1xx+(i-1)*Step_PK*cosa)+Step_PR*sina*(j-1)
                    YY = (point1yy+(i-1)*Step_PK*sina)-Step_PR*cosa*(j-1)
    
                    a = QgsPointXY(XX, YY)
                    xyTarget = xform.transform(a)
                    lat = xyTarget.y()
                    lon = xyTarget.x()
    
                    gridArray.append((j, i, XX, YY, lon, lat))


            # Create 8
            theta1 = np.linspace(0 , 2 * np.pi, num_points)
            theta2 = np.linspace(2 * np.pi, 0, num_points)

            x1 = radius * np.cos(theta1)
            y1 = radius * np.sin(theta1)
            x2 = radius * np.cos(theta2)
            y2 = radius * np.sin(theta2) 

            cos_turn = math.cos(math.radians(180))
            sin_turn = math.sin(math.radians(180))

            xy1 = []
            xy2 = []
            for i in range(len(x1)):
                xy1.append((x1[i], y1[i]))
                xy2.append((x2[i]*cos_turn + y2[i]*sin_turn, y2[i]*cos_turn - x2[i]*sin_turn))


            try:
                arr_8 = [xy1, xy2]
                xy = []
            
                for j in range(2):
                    for i in range(len(x1)):
                        x_t = hp_coord[0] + arr_8[j][i][0] + radius*2*j
                        y_t = hp_coord[1] + arr_8[j][i][1]
                        a = QgsPointXY(x_t, y_t)
                        xyTarget = xform.transform(a)
                        lat = xyTarget.y()
                        lon = xyTarget.x()
        
                        xy.append((x_t-radius, y_t, lon, lat))
    
                    if j == 0:
                        del xy[-1]
    
                a = QgsPointXY(xy[-1][0], xy[-1][1]+50)
                xyTarget = xform.transform(a)
                lat = xyTarget.y()
                lon = xyTarget.x()
    
                xy.append((xy[-1][0], xy[-1][1]+50, lon, lat))

            except:
                pass

                            
            # Create new Layer
            layer_name = layer_template + str(layer_counter_start) 
            grid_layer = QgsVectorLayer("Point", layer_name, "memory")
    
            pr = grid_layer.dataProvider()
            crs = line_layer.crs()
            if crs.authid() == "EPSG:4326":
                mbox.setText("Нельзя построить в системе координат WGS 84\nСистема координат слоя должна быть прямоугольной")
                mbox.show()
                mbox.exec_()
                return
            grid_layer.setCrs(crs)
    
            pr.addAttributes([QgsField('Name', QVariant.String), 
                              QgsField('PR', QVariant.Int),
                              QgsField('PK', QVariant.Int),
                              QgsField('ELEV', QVariant.Double,'double', 20, 3),
                              QgsField('LON', QVariant.Double,'double', 20, 7),
                              QgsField('LAT', QVariant.Double,'double', 20, 7),
                              QgsField('ROUTE', QVariant.Int),
                              ])
    
            grid_layer.updateFields()
    

            # Add attributes in new Layer
            ff = f / 2
            fets = []
            if self.dlg_grid.build_8.isChecked():
                for i, val in enumerate(xy):
                    fet = QgsFeature()
                    fet.setGeometry(QgsPoint(val[0], val[1]))
                    attrs = ['∞', 0, i, None, val[2], val[3], 82]

                    fet.setAttributes(attrs)
                    fets.append(fet)
    
            for i in gridArray:
                ff -= 0.5
                if ff % 5000 == 0:
                    self.dlg_grid.progressBar.setValue(((f-ff)/f)*100)
                    QApplication.processEvents()
                fet = QgsFeature()
                fet.setGeometry(QgsPoint(i[2], i[3]))
                Name = str(i[0])+', '+str(i[1])
                attrs = [Name, i[0], i[1], None, i[4], i[5], 16]
                fet.setAttributes(attrs)
                fets.append(fet)

            pr.addFeatures(fets)
            grid_layer.updateExtents()
    
            QgsProject.instance().addMapLayer(grid_layer)


            if self.dlg_grid.save_check_btn.isChecked():
                options = QgsVectorFileWriter.SaveVectorOptions()
                options.driverName = "ESRI Shapefile"
                options.layerName = grid_layer.name()
                QgsVectorFileWriter.writeAsVectorFormatV3(grid_layer, path + '\\' + layer_name + '.shp', QgsCoordinateTransformContext(), options)
                vlayer = QgsVectorLayer(path + '\\' + layer_name + '.shp', layer_name, "ogr")
                QgsProject.instance().removeMapLayer(grid_layer)
                QgsProject.instance().addMapLayer(vlayer)


        if self.dlg_grid.remove_line_check_btn.isChecked():
            QgsProject.instance().removeMapLayer(line_layer)
        else:
            self.iface.setActiveLayer(line_layer)


        self.dlg_grid.progressBar.setValue(0)
        self.iface.messageBar().pushMessage("Grid points created success", level=Qgis.Success, duration=5)


    #--------------------------------------------------------------------------
    # Second Window
    #--------------------------------------------------------------------------

    #def get_alt(self):
#
    #    tool = PointTool(self.iface.mapCanvas(), parent=self.iface) #define this class as parent
    #    self.iface.mapCanvas().setMapTool(tool)
#
    #    rlayer = self.dlg_export.input_rlayer_CB.currentLayer()
    #    print(rlayer)



    #def bind_alt_home(self, point, ui):
#
    #    rlayer = ui.input_rlayer_CB.currentLayer()
    #    rpr = rlayer.dataProvider()
#
    #    alt_home = rpr.identify(point, QgsRaster.IdentifyFormatValue).results()[1]
    #    print('home', point, alt_home)







    def import_layer(self):
        data = []
        fieldList = []
        layer = self.dlg_export.input_layer_CB.currentLayer()
        [fieldList.append(field.name()) for field in layer.fields()]
        features = layer.getFeatures()
        data.append(fieldList)
        for feature in features:
            attrs = feature.attributes()
            strAttrs = []
            for attr in attrs:
                try:
                    strAttrs.append(str(round(attr, 7)))
                except:
                    strAttrs.append(str(attr))
            data.append(strAttrs)

        vert = []
        for i in range(len(data)):
            vert.append(str(i+1))


        self.dlg_export.tableWidget.setRowCount(len(data)-1)
        self.dlg_export.tableWidget.setColumnCount(len(data[0]))
        self.dlg_export.tableWidget.setHorizontalHeaderLabels(data[0])
        self.dlg_export.tableWidget.setVerticalHeaderLabels(vert)

        for i in range(1, len(data)):
            for j in range(len(data[0])):
                self.dlg_export.tableWidget.setItem(i-1, j, QTableWidgetItem(data[i][j]))

        self.dlg_export.tableWidget.setColumnWidth(0, 35)
        self.dlg_export.tableWidget.setColumnWidth(1, 35)
        self.dlg_export.tableWidget.setColumnWidth(2, 35)
        self.dlg_export.tableWidget.setColumnWidth(3, 60)
        self.dlg_export.tableWidget.setColumnWidth(4, 70)
        self.dlg_export.tableWidget.setColumnWidth(5, 70)
        self.dlg_export.tableWidget.setColumnWidth(6, 50)


    def bind_elev(self):
        print('bind')
        rlayer = self.dlg_export.input_rlayer_CB.currentLayer()
        vlayer = self.dlg_export.input_layer_CB.currentLayer()
        vlayer.startEditing()
        if vlayer.type() != QgsMapLayerType.VectorLayer:
            mbox.setText("Должен быть выбран векторный слой с точками")
            mbox.show()
            mbox.exec_()
            return
        f = vlayer.featureCount()
        ff = f
        features = vlayer.getFeatures()

        test_none = 0

        geom = vlayer.getFeature(1).geometry()
        geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
        if geomSingleType:
            xy = geom.asPoint()
            try:
                ident = rpr.identify(QgsPointXY(xy.x(), xy.y()), 1)
                IFV = 1
            except:
                IFV = QgsRaster.IdentifyFormatValue
        else:
            xy = geom.asMultiPoint()
            try:
                ident = rpr.identify(QgsPointXY(xy[0].x(), xy[0].y()), 1)
                IFV = 1
            except:
                IFV = QgsRaster.IdentifyFormatValue

        fc = vlayer.fields().count()
        vpr = vlayer.dataProvider()
        rpr = rlayer.dataProvider()

        for i, field in enumerate(vlayer.fields()):
            if field.name()=="ELEV":
                fc = i

        if vlayer.providerType()=="memory":
            for field in vlayer.fields():
                if field.name()=="Z":
                    mbox.setText('Поле Z уже есть в таблице')
                    mbox.show()
                    mbox.exec_()
                    return
        for i in vlayer.getFeatures():
            if i.geometry().type() == 1 or i.geometry().type() == 2:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                mbox.exec_()
                return
            break
        if not rlayer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("В окне DEM должен быть выбран растровый слой рельефа")
            mbox.show()
            mbox.exec_()
            return
        vcrs = vlayer.crs()
        rcrs = rlayer.crs()
        if not vcrs==rcrs:
            mbox.setText("Проекции растра и точек не совпадают")
            mbox.show()
            mbox.exec_()
            return
        path = vpr.dataSourceUri()
        pp=path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
        if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
            mbox.setText("Работает только с шейп файлами")
            mbox.show()
            mbox.exec_()
            return

        for i in features:
            ff-=1
            if ff%200==0:
                self.dlg_export.progressBar.setValue(((f-ff)/f)*100)
                QApplication.processEvents()
            geom = i.geometry()

            if not geom.type() == 0:
               continue

            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())

            if geomSingleType:
                xy = geom.asPoint()
                ident = rpr.identify(QgsPointXY(xy.x(), xy.y()), IFV)
            else:
                xy = geom.asMultiPoint()
                ident = rpr.identify(QgsPointXY(xy[0].x(), xy[0].y()), IFV)

            if ident.results()=={}:

                mbox.setText("Недоступный источник растра во вкладке DEM")
                mbox.show()
                mbox.exec_()
                return

            z = ident.results()[1]

            if z == None:
                test_none = 1

            ids = i.id()
            attr_value = {fc : z}
            vpr.changeAttributeValues({ids:attr_value})

        vlayer.updateFields()
        vlayer.commitChanges()
        self.dlg_export.progressBar.setValue(0)
        self.iface.messageBar().pushMessage("Elevation added in current layer", 
            level=Qgis.Success, duration=5)

        
        self.import_layer()

        if test_none == 1:
            mbox.setText("Есть пустые значения высот")
            mbox.show()
            mbox.exec_()
            return

        mboxi.setText("Высоты добавлены")
        mboxi.show()
        mboxi.exec_()


    def modify(self, cor):
        print('modify')

        self.mod = 1

        home_alt = float(self.dlg_export.home_alt.text())
        flight_alt = float(self.dlg_export.flight_alt.text())

        # Get input data
        col_cnt = self.dlg_export.tableWidget.columnCount()
        row_cnt = self.dlg_export.tableWidget.rowCount()

        input_data_dir = []
        input_data_rev = []
        new_dir = 0
        for i in range(row_cnt):
            line = []
            for j in range(col_cnt):
                item = self.dlg_export.tableWidget.item(i, j).text()
                line.append(item)

            if int(line[1]) % 2 != 0:
                if new_dir == 1:
                    input_data_rev.reverse()
                    input_data_dir.extend(input_data_rev)
                    input_data_rev = []
                input_data_dir.append(line)
                new_dir = 0
            elif int(line[1]) % 2 == 0:

                new_dir = 1
                input_data_rev.append(line)

        if new_dir == 1:
            input_data_rev.reverse()
            input_data_dir.extend(input_data_rev)


        # Modify data for waypoint
        vert = []
        self.modify_data = []
        self.modify_data.append(('0', '1', '0', '16', '0', '0', '0', '0', '0', '0', '0', '1'))
        for i, line in enumerate(input_data_dir):
            if cor == None:
                alt_rel = str(round(float(line[3]) - home_alt + flight_alt, 3))
            else:
                alt_rel = str(cor[i])
            self.modify_data.append((str(i), '0', '3', line[6], '0', '0', '0', '0', line[5], line[4], alt_rel, '1'))
            vert.append(str(i+1))
        self.modify_data.append((str(i+1), '0', '3', '20', '0', '0', '0', '0', '0', '0', '0', '1'))


        self.dlg_export.tableWidget_2.setRowCount(len(self.modify_data))
        self.dlg_export.tableWidget_2.setColumnCount(12)
        self.dlg_export.tableWidget_2.setVerticalHeaderLabels(vert)
        #self.dlg_export.tableWidget_2.horizontalHeader().setDefaultSectionSize(60)    
        for i in range(8):
            self.dlg_export.tableWidget_2.setColumnWidth(i, 30)
        self.dlg_export.tableWidget_2.setColumnWidth(8, 70)
        self.dlg_export.tableWidget_2.setColumnWidth(9, 70)
        self.dlg_export.tableWidget_2.setColumnWidth(10, 50)
        self.dlg_export.tableWidget_2.setColumnWidth(11, 30)

        for i in range(len(self.modify_data)):
            for j in range(len(self.modify_data[0])):
                self.dlg_export.tableWidget_2.setItem(i, j, QTableWidgetItem(self.modify_data[i][j]))



    def export_waypoints(self):
        if self.dlg_export.mQgsFileWidget.filePath() == '':
            mbox.setText("Нужно выбрать путь к папке для сохранения")
            mbox.show()
            mbox.exec_()
            return

        vlayer = self.dlg_export.input_layer_CB.currentLayer().name()
        directory = self.dlg_export.mQgsFileWidget.filePath() + '/'
        path = directory + vlayer + '.waypoints'

        strr = 'QGC WPL 110' 

        with open(path, 'w', encoding = 'Windows-1251') as f:
            f.write(strr + '\n')
            line = []
            for i in self.modify_data:
                line = '\t'.join(i)
                f.write(line + '\n')

        self.iface.messageBar().pushMessage("Waypoints file has been created", level=Qgis.Success, duration=6)


    def correction(self):
        if self.mod == 1:
            dist_arr, dist_delta, dem_alt, fly_alt, minmax, delta_alt, delta_grad, nools, minmax_grad, delta_grad_mm = self.fly_alt()
    
            coef = float(self.dlg_export.correct_coef.text())
            flight_alt_0 = float(self.dlg_export.flight_alt.text())
            home_alt = float(self.dlg_export.home_alt.text())
    
            fly_alt_correct = []

            cnt = 0
            for i in range(1, len(delta_grad)-1):
                x0 = delta_grad[i-1]
                x1 = delta_grad[i]
                x2 = delta_grad[i+1]
                

                if x2 < 0 and x0 < 0 and x1 < 0:
                    d = round((abs((x2+x0)/2))-abs(x1), 3)
                elif x2 > 0 and x0 > 0 and x1 > 0:
                    d = round((abs((x2+x0)/2))-abs(x1), 3)
                elif x2 < 0 and x0 < 0 and x1 > 0:
                    d = round((abs((x2+x0)/2))+abs(x1), 3)
                elif x2 > 0 and x0 > 0 and x1 < 0:
                    d = round((abs((x2+x0)/2))+abs(x1), 3)
                else:
                    d = round((abs((x2+x0)/2))-abs(x1), 3)


                test = round((abs(x2)-abs(x0))/2, 3)
                
                if abs(d) > 29 and abs(test) < 15:
                    cnt += 1
                    delta_grad[i] = round((x2+x0)/2, 3)
                else:
                    cnt = 0

                #print(cnt, x1, test)

    
            for i, alt in enumerate(delta_grad):
                correct_item = (flight_alt_0*coef/100) * abs(alt/100)
                fly_alt_correct.append(round(fly_alt[i]+correct_item-home_alt, 3))
    
    
            self.modify(fly_alt_correct)

            self.mod = 0
        else:
            pass


    def fly_alt(self):
        # Get input data
        home_alt = float(self.dlg_export.home_alt.text())
        col_cnt = self.dlg_export.tableWidget.columnCount()
        row_cnt = self.dlg_export.tableWidget.rowCount()
        col_2_cnt = self.dlg_export.tableWidget_2.columnCount()
        row_2_cnt = self.dlg_export.tableWidget_2.rowCount()

        layer = self.dlg_export.input_layer_CB.currentLayer()


        # dist
        crs = QgsCoordinateReferenceSystem('EPSG:4326')
        targetCrs = layer.crs()
        transformContext = QgsProject.instance().transformContext()
        xform = QgsCoordinateTransform(crs, targetCrs, transformContext)

        gridArray = []
        for i in range(1, row_2_cnt-1):
            line = []
            for j in range(col_2_cnt):
                item = self.dlg_export.tableWidget_2.item(i, j).text()
                line.append(item)


            a = QgsPointXY(float(line[-3]), float(line[-4]))

            xyTarget = xform.transform(a)

            XX = xyTarget.x()
            YY = xyTarget.y()

            gridArray.append((XX, YY, float(line[-2]))) 

        
        dist_arr = [0]
        dist_delta = [0]

        dist = 0
        for i in range(1, len(gridArray)):
            x0 = gridArray[i-1][0]
            x1 = gridArray[i][0]
            y0 = gridArray[i-1][1]
            y1 = gridArray[i][1]
            dist += ((x1-x0)**2+(y1-y0)**2)**0.5
            dist_arr.append(round(dist, 1))
            dist_delta.append(((x1-x0)**2+(y1-y0)**2)**0.5)


        input_data_dir = []
        input_data_rev = []
        new_dir = 0

        for i in range(row_cnt):
            line = []
            for j in range(col_cnt):
                item = self.dlg_export.tableWidget.item(i, j).text()
                line.append(item)

            if int(line[1]) % 2 != 0:
                if new_dir == 1:
                    input_data_rev.reverse()
                    input_data_dir.extend(input_data_rev)
                    input_data_rev = []
                input_data_dir.append((int(line[1]), int(line[2]), float(line[3])))
                new_dir = 0
            elif int(line[1]) % 2 == 0:

                new_dir = 1
                input_data_rev.append((int(line[1]), int(line[2]), float(line[3])))

        if new_dir == 1:
            input_data_rev.reverse()
            input_data_dir.extend(input_data_rev)

        dem_alt = []
        fly_alt = []


        dem_alt = [round(i[2], 3) for i in input_data_dir]

        for i in range(1, row_2_cnt-1):
            line = []
            for j in range(col_2_cnt):
                item = self.dlg_export.tableWidget_2.item(i, j).text()
                line.append(item)

            fly_alt.append(round((home_alt + float(line[-2])), 3))

        minmax = [min(dem_alt), max(dem_alt), min(fly_alt), max(fly_alt)]
        delta_alt = max(minmax) - min(minmax)


        delta_grad = [0]
        nools = [0]
        for i in range(1, len(fly_alt)):
            alt0 = fly_alt[i-1]
            alt1 = fly_alt[i]
            delta_grad.append(round(((alt1 - alt0)/dist_delta[i])*100, 2))
            nools.append(0)

        minmax_grad = [min(delta_grad), max(delta_grad)]
        delta_grad_mm = max(delta_grad) - min(delta_grad)

        return dist_arr, dist_delta, dem_alt, fly_alt, minmax, delta_alt, delta_grad, nools, minmax_grad, delta_grad_mm
        

    def graphics(self):
        
        dist_arr, dist_delta, dem_alt, fly_alt, minmax, delta_alt, delta_grad, nools, minmax_grad, delta_grad_mm = self.fly_alt()

        # Plot
        plt.style.use("dark_background")

        for param in ['text.color', 'axes.labelcolor', 'xtick.color', 'ytick.color']:
            plt.rcParams[param] = '0.9'  # very light grey
        
        for param in ['figure.facecolor', 'axes.facecolor', 'savefig.facecolor']:
            plt.rcParams[param] = '#212946'  # bluish dark grey
        
        colors_1 = [
            '#08F7FE',  # teal/cyan
            '#00ff41',  # matrix green
        ]

        colors_rev_1 = [
            '#00ff41',  # matrix green
            '#08F7FE',  # teal/cyan
        ]

        colors_2 = [
            '#F5D300',  # yellow
            '#FE53BB',  # pink
        ]

        colors_rev_2 = [
            '#FE53BB',  # pink
            '#F5D300',  # yellow
        ]
        



        df = pd.DataFrame({'DEM': dem_alt, 'fly' : fly_alt, 'dist': dist_arr})
        dfx = pd.DataFrame({'DEM': dem_alt, 'fly' : fly_alt})

        df_grad = pd.DataFrame({'incline': delta_grad, 'flat' : nools, 'dist': dist_arr})
        df_grad_x = pd.DataFrame({'incline': delta_grad, 'flat' : nools})

        fig = None
        fig, ax = plt.subplots(2, 1, figsize=[12, 6])
        plt.subplots_adjust(top=0.97, bottom=0.1, left=0.06, right=0.96, hspace=0.1)
        
        
        # Redraw the data with low alpha and slighty increased linewidth:
        n_shades = 10
        diff_linewidth = 1.05
        alpha_value = 0.3 / n_shades
        
        # First plot
        df.plot(x='dist', y=['fly', 'DEM'], marker='o', markersize=0.8, linewidth=0.5, color=colors_1, ax=ax[0])

        for n in range(1, n_shades+1):
        
            df.plot(x='dist', 
                    y=['fly', 'DEM'],
                    marker='o',
                    markersize=2,
                    linewidth=1+(diff_linewidth*n),
                    alpha=alpha_value,
                    legend=False,
                    ax=ax[0],
                    color=colors_1)
            
        # Color the areas below the lines:
        for column, color in zip(dfx, colors_rev_1):

            ax[0].fill_between(x=df['dist'].values,
                            y1=dfx[column].values,
                            y2=[0] * len(dfx),
                            color=color,
                            alpha=0.1)
            
        ax[0].grid(color='#2A3459')
        ax[0].set_ylabel('Высота, м')
            
        ax[0].set_xlim([0, dist_arr[-1]])
        ax[0].set_ylim(min(minmax)-delta_alt/20, max(minmax)+delta_alt/20)

        # Second plot
        df_grad.plot(x='dist', y=['flat', 'incline'], marker='o', markersize=0.8, linewidth=0.5, color=colors_2, ax=ax[1])

        for n in range(1, n_shades+1):
        
            df_grad.plot(x='dist', 
                    y=['flat', 'incline'],
                    marker='o',
                    markersize=2,
                    linewidth=1+(diff_linewidth*n),
                    alpha=alpha_value,
                    legend=False,
                    ax=ax[1],
                    color=colors_2)
            
        # Color the areas below the lines:
        for column, color in zip(df_grad_x, colors_rev_2):

            ax[1].fill_between(x=df_grad['dist'].values,
                            y1=df_grad_x[column].values,
                            y2=[0] * len(df_grad_x),
                            color=color,
                            alpha=0.1)
            
        ax[1].grid(color='#2A3459')
        ax[1].set_ylabel('Уклон, %')
            
        ax[1].set_xlim([0, dist_arr[-1]])
        ax[1].set_ylim(minmax_grad[0]-delta_grad_mm/20, minmax_grad[1]+delta_grad_mm/20)
        
        plt.show()



    #--------------------------------------------------------------------------
    def run_gridding(self):
        self.dlg_grid = profilesDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_grid.show()
        # Buttons click
        self.dlg_grid.Grid.clicked.connect(self.Grid)
        self.dlg_grid.CreateLine.clicked.connect(self.CreateLines)
        self.dlg_grid.CreatePoint.clicked.connect(self.CreatePoints)

        self.dlg_grid.home_point.setFilters(QgsMapLayerProxyModel.PointLayer)

        self.cfg_lines_path = self.plugin_dir + '/cfg_lines.ini'
        self.cfg_lines_path_path = self.plugin_dir + '/cfg_lines_path.ini'

    
        with open(self.cfg_lines_path_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            self.dlg_grid.mQgsFileWidget.setFilePath(cfg[0][1])

        with open(self.cfg_lines_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            self.dlg_grid.Step_PK.setText(cfg[0][1])
            self.dlg_grid.len_pr.setText(cfg[1][1])
            self.dlg_grid.Offset_PK.setText(cfg[2][1])
            self.dlg_grid.Step_PR.setText(cfg[3][1])
            self.dlg_grid.Num_PR.setText(cfg[4][1])
            self.dlg_grid.Offset_PR.setText(cfg[5][1])
            self.dlg_grid.num_fly.setText(cfg[6][1])
            self.dlg_grid.layer_template.setText(cfg[7][1])
            self.dlg_grid.layer_counter.setText(cfg[8][1])
            self.dlg_grid.save_check_btn.setCheckState(int(cfg[9][1]))
            self.dlg_grid.remove_line_check_btn.setCheckState(int(cfg[10][1]))
            self.dlg_grid.build_8.setCheckState(int(cfg[11][1]))
            self.dlg_grid.num_points.setText(cfg[12][1])
            self.dlg_grid.radius.setText(cfg[13][1])


        self.dlg_grid.Step_PK.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.len_pr.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.Offset_PK.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.Step_PR.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.Num_PR.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.Offset_PR.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.num_fly.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.layer_template.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.layer_counter.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.save_check_btn.stateChanged.connect(self.change_cfg_lines)
        self.dlg_grid.remove_line_check_btn.stateChanged.connect(self.change_cfg_lines)
        self.dlg_grid.build_8.stateChanged.connect(self.change_cfg_lines)
        self.dlg_grid.num_points.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.radius.textChanged.connect(self.change_cfg_lines)

        self.dlg_grid.mQgsFileWidget.fileChanged.connect(self.change_path_lines)

        self.dlg_grid.closeEvent = self.closeEvent



    def run_layers_operations(self):
        self.dlg_export = export_waypointsDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_export.show()
        # Buttons click
        self.dlg_export.import_layer.clicked.connect(self.import_layer)
        self.dlg_export.bind_elev.clicked.connect(self.bind_elev)
        self.dlg_export.modify.clicked.connect(lambda: self.modify(cor=None))
        self.dlg_export.export_layer.clicked.connect(self.export_waypoints)
        self.dlg_export.graphic.clicked.connect(self.graphics)
        self.dlg_export.correct.clicked.connect(self.correction)
        #self.dlg_export.get_alt.clicked.connect(self.get_alt)

        self.dlg_export.input_layer_CB.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.dlg_export.input_rlayer_CB.setFilters(QgsMapLayerProxyModel.RasterLayer)

        self.dlg_export.mQgsFileWidget.fileChanged.connect(self.change_cfg_export)


        self.cfg_path = self.plugin_dir + '/cfg.ini'

        with open(self.cfg_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            self.dlg_export.home_alt.setText(cfg[0][1])
            self.dlg_export.flight_alt.setText(cfg[1][1])
            self.dlg_export.mQgsFileWidget.setFilePath(cfg[2][1])
            self.dlg_export.correct_coef.setText(cfg[3][1])


        self.dlg_export.home_alt.textChanged.connect(self.change_cfg_export)
        self.dlg_export.flight_alt.textChanged.connect(self.change_cfg_export)
        self.dlg_export.correct_coef.textChanged.connect(self.change_cfg_export)




    def change_path_lines(self):
        with open(self.cfg_lines_path_path, 'w') as f:
            f.write('path' + '\t' + self.dlg_grid.mQgsFileWidget.filePath() + '\n')

    def change_cfg_lines(self):
        with open(self.cfg_lines_path, 'w') as f:
            f.write('Step_PK' + '\t' + self.dlg_grid.Step_PK.text() + '\n')
            f.write('len_pr' + '\t' + self.dlg_grid.len_pr.text() + '\n')
            f.write('Offset_PK' + '\t' + self.dlg_grid.Offset_PK.text() + '\n')
            f.write('Step_PR' + '\t' + self.dlg_grid.Step_PR.text() + '\n')
            f.write('Num_PR' + '\t' + self.dlg_grid.Num_PR.text() + '\n')
            f.write('Offset_PR' + '\t' + self.dlg_grid.Offset_PR.text() + '\n')
            f.write('num_fly' + '\t' + self.dlg_grid.num_fly.text() + '\n')
            f.write('layer_template' + '\t' + self.dlg_grid.layer_template.text() + '\n')
            f.write('layer_counter' + '\t' + self.dlg_grid.layer_counter.text() + '\n')
            f.write('save_check' + '\t' + str(self.dlg_grid.save_check_btn.checkState()) + '\n')
            f.write('remove_check' + '\t' + str(self.dlg_grid.remove_line_check_btn.checkState()) + '\n')
            f.write('build_check' + '\t' + str(self.dlg_grid.build_8.checkState()) + '\n')
            f.write('num_points' + '\t' + self.dlg_grid.num_points.text() + '\n')
            f.write('radius' + '\t' + self.dlg_grid.radius.text() + '\n')




    def change_cfg_export(self):
        with open(self.cfg_path, 'w') as f:
            f.write('home_alt' + '\t' + self.dlg_export.home_alt.text() + '\n')
            f.write('flight_alt' + '\t' + self.dlg_export.flight_alt.text() + '\n')
            f.write('path' + '\t' + self.dlg_export.mQgsFileWidget.filePath() + '\n')
            f.write('coef' + '\t' + self.dlg_export.correct_coef.text() + '\n')


    def closeEvent(self, event):
        print("Close")


class PointTool(QgsMapTool):   
    def __init__(self, canvas,parent=None): #add parent parametre
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas    
        self.ui = export_waypointsDialog()
        self.parent = parent

    def canvasPressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            x = event.pos().x()
            y = event.pos().y()
            point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

            Geoprocess.bind_alt_home(Geoprocess, point, self.ui)

        elif event.button() == QtCore.Qt.RightButton:
            pass 
            #print('Press_Right')

    #def canvasMoveEvent(self, event):
        

    def canvasReleaseEvent(self, event):
        #Get the click

        
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        #print('release', point)


        #self.parent.dlg.X.setText(str(point[0])) # call parent(Projet) dialog
        #self.parent.dlg.Y.setText(str(point[1]))

    def activate(self):
        pass

    def deactivate(self):
        pass

    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return True