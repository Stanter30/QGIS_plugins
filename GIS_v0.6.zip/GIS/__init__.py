# -*- coding: utf-8 -*-
def classFactory(iface):
    from .GIS import GIS
    return GIS(iface)

