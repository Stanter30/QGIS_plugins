# -*- coding: utf-8 -*-
from .resources import *
from qgis.PyQt import uic
from qgis.PyQt import QtGui, QtCore, QtWidgets
from qgis.PyQt.QtCore import Qt, QTimer, QSize, QSettings, QTranslator, QCoreApplication, QVariant, QRect, QPoint, pyqtSignal, QTemporaryFile
from qgis.PyQt.QtGui import QIcon, QImage, QPixmap, QColor, QPainter, QPen, QBrush, QCursor
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from qgis.gui import QgsMapLayerComboBox, QgsMessageBar

import os
import time
import processing
from datetime import datetime
from PIL import Image
import torch
from torch import nn as nn
from torchvision.transforms import v2 as tfs_v2
import numpy as np
import pandas as pd
from tqdm import tqdm
import matplotlib.pyplot as plt

import rasterio
from rasterio.transform import from_bounds


class GIS:

    def __init__(self, iface):
        self.iface = iface

        self.plugin_dir = os.path.dirname(__file__)

        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'GIS_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.toolbar = self.iface.addToolBar(u'GIS')
        self.toolbar.setObjectName(u'GIS')

        # Ссылка на окно инструмента цветов, чтобы не создавать несколько экземпляров
        self.color_finder_window = None

    def add_action(self, icon_path, text, callback, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(True)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu('GIS', action)

        self.actions.append(action)

        return action

    def initGui(self):
        icon_path = ':/plugins/GIS/icon.png'
        self.add_action(icon_path, text='GIS', callback=self.run, parent=self.iface.mainWindow())

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu('GIS', action)
            self.iface.removeToolBarIcon(action)


    #----------------------------------------------------------------------
    
    def mode_geol(self):
        tile_size = 512
        out_channels = 32
        num_classes = 2
        lvl = 0.05
        input_tif = self.dlg_main.mQgsFileWidget_2.filePath()  # Путь к изображению

        rlayer = self.iface.activeLayer()
        rlayer_path = rlayer.source()
        crs = rlayer.crs().authid()

        model_path = "/model_geol_32.tar"
        mode = 0
        self.test(tile_size, out_channels, num_classes, lvl, rlayer_path, model_path, mode, crs)

    def mode_sat(self):
        tile_size = 512
        out_channels = 16
        num_classes = 8
        lvl = 0.8
        input_tif = self.dlg_main.mQgsFileWidget.filePath()  # Путь к изображению

        rlayer = self.iface.activeLayer()
        rlayer_path = rlayer.source()
        crs = rlayer.crs().authid()

        model_path = "/model_sat_16.tar"
        mode = 1
        self.test(tile_size, out_channels, num_classes, lvl, rlayer_path, model_path, mode, crs)


    def test(self, tile_size, out_channels, num_classes, lvl, input_tif, model_path, mode, crs):

        directory_path = os.path.dirname(input_tif)
        
        model = UNetModel(out_channels=out_channels, num_classes=num_classes)
        
        st = torch.load(self.plugin_dir + model_path, weights_only=False)
        model.load_state_dict(st)
        
        model.eval()
        
        img = Image.open(input_tif).convert('RGB')
        trnsf = tfs_v2.Compose([tfs_v2.ToImage(), tfs_v2.ToDtype(torch.float32, scale=True)])
        
        t0 = time.perf_counter()
        
        # Открываем изображение
        cnt = -1
        with Image.open(input_tif) as img:
            width, height = img.size
            print("WIDTH =", width, "HEIGHT =", height)
            output_image = Image.new('RGB', (width, height))
            empty_matrix = np.zeros((height, width), dtype='float32')
        
            # Итерируем по окнам изображения
            for i in tqdm(range(0, width, tile_size), desc="PROCESS", leave=True):
                QApplication.processEvents()
                for j in range(0, height, tile_size):
                    # Определяем координаты окна
                    box = [i, j, i + tile_size, j + tile_size]
        
                    # Обрезаем изображение
                    tile = img.crop(box).convert('RGB')
        
                    # Пропускаем через модель
                    tile = trnsf(tile)
                    tile = tile.unsqueeze(0)
                    p = model(tile).squeeze(0)
                    pp = p.permute(1, 2, 0)
                    x = nn.functional.sigmoid(pp)
        
                    xx = x.permute(2, 0, 1)
                    x = xx.detach().cpu().numpy()
        
                    # Сегментируем
                    a = np.zeros((tile_size, tile_size), dtype='float32')
                    for k in range(len(x)):
                        x[k][x[k] > lvl] = k
                        x[k][x[k] <= lvl] = 0
                        a += x[k]
        
                    # Края растра
                    if box[3] > height:
                        box[3] = box[1] + height - box[1]
                        a = a[0:box[3] - box[1], 0:box[2] - box[0]]
                    if box[2] > width:
                        box[2] = box[0] + width - box[0]
                        a = a[0:box[3] - box[1], 0:box[2] - box[0]]
        
                    # Вставка маленькой матрицы в большую
                    empty_matrix[box[1]:box[3], box[0]:box[2]] = a
        
        t1 = time.perf_counter()
        print(round(t1 - t0, 3))
        
        # Удаление мусора
        a = np.array(empty_matrix, dtype='uint8')
        a[a >= len(x)] = 0
        
        unique_values, counts = np.unique(a, return_counts=True)
        total = sum(counts)
        percentages = [round((num / total) * 100, 2) for num in counts]
        value_counts = dict(zip(unique_values, percentages))
        values = dict(sorted(value_counts.items(), key=lambda item: item[1], reverse=True))
        #print(values)
        
        for key in values:
            if values[key] < 0.2:
                values[key] = 0
                a[a == key] = 0
        
        unique_values, counts = np.unique(a, return_counts=True)
        total = sum(counts)
        percentages = [round((num / total) * 100, 2) for num in counts]
        value_counts = dict(zip(unique_values, percentages))
        values = dict(sorted(value_counts.items(), key=lambda item: item[1], reverse=True))
        #print(values)
        
        #np.save(directory_path + '/matrix.npy', a)
        
        img = Image.fromarray(a*32, mode='L')
        img.save(directory_path + '/output.tif')
        
        # Вставка координат в tif
        with rasterio.open(directory_path + '/output.tif') as src:

            # Исходный растр
            with rasterio.open(input_tif) as src_in:
                extent = src_in.bounds
                transform = from_bounds(extent[0], extent[1], extent[2], extent[3], width, height)
    
                meta = src.meta
                meta.update({'transform': transform})
            
                with rasterio.open(directory_path + '/output_image.tif', 'w', **meta) as dst:
                    dst.write(src.read())


        os.remove(directory_path + '/output.tif')
        raster_path = directory_path + '/output_image.tif'
        
        # Создаём объект растрового слоя
        raster_layer = QgsRasterLayer(raster_path, "output_image")

        QgsProject.instance().addMapLayer(raster_layer)

        raster_layer.setCrs(QgsCoordinateReferenceSystem(crs))

        if mode == 1:
            self.post(raster_layer)
    
            QgsProject.instance().removeMapLayer(raster_layer.id())
    
            #cmap = plt.get_cmap('viridis', num_classes)
            #plt.imshow(a, cmap)
            #plt.colorbar()
            #plt.show()



    def classification(self):
        t0 = time.perf_counter()
        rlayer_0 = self.iface.activeLayer()
        crs = rlayer_0.crs().authid()
        process_0 = processing.run("gdal:polygonize", {'INPUT':rlayer_0,'BAND':1,'FIELD':'DN','EIGHT_CONNECTEDNESS':False,'EXTRA':'','OUTPUT':'TEMPORARY_OUTPUT'})
        QApplication.processEvents()
        vlayer = QgsVectorLayer(process_0["OUTPUT"], "vector_1")

        rlayer = self.dlg_main.mMapLayerComboBox.currentLayer()

        red_lay = processing.run("native:zonalstatisticsfb", {'INPUT':vlayer,'INPUT_RASTER':rlayer,'RASTER_BAND':1,'COLUMN_PREFIX':'_','STATISTICS':[3],'OUTPUT':'TEMPORARY_OUTPUT'})
        green_lay = processing.run("native:zonalstatisticsfb", {'INPUT':vlayer,'INPUT_RASTER':rlayer,'RASTER_BAND':2,'COLUMN_PREFIX':'_','STATISTICS':[3],'OUTPUT':'TEMPORARY_OUTPUT'})
        blue_lay = processing.run("native:zonalstatisticsfb", {'INPUT':vlayer,'INPUT_RASTER':rlayer,'RASTER_BAND':3,'COLUMN_PREFIX':'_','STATISTICS':[3],'OUTPUT':'TEMPORARY_OUTPUT'})

        r_lvl = [feature[2] for feature in red_lay["OUTPUT"].getFeatures()]
        g_lvl = [feature[2] for feature in green_lay["OUTPUT"].getFeatures()]
        b_lvl = [feature[2] for feature in blue_lay["OUTPUT"].getFeatures()]

        color_data = np.column_stack((r_lvl, g_lvl, b_lvl)).tolist()

        # Заданные классы цветов
        classes = {
            0: (50, 50, 50),
            1: (241, 189, 165),
            2: (238, 170, 159),
            3: (235, 153, 141),
            4: (247, 190, 207),
            5: (244, 176, 197),
            6: (225, 154, 196),
            7: (220, 132, 182),
            8: (255, 242, 208),
            9: (254, 233, 168),
            10: (255, 228, 151),
            11: (244, 215, 123),
            12: (0, 165, 119),
            13: (230, 71, 53),
        }
        
        # Создаём DataFrame
        df = pd.DataFrame(color_data, columns=['R', 'G', 'B'])
        
        # Функция для вычисления ошибок и выбора класса
        def classify_color(r, g, b):
            errors = {}
            for cls, (r_ref, g_ref, b_ref) in classes.items():
                error = abs(r - r_ref) + abs(g - g_ref) + abs(b - b_ref)
                errors[cls] = error
            best_class = min(errors, key=errors.get)
            return best_class, errors[best_class]
        
        # Применяем к каждому объекту
        df[['Class', 'Min_Error']] = df.apply(
            lambda row: classify_color(row['R'], row['G'], row['B']), 
            axis=1, 
            result_type='expand'
        )
        
        vals = df.values

        # Выводим результат
        classes_new = vals[:, 3].tolist()

        # Добавить новый столбец (поле) в таблицу атрибутов
        field_name = 'class' 
        field_type = QVariant.Int 
        
        vlayer.startEditing()
        vlayer.addAttribute(QgsField(field_name, field_type))
        
        vlayer.updateFields()
        
        # Присвоить значения из списка по порядку
        for i, feature in enumerate(vlayer.getFeatures()):
            attr_index = vlayer.fields().indexFromName(field_name)
            vlayer.changeAttributeValue(feature.id(), attr_index, classes_new[i])
        
        # Selection
        expr = QgsExpression('DN = 32')
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in vlayer.getFeatures(request)]
        vlayer.selectByIds(ids)

        vlayer.commitChanges()

        # Начинаем редактирование
        vlayer.startEditing()
        
        # Индексы столбцов: 2-й столбец = индекс 1, 3-й столбец = индекс 2
        field_index_2 = 1  # второй столбец — проверяем на 32
        field_index_3 = 2  # третий столбец — меняем на 0
        
        # Создаём словарь изменений: {feature_id: {field_index: new_value}}
        attrs_to_update = {}
        
        # Обрабатываем только выделенные объекты
        for feat in vlayer.selectedFeatures():
            if feat[field_index_2] == 32:
                attrs_to_update[feat.id()] = {field_index_3: 0}
        
        # Применяем изменения всем выделенным объектам за один раз
        if attrs_to_update:
            vlayer.dataProvider().changeAttributeValues(attrs_to_update)
            vlayer.commitChanges()
            print(f"Обновлено {len(attrs_to_update)} объектов")
        else:
            vlayer.commitChanges()
            print("Нет выделенных объектов с условием 2-й столбец = 32.")


        fix_geom_layer = processing.run("native:fixgeometries", {'INPUT':vlayer,'METHOD':1,'OUTPUT':'TEMPORARY_OUTPUT'})["OUTPUT"]
        #QgsProject.instance().addMapLayer(fix_geom_layer)

        # Selection
        expr = QgsExpression('class = 0')
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in fix_geom_layer.getFeatures(request)]
        fix_geom_layer.selectByIds(ids)
        fix_geom_layer.setCrs(QgsCoordinateReferenceSystem(crs))

        t1 = time.perf_counter()
        print('time_vectorize', round(t1-t0, 3))

        self.cut_class_0(fix_geom_layer)


    def cut_class_0(self, layer):
        t0 = time.perf_counter()
        vlayer = layer
        extent = vlayer.extent()
        e1, e2, e3, e4 = extent.xMinimum(), extent.xMaximum(), extent.yMinimum(), extent.yMaximum()

        crs = vlayer.crs()
        crs_authid = crs.authid()

        if crs_authid == '':
            print('Нет системы координат')
            return

        mesh_size = float(self.dlg_main.mesh_size.text())
        ext = str(e1-mesh_size/2)+','+str(e2+mesh_size/2)+','+str(e3-mesh_size/2)+','+str(e4+mesh_size/2)



        # Сетка
        grid_layer = processing.run("native:creategrid", {   'TYPE':4,
                                                        'EXTENT':ext,
                                                        'HSPACING':mesh_size,'VSPACING':mesh_size,'HOVERLAY':0,'VOVERLAY':0,
                                                        'CRS':QgsCoordinateReferenceSystem(crs_authid),
                                                        'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']


        QgsProject.instance().addMapLayer(vlayer)


        # Сетка над 0 классом
        intersect_layer = processing.run("native:extractbylocation", {'INPUT':grid_layer,'PREDICATE':[0],
                                                    'INTERSECT':QgsProcessingFeatureSourceDefinition(vlayer.source(), 
                                                    selectedFeaturesOnly=True, featureLimit=-1, 
                                                    geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']



        # Слой Обрезка сетки
        cut_mesh_layer = processing.run("native:intersection", {'INPUT':QgsProcessingFeatureSourceDefinition(vlayer.source(),
                                                            selectedFeaturesOnly=True, featureLimit=-1, 
                                                            geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),
                                                            'OVERLAY':intersect_layer,
                                                            'INPUT_FIELDS':['class'],'OVERLAY_FIELDS':['id'],
                                                            'OVERLAY_FIELDS_PREFIX':'','OUTPUT':'TEMPORARY_OUTPUT','GRID_SIZE':None})['OUTPUT']


        # Уравнивание названий полей
        cut_mesh_layer.startEditing()
        fields = cut_mesh_layer.fields()
        rename_mapping = {
            "class": "fid",
            "id": "DN"
        }
        
        for field in fields:
            old_name = field.name()
            if old_name in rename_mapping:
                idx = cut_mesh_layer.fields().indexFromName(old_name)
                cut_mesh_layer.renameAttribute(idx, rename_mapping[old_name])
        

        # 2. Добавление нового столбца
        cut_mesh_layer.startEditing()
        new_field = QgsField("class", QVariant.Int)
        cut_mesh_layer.addAttribute(new_field)
        cut_mesh_layer.updateFields()
        cut_mesh_layer.commitChanges()
        
        # 3. Заполнение значений
        cut_mesh_layer.startEditing()
        idx_col1 = cut_mesh_layer.fields().indexFromName("fid")
        idx_col2 = cut_mesh_layer.fields().indexFromName("DN")
        idx_col3 = cut_mesh_layer.fields().indexFromName("class")
        
        for feature in cut_mesh_layer.getFeatures():
            feature.setAttribute(idx_col1, 0)
            feature.setAttribute(idx_col2, 32)
            feature.setAttribute(idx_col3, 0)
            cut_mesh_layer.updateFeature(feature)
        
        cut_mesh_layer.commitChanges()

        # Удаляем выделенные объекты
        vlayer.startEditing()
        vlayer.deleteSelectedFeatures()
        vlayer.commitChanges()

        # Копируем все объекты из второго слоя в активный
        features = cut_mesh_layer.getFeatures()
        vlayer.startEditing()
        vlayer.dataProvider().addFeatures(features)
        vlayer.commitChanges()

        # Selection
        expr = QgsExpression('class = 0')
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in vlayer.getFeatures(request)]
        vlayer.selectByIds(ids)

        QApplication.processEvents()
        t1 = time.perf_counter()
        print('time_def_class_0', round(t1-t0, 3))

        self.remove_class_0(vlayer)



    def remove_class_0(self, layer):
        t0 = time.perf_counter()


        cut_layer = processing.run("qgis:eliminateselectedpolygons", {  'INPUT':layer.source(),
                                                                        'MODE':2,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        QgsProject.instance().addMapLayer(cut_layer)

        t1 = time.perf_counter()
        print('time_remove_class_0', round(t1-t0, 3))


    def remove_small_polygons(self):
        vlayer = self.iface.activeLayer()

        square = int(self.dlg_main.square.text())

        # Selection
        expr = QgsExpression('$area < '+str(square))
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in vlayer.getFeatures(request)]
        vlayer.selectByIds(ids)

        cut_layer = processing.run("qgis:eliminateselectedpolygons", {  'INPUT':vlayer.source(),
                                                                        'MODE':2,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        QgsProject.instance().addMapLayer(cut_layer)


    def post_geol(self):
        t0 = time.perf_counter()

        vlayer = self.iface.activeLayer()
        tolerance = int(self.dlg_main.tolerance.text())
        
        lay_simp = processing.run("native:simplifygeometries", {'INPUT':vlayer,'METHOD':1,
                                                                'TOLERANCE':tolerance,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #QgsProject.instance().addMapLayer(lay_simp)

        lay_line = processing.run("native:polygonstolines", {'INPUT':lay_simp,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #QgsProject.instance().addMapLayer(lay_line)

        lay_pol = processing.run("native:polygonize", {'INPUT':lay_line,'KEEP_FIELDS':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #QgsProject.instance().addMapLayer(lay_pol)

        lay_polus = processing.run("native:poleofinaccessibility", {'INPUT':vlayer,'TOLERANCE':1,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #QgsProject.instance().addMapLayer(lay_polus)

        lay_pol_classifed = processing.run("native:joinattributesbylocation", {'INPUT':lay_pol,'PREDICATE':[0],'JOIN':lay_polus,'JOIN_FIELDS':['class'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        
        lay_pol_classifed.startEditing()

        # Выбираем объекты с пустыми значениями в поле "название_поля"
        request = QgsFeatureRequest().setFilterExpression('"class" IS NULL OR "название_поля" = \'\'')
        features_to_delete = [f.id() for f in lay_pol_classifed.getFeatures(request)]
        
        # Удаляем выбранные объекты
        lay_pol_classifed.deleteFeatures(features_to_delete)
        
        lay_pol_classifed.commitChanges()
        #QgsProject.instance().addMapLayer(lay_pol_classifed)

        # Overlap Polygon
        extent = vlayer.extent()
        extent = [extent.xMinimum(), extent.yMinimum(), extent.xMaximum(), extent.yMaximum()]  # Пример: лево, низ, право, верх
        
        # Создаем временный слой полигонов
        crs = vlayer.crs().authid()
        lay_overlap = QgsVectorLayer("Polygon", "Rectangle", "memory")
        lay_overlap.setCrs(QgsCoordinateReferenceSystem(crs))
        provider = lay_overlap.dataProvider()

        provider.addAttributes([QgsField("class", QVariant.Int)])
        lay_overlap.updateFields()
        
        # Создаем полигон из охвата
        rectangle = QgsGeometry.fromRect(QgsRectangle(*extent))
        
        # Добавляем объект в слой
        feature = QgsFeature()
        feature.setGeometry(rectangle)
        feature.setAttributes([0]) 
        provider.addFeature(feature)
        #QgsProject.instance().addMapLayer(lay_overlap)

        lay_diff = processing.run("native:difference", {'INPUT':lay_overlap,'OVERLAY':lay_pol_classifed,'OUTPUT':'TEMPORARY_OUTPUT','GRID_SIZE':None})['OUTPUT']
        #QgsProject.instance().addMapLayer(lay_diff)

        # Объединяем слои
        merged_layer = processing.run(
            "native:mergevectorlayers",
            {
                'LAYERS': [lay_diff, lay_pol_classifed],    # Список объединяемых слоёв
                'OUTPUT': 'memory:',                        # Результат в памяти (или путь к файлу)
                'ADD_SOURCE_FIELDS':False          
            },
            feedback=QgsProcessingFeedback()
        )['OUTPUT']
        
        QgsProject.instance().addMapLayer(merged_layer)

        # Selection 0
        expr = QgsExpression('"class" = 0')
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in merged_layer.getFeatures(request)]
        merged_layer.selectByIds(ids)

        lay_split = processing.run("native:multiparttosingleparts", {'INPUT':QgsProcessingFeatureSourceDefinition(merged_layer.source(), featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #QgsProject.instance().addMapLayer(lay_split)

        # Selection 0
        expr = QgsExpression('"class" = 0')
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in lay_split.getFeatures(request)]
        lay_split.selectByIds(ids)

        fin_lay = processing.run("qgis:eliminateselectedpolygons", {'INPUT':lay_split,'MODE':2,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        QgsProject.instance().addMapLayer(fin_lay)
        QgsProject.instance().removeMapLayer(merged_layer)


        self.style_geol(vlayer, fin_lay)

        t1 = time.perf_counter()
        print('time_remove_class_0', round(t1-t0, 3))


    def style_geol(self, source, target):

        target.setRenderer(source.renderer().clone())
        target.triggerRepaint()



    def open_color_finder(self):
        """Запуск инструмента определения средних цветов"""
        if self.color_finder_window is None:
            # Создаем окно, передавая главное окно QGIS как родителя
            self.color_finder_window = ColorFinderWindow(self.iface.mainWindow())
            # Сигнал для очистки ссылки при закрытии окна
            self.color_finder_window.destroyed.connect(self.on_color_finder_closed)
        
        self.color_finder_window.show()
        self.color_finder_window.raise_()
        self.color_finder_window.activateWindow()

    def on_color_finder_closed(self):
        """Сброс ссылки при закрытии окна инструмента"""
        self.color_finder_window = None



    # ----- SAT ------

    def post(self, layer):
        # 1 Polygonize
        rlayer = self.iface.activeLayer()
        aa = processing.run("gdal:polygonize", {'INPUT':rlayer,'BAND':1,'FIELD':'DN','EIGHT_CONNECTEDNESS':False,'EXTRA':'','OUTPUT':'TEMPORARY_OUTPUT'})
        print('1/3')
        QApplication.processEvents()
        layer_1 = QgsVectorLayer(aa["OUTPUT"], "vector_1")

        # 2 Merge polygons by class
        layer_2 = processing.run("native:dissolve", {'INPUT':layer_1,'FIELD':['DN'],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})
        print('2/3')
        QApplication.processEvents()

        # Selection 0
        expr = QgsExpression('"DN" = 0')
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in layer_2["OUTPUT"].getFeatures(request)]
        layer_2["OUTPUT"].selectByIds(ids)

        # 3 Remove 0 polygons
        layer_3 = processing.run("qgis:eliminateselectedpolygons", {'INPUT':layer_2["OUTPUT"],'MODE':2,'OUTPUT':'TEMPORARY_OUTPUT'})
        print('3/3')
        QgsProject.instance().addMapLayer(layer_3["OUTPUT"])

        self.style(layer_3["OUTPUT"])

        layer_3["OUTPUT"].setName("Output_1")


    def holes(self):
        layer = self.iface.activeLayer()
        scuare = int(self.dlg_main.min_radius.text())
        out = processing.run("native:multiparttosingleparts", {'INPUT':layer,'OUTPUT':'TEMPORARY_OUTPUT'})
        #QgsProject.instance().addMapLayer(out["OUTPUT"])

        # Selection
        expr = QgsExpression('$area <' + str(scuare))
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in out["OUTPUT"].getFeatures(request)]
        out["OUTPUT"].selectByIds(ids)

        # Change attrs
        out["OUTPUT"].startEditing()
        idx = out["OUTPUT"].fields().indexFromName("DN")
        attrs = {feat.id(): {idx: 999} for feat in out["OUTPUT"].selectedFeatures()}
        out["OUTPUT"].dataProvider().changeAttributeValues(attrs)
        out["OUTPUT"].commitChanges()

        # Merge polygons by class
        layer_2 = processing.run("native:dissolve", {'INPUT':out["OUTPUT"],'FIELD':['DN'],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})
        # Selection 999
        expr = QgsExpression('"DN" = 999')
        request = QgsFeatureRequest(expr)
        ids = [f.id() for f in layer_2["OUTPUT"].getFeatures(request)]
        layer_2["OUTPUT"].selectByIds(ids)

        # Remove polygons
        layer_3 = processing.run("qgis:eliminateselectedpolygons", {'INPUT':layer_2["OUTPUT"],'MODE':2,'OUTPUT':'TEMPORARY_OUTPUT'})
        QgsProject.instance().addMapLayer(layer_3["OUTPUT"])

        self.style(layer_3["OUTPUT"])

        layer_3["OUTPUT"].setName("Output_2")

    def style(self, layer):
        # ------------------------------------------------------------
        # 2. Поле, содержащее класс (уникальное значение)
        # ------------------------------------------------------------
        class_field = "DN"                 # <-- замените на имя вашего поля
        
        # ------------------------------------------------------------
        # 3. Список цветов для 8 классов
        # ------------------------------------------------------------
        # Можно использовать любые цвета – здесь простая палитра.
        colors = [
            QColor("#1b8020"),  # лес
            QColor("#4dd676"),  # поле
            QColor("#adbab3"),  # дорга
            QColor("#1cf0ff"),  # водоем
            QColor("#f56969"),  # постройки
            QColor("#fff700"),  # жд
        ]

        classes = ["Лес", "Поле", "Дорога", "Водоем", "Постройки", "Железная дорога"]
        
        # ------------------------------------------------------------
        # 4. Формируем список категорий
        # ------------------------------------------------------------
        categories = []
        for i, color in enumerate(colors):
            # Создаём символ (заполнение) для полигона
            symbol = QgsFillSymbol.createSimple({
                "color": color.name(),          # заливка
                "outline_color": "black",    # цвет контура (по желанию)
                "outline_width": "0.0"
            })
            # Текст подписи в легенде
            label = classes[i]
            # Создаём категорию
            category = QgsRendererCategory((i+1)*32, symbol, label)
            categories.append(category)
        
        # ------------------------------------------------------------
        # 5. Создаём и назначаем классифицированный рендерер
        # ------------------------------------------------------------
        renderer = QgsCategorizedSymbolRenderer(class_field, categories)
    
        layer.setRenderer(renderer)
        
        # ------------------------------------------------------------
        # 6. Обновляем отображение и сохраняем стиль (по желанию)
        # ------------------------------------------------------------
        layer.triggerRepaint()               # перерисовать слой в Canvas
        QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(True)


    #----------------------------------------------------------------------
    def run(self):
            
        self.dlg_main = main_dialog(self.iface, parent = self.iface.mainWindow())
        self.dlg_main.show()

        self.dlg_main.mMapLayerComboBox.setFilters(QgsMapLayerProxyModel.RasterLayer) 

        # Buttons click Geol
        self.dlg_main.btn_geol_segmentation.clicked.connect(self.mode_geol)
        self.dlg_main.btn_classification.clicked.connect(self.classification)
        self.dlg_main.btn_remove_small_polygons.clicked.connect(self.remove_small_polygons)
        self.dlg_main.btn_post_geol.clicked.connect(self.post_geol)

        self.dlg_main.btn_c.clicked.connect(self.open_color_finder)
        
        # Buttons click Sat
        self.dlg_main.btn_sat_segmentation.clicked.connect(self.mode_sat)
        self.dlg_main.btn_3.clicked.connect(self.holes)


# Dialog windows
FORM_CLASS_main, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'main.ui'))


class main_dialog(QtWidgets.QDialog, FORM_CLASS_main):
    def __init__(self, iface, parent):
        super(main_dialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface



class UNetModel(nn.Module):
    class _TwoConvLayers(nn.Module):
        def __init__(self, in_channels, out_channels):
            super().__init__()
            self.model = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
                nn.ReLU(inplace=True),
                nn.BatchNorm2d(out_channels),
                nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
                nn.ReLU(inplace=True),
                nn.BatchNorm2d(out_channels),
            )

        def forward(self, x):
            return self.model(x)

    class _EncoderBlock(nn.Module):
        def __init__(self, in_channels, out_channels):
            super().__init__()
            self.block = UNetModel._TwoConvLayers(in_channels, out_channels)
            self.max_pool = nn.MaxPool2d(2)

        def forward(self, x):
            x = self.block(x)
            y = self.max_pool(x)
            return y, x

    class _DecoderBlock(nn.Module):
        def __init__(self, in_channels, out_channels):
            super().__init__()
            self.transpose = nn.ConvTranspose2d(in_channels, out_channels, 2, stride=2)
            self.block = UNetModel._TwoConvLayers(in_channels, out_channels)

        def forward(self, x, y):
            x = self.transpose(x)
            u = torch.cat([x, y], dim=1)
            u = self.block(u)
            return u

    def __init__(self, in_channels=3, out_channels=None, num_classes=None):
        super().__init__()
        self.enc_block1 = self._EncoderBlock(in_channels, out_channels)
        self.enc_block2 = self._EncoderBlock(out_channels, out_channels * 2)
        self.enc_block3 = self._EncoderBlock(out_channels * 2, out_channels * 4)
        self.enc_block4 = self._EncoderBlock(out_channels * 4, out_channels * 8)

        self.bottleneck = self._TwoConvLayers(out_channels * 8, out_channels * 16)

        self.dec_block1 = self._DecoderBlock(out_channels * 16, out_channels * 8)
        self.dec_block2 = self._DecoderBlock(out_channels * 8, out_channels * 4)
        self.dec_block3 = self._DecoderBlock(out_channels * 4, out_channels * 2)
        self.dec_block4 = self._DecoderBlock(out_channels * 2, out_channels)

        self.out = nn.Conv2d(out_channels, num_classes, 1)

    def forward(self, x):
        x, y1 = self.enc_block1(x)
        x, y2 = self.enc_block2(x)
        x, y3 = self.enc_block3(x)
        x, y4 = self.enc_block4(x)

        x = self.bottleneck(x)

        x = self.dec_block1(x, y4)
        x = self.dec_block2(x, y3)
        x = self.dec_block3(x, y2)
        x = self.dec_block4(x, y1)
        return self.out(x)


# ----------------------------------------------------------------------
# Классы для инструмента определения цвета (из первого скрипта)
# ----------------------------------------------------------------------

class ImageLabel(QLabel):
    # Сигнал для уведомления о завершении выделения
    selection_finished = pyqtSignal()
    # Сигнал для обновления метки зума
    zoom_changed = pyqtSignal(int)
    # Сигнал для запроса прокрутки (панорамирования)
    pan_requested = pyqtSignal(int, int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.selection_start = None
        self.selection_end = None
        self.is_selecting = False

        # Параметры панорамирования
        self.is_panning = False
        self.pan_start = QPoint()

        # Параметры масштабирования
        self.zoom_level = 1.0
        self.min_zoom = 0.1
        self.max_zoom = 5.0
        self.zoom_step = 0.1
        self.original_pixmap = None

    def wheelEvent(self, event):
        if not self.original_pixmap:
            return
        delta = event.angleDelta().y()
        if delta > 0:
            new_zoom = self.zoom_level + self.zoom_step
        else:
            new_zoom = self.zoom_level - self.zoom_step

        new_zoom = max(self.min_zoom, min(self.max_zoom, new_zoom))

        if abs(new_zoom - self.zoom_level) > 0.001:
            self.zoom_level = new_zoom
            self.update_pixmap()
            self.zoom_changed.emit(int(self.zoom_level * 100))

    def update_pixmap(self):
        if self.original_pixmap:
            new_width = int(self.original_pixmap.width() * self.zoom_level)
            new_height = int(self.original_pixmap.height() * self.zoom_level)
            scaled_pixmap = self.original_pixmap.scaled(
                new_width, new_height,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.setPixmap(scaled_pixmap)
            self.setFixedSize(scaled_pixmap.size())
            self.setCursor(Qt.ArrowCursor)

    def set_original_pixmap(self, pixmap):
        self.original_pixmap = pixmap
        self.zoom_level = 1.0
        self.update_pixmap()

    def get_scaled_coordinates(self, point):
        if self.zoom_level > 0:
            x = int(point.x() / self.zoom_level)
            y = int(point.y() / self.zoom_level)
            return QPoint(x, y)
        return point

    def mousePressEvent(self, event):
        if event.button() == Qt.MiddleButton:
            self.is_panning = True
            self.pan_start = event.globalPos()
            self.setCursor(Qt.ClosedHandCursor)
            event.accept()
            return

        if event.button() == Qt.LeftButton:
            self.selection_start = self.get_scaled_coordinates(event.pos())
            self.selection_end = self.selection_start
            self.is_selecting = True
            self.update()

    def mouseMoveEvent(self, event):
        if self.is_panning:
            delta = event.globalPos() - self.pan_start
            self.pan_requested.emit(-delta.x(), -delta.y())
            self.pan_start = event.globalPos()
            return

        if self.is_selecting:
            self.selection_end = self.get_scaled_coordinates(event.pos())
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MiddleButton and self.is_panning:
            self.is_panning = False
            self.setCursor(Qt.ArrowCursor)
            event.accept()
            return

        if event.button() == Qt.LeftButton and self.is_selecting:
            self.is_selecting = False
            self.update()
            self.selection_finished.emit()

    def paintEvent(self, event):
        super().paintEvent(event)
        if self.is_selecting and self.selection_start and self.selection_end:
            painter = QPainter(self)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(255, 0, 0, 50))

            start_scaled = QPoint(
                int(self.selection_start.x() * self.zoom_level),
                int(self.selection_start.y() * self.zoom_level)
            )
            end_scaled = QPoint(
                int(self.selection_end.x() * self.zoom_level),
                int(self.selection_end.y() * self.zoom_level)
            )

            rect = QRect(start_scaled, end_scaled).normalized()
            painter.drawRect(rect)

    def reset_zoom(self):
        self.zoom_level = 1.0
        self.update_pixmap()

    def get_zoom_level(self):
        return int(self.zoom_level * 100)


class ColorFinderWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Average Color Finder")
        self.setGeometry(100, 100, 1200, 800)

        self.image = None
        self.pixmap = None
        self.current_color = None

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setAlignment(Qt.AlignCenter)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        self.container = QWidget()
        self.container_layout = QVBoxLayout()
        self.container_layout.setContentsMargins(0, 0, 0, 0)
        self.container.setLayout(self.container_layout)

        self.image_label = ImageLabel(self.container)
        self.container_layout.addWidget(self.image_label)

        self.scroll_area.setWidget(self.container)

        self.image_label.selection_finished.connect(self.calculate_average_color)
        self.image_label.zoom_changed.connect(self.update_zoom_label)
        self.image_label.pan_requested.connect(self.handle_pan)

        self.zoom_label = QLabel("Zoom: 100%")
        self.zoom_label.setAlignment(Qt.AlignCenter)
        self.zoom_label.setStyleSheet("font-weight: bold; padding: 5px;")

        self.zoom_in_button = QPushButton("Zoom In (+)")
        self.zoom_in_button.clicked.connect(lambda: self.adjust_zoom(0.1))

        self.zoom_out_button = QPushButton("Zoom Out (-)")
        self.zoom_out_button.clicked.connect(lambda: self.adjust_zoom(-0.1))

        self.zoom_reset_button = QPushButton("Reset Zoom (100%)")
        self.zoom_reset_button.clicked.connect(self.reset_zoom)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["№", "R", "G", "B", "Color"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setMaximumHeight(200)

        self.add_button = QPushButton("Add Color to Table")
        self.add_button.clicked.connect(self.add_color_to_table)
        self.add_button.setEnabled(False)

        self.open_button = QPushButton("📂 Open Image")
        self.open_button.clicked.connect(self.open_image)
        self.open_button.setStyleSheet("font-size: 12px; padding: 8px;")

        zoom_layout = QHBoxLayout()
        zoom_layout.addWidget(self.zoom_out_button)
        zoom_layout.addWidget(self.zoom_reset_button)
        zoom_layout.addWidget(self.zoom_in_button)
        zoom_layout.addWidget(self.zoom_label)

        main_buttons_layout = QHBoxLayout()
        main_buttons_layout.addWidget(self.open_button)
        main_buttons_layout.addWidget(self.add_button)

        main_layout = QVBoxLayout()
        main_layout.addLayout(main_buttons_layout)
        main_layout.addLayout(zoom_layout)
        main_layout.addWidget(self.scroll_area)
        main_layout.addWidget(self.table)

        self.info_label = QLabel("📌 Scroll wheel to zoom | Middle click drag to pan | Left click to select area")
        self.info_label.setAlignment(Qt.AlignCenter)
        self.info_label.setStyleSheet("padding: 10px; background-color: #f0f0f0;")
        main_layout.addWidget(self.info_label)

        self.central_widget.setLayout(main_layout)
        self.create_menu()

    def create_menu(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu('&File')
        open_action = file_menu.addAction('&Open Image\tCtrl+O')
        open_action.triggered.connect(self.open_image)
        file_menu.addSeparator()
        exit_action = file_menu.addAction('E&xit\tCtrl+Q')
        exit_action.triggered.connect(self.close)

    def handle_pan(self, dx, dy):
        h_bar = self.scroll_area.horizontalScrollBar()
        v_bar = self.scroll_area.verticalScrollBar()
        h_bar.setValue(h_bar.value() + dx)
        v_bar.setValue(v_bar.value() + dy)

    def adjust_zoom(self, delta):
        new_zoom = self.image_label.zoom_level + delta
        new_zoom = max(self.image_label.min_zoom, min(self.image_label.max_zoom, new_zoom))
        self.image_label.zoom_level = new_zoom
        self.image_label.update_pixmap()
        self.update_zoom_label()

    def reset_zoom(self):
        self.image_label.reset_zoom()
        self.update_zoom_label()

    def update_zoom_label(self, zoom_percent=None):
        if zoom_percent is None:
            zoom_percent = self.image_label.get_zoom_level()
        self.zoom_label.setText(f"Zoom: {zoom_percent}%")

    def open_image(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open Image", "",
            "Image Files (*.png *.jpg *.bmp *.tif *.tiff)"
        )
        if file_path:
            self.load_image(file_path)

    def load_image(self, image_path):
        """Загрузка изображения через GDAL (QGIS) для избежания ошибок TIFF"""
        try:
            # Создаем временный растер QGIS
            rlayer = QgsRasterLayer(image_path, "temp_color_finder")
            
            if not rlayer.isValid():
                print(f"Failed to load image via GDAL: {image_path}")
                # Если GDAL не справился, пробуем стандартный метод (на случай ошибок)
                return self.load_image_fallback(image_path)

            # Получаем размеры
            width = rlayer.width()
            height = rlayer.height()
            extent = rlayer.extent()

            # Проверяем размер (защита от слишком больших изображений для превью)
            # Если изображение огромное, можно добавить уменьшение, но для точности цветов оставим как есть
            if width == 0 or height == 0:
                return False

            # Читаем данные через блок данных GDAL
            # Это быстрее и надежнее, чем чтение через QImage для больших TIFF
            block = rlayer.dataProvider().block(1, QgsRectangle(0, 0, width, height), width, height)
            
            # Получаем байты изображения
            # Примечание: block.bits() возвращает данные в формате, зависящем от канала
            # Для простоты и надежности цветных изображений, попробуем сконструировать QImage
            
            # Попытка получить изображение через GDAL напрямую в память
            # Если это обычный RGB TIFF, QgsRasterLayer может отдать его через provider
            
            # Альтернативный надежный вариант для цветных изображений:
            # Считываем по каналам и собираем в numpy, затем в QImage
            if rlayer.bandCount() >= 3:
                block_r = rlayer.dataProvider().block(1, QgsRectangle(0, 0, width, height), width, height)
                block_g = rlayer.dataProvider().block(2, QgsRectangle(0, 0, width, height), width, height)
                block_b = rlayer.dataProvider().block(3, QgsRectangle(0, 0, width, height), width, height)

                # Создаем массив для всего растра
                arr = np.zeros((height, width, 3), dtype=np.uint8)
                
                # Читаем данные построчно
                for row in range(height):
                    for col in range(width):
                        pixel = rlayer.dataProvider().identify(QgsPointXY(extent.xMinimum() + col * extent.width()/width,
                                                                        extent.yMaximum() - row * extent.height()/height),
                                                               QgsRaster.IdentifyFormatValue).results()
                        if 1 in pixel and 2 in pixel and 3 in pixel:
                            arr[row, col] = [pixel[1], pixel[2], pixel[3]]

                
                # Преобразуем в numpy массивы
                arr_r = np.frombuffer(block_r.data(), dtype=np.uint8).reshape((height, width))
                arr_g = np.frombuffer(block_g.data(), dtype=np.uint8).reshape((height, width))
                arr_b = np.frombuffer(block_b.data(), dtype=np.uint8).reshape((height, width))

                print(arr)
                return
                
                # Собираем в RGB
                rgb_data = np.stack([arr_r, arr_g, arr_b], axis=-1)
                
                # Создаем QImage из numpy массива
                # QImage.Format_RGB888 требует порядок байт R, G, B
                bytes_per_line = 3 * width
                self.image = QImage(rgb_data.data, width, height, bytes_per_line, QImage.Format_RGB888)
                
                # Важно: создаем копию, так как исходные данные могут быть удалены
                self.image = self.image.copy() 
                
            else:
                # Если каналов меньше 3 (например, grayscale), пробуем стандартную загрузку
                return self.load_image_fallback(image_path)

            self.pixmap = QPixmap.fromImage(self.image)
            self.image_label.set_original_pixmap(self.pixmap)
            self.update_zoom_label()
            self.setWindowTitle(f"Average Color Finder - {os.path.basename(image_path)}")
            return True

        except Exception as e:
            print(f"Error loading image: {e}")
            return self.load_image_fallback(image_path)

    def load_image_fallback(self, image_path):
        """Резервный метод загрузки через QImage (если GDAL не подошел)"""
        # Подавляем предупреждения для этого блока кода
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            self.image = QImage()
            if not self.image.load(image_path):
                print(f"Failed to load image: {image_path}")
                return False
            self.pixmap = QPixmap.fromImage(self.image)
            self.image_label.set_original_pixmap(self.pixmap)
            self.update_zoom_label()
            self.setWindowTitle(f"Average Color Finder - {os.path.basename(image_path)}")
            return True

    def calculate_average_color(self):
        if (not hasattr(self.image_label, 'selection_start') or
                not self.image_label.selection_start or
                not self.image_label.selection_end or
                not self.image):
            return

        rect = QRect(self.image_label.selection_start,
                     self.image_label.selection_end).normalized()

        if rect.width() == 0 or rect.height() == 0:
            return

        ptr = self.image.bits()
        ptr.setsize(self.image.byteCount())

        if self.image.format() == QImage.Format_RGB32 or self.image.format() == QImage.Format_ARGB32:
            arr = np.array(ptr).reshape(self.image.height(), self.image.width(), 4)
        elif self.image.format() == QImage.Format_RGB888:
            arr = np.array(ptr).reshape(self.image.height(), self.image.width(), 3)
            arr = np.dstack([arr, np.full((self.image.height(), self.image.width()), 255, dtype=np.uint8)])
        else:
            self.image = self.image.convertToFormat(QImage.Format_RGB32)
            ptr = self.image.bits()
            ptr.setsize(self.image.byteCount())
            arr = np.array(ptr).reshape(self.image.height(), self.image.width(), 4)

        x1, y1 = rect.topLeft().x(), rect.topLeft().y()
        x2, y2 = rect.bottomRight().x(), rect.bottomRight().y()

        x1 = max(0, min(x1, self.image.width() - 1))
        y1 = max(0, min(y1, self.image.height() - 1))
        x2 = max(0, min(x2, self.image.width() - 1))
        y2 = max(0, min(y2, self.image.height() - 1))

        region = arr[y1:y2 + 1, x1:x2 + 1]
        avg_color = np.mean(region[:, :, :3], axis=(0, 1))
        avg_color = np.round(avg_color).astype(int)

        # QColor принимает (R, G, B)
        self.current_color = QColor(int(avg_color[2]), int(avg_color[1]), int(avg_color[0]))
        self.add_button.setEnabled(True)

        print(f"Average color in selection: RGB({avg_color[2]}, {avg_color[1]}, {avg_color[0]})")
        print(f"Hex: {self.current_color.name()}")

    def add_color_to_table(self):
        if not self.current_color:
            return

        row_position = self.table.rowCount()
        self.table.insertRow(row_position)

        self.table.setItem(row_position, 0, QTableWidgetItem(str(row_position + 1)))
        self.table.setItem(row_position, 1, QTableWidgetItem(str(self.current_color.red())))
        self.table.setItem(row_position, 2, QTableWidgetItem(str(self.current_color.green())))
        self.table.setItem(row_position, 3, QTableWidgetItem(str(self.current_color.blue())))

        color_item = QTableWidgetItem()
        color_item.setBackground(QBrush(self.current_color))
        color_item.setFlags(color_item.flags() & ~Qt.ItemIsEditable)
        self.table.setItem(row_position, 4, color_item)

        self.add_button.setEnabled(False)