# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Geoprocess
                                 A QGIS plugin
 Geoprocess
                              -------------------
        begin                : 2023-04-01
        git sha              : $Format:%H$
        copyright            : (C) 2023 by SSG
        email                : stanter30@gmail.com
 ***************************************************************************/
"""
import wx
import win32gui
import win32con
from win32gui import GetWindowText, GetForegroundWindow
import win32com.client
import subprocess
import sys
import etc
import json
from array import *
import numpy as np
#import matplotlib.pyplot as plt
#from mpl_toolkits.mplot3d import Axes3D
from time import sleep
import operator
import time
import os.path
import math
import processing
from osgeo import osr, gdal, ogr
from operator import itemgetter, attrgetter, methodcaller
from itertools import groupby
from qgis.analysis import *
from qgis.core import *
from qgis.core.additions.edit import edit
from qgis.gui import *
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtCore import QSettings, QTranslator, QVariant, QCoreApplication, Qt, QRectF
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QApplication, QAction, QProgressBar, QMessageBox, QHBoxLayout, QVBoxLayout, QSizePolicy, QPushButton, QDialog, QGridLayout, QDialogButtonBox, QMainWindow, QWidget
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtCore import QThread, QMetaMethod, QObject, pyqtSignal
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QWidget, QPushButton, QApplication, QMainWindow, QMenuBar, QMenu, QAction, QVBoxLayout
from PyQt5.QtWidgets import *
from qgis.gui import QgsLayerTreeView, QgsMapCanvas, QgsMapCanvasItem, QgsMessageBar, QgsVertexMarker, QgsRubberBand

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .Geoprocess_dialog import profilesDialog
from .Geoprocess_dialog import export_waypointsDialog

class Message:

    def msg(self):
        mbox=QMessageBox()
        mbox.setWindowTitle("Неправильный источник данных")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

    def info(self):
        mbox=QMessageBox()
        mbox.setWindowTitle("Информация")
        mbox.setIcon(QMessageBox.Information)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

mbox=Message().msg()
mboxi=Message().info()

class Geoprocess:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor."""
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'Geoprocess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Waypointer')
        self.toolbar = self.iface.addToolBar(u'Waypointer')
        self.toolbar.setObjectName(u'Waypointer')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None



    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        return QCoreApplication.translate('Waypointer', message)


    def tool_gridding(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def tool_layers_operations(self, icon2_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon2_path)
        action2 = QAction(icon, text, parent)
        action2.triggered.connect(callback)
        action2.setEnabled(enabled_flag)

        if status_tip is not None:
            action2.setStatusTip(status_tip)
        if whats_this is not None:
            action2.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action2)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action2)

        self.actions.append(action2)
        return action2


    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/Waypointer/gridding.png'
        icon2_path = ':/plugins/Waypointer/layers.png'
        self.tool_gridding(icon_path, text=self.tr(u'Waypointer_Creation Lines'), callback=self.run_gridding, parent=self.iface.mainWindow())
        self.tool_layers_operations(icon2_path, text=self.tr(u'Waypointer_Export'), callback=self.run_layers_operations, parent=self.iface.mainWindow())


        # will be set False in run()
        self.first_start = True

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&Waypointer'), action)
            self.iface.removeToolBarIcon(action)

    def rejectDlg(self):
        self.dlg.close()

    def Exit(self):
        self.iface.messageBar().clearWidgets()
    #--------------------------------------------------------------------------
    #--------------------------------------------------------------------------
    # First Window
    #--------------------------------------------------------------------------
    def CreateLines(self):
        lin0 = QgsVectorLayer("LineString", "New_Line", "memory")
        crs = QgsProject.instance().crs()
        lin0.setCrs(crs)
        lin0.dataProvider().addAttributes([QgsField('ID', QVariant.Int)])
        lin0.updateExtents()
        QgsProject.instance().addMapLayer(lin0)
        lin0.startEditing()
        # Push add line
        hwnd = win32gui.FindWindow(None, 'Building profiles')
        parent_hwnd = win32gui.GetParent(hwnd)
        text_parent = win32gui.GetWindowText(parent_hwnd)
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.AppActivate(text_parent)
        shell.SendKeys("^.")


    def Grid(self):
        tic = time.perf_counter()
        path = self.dlg_grid.mQgsFileWidget.filePath()
        num_fly = int(self.dlg_grid.num_fly.text())
        layer_template = self.dlg_grid.layer_template.text()
        layer_counter_start = int(self.dlg_grid.layer_counter.text()) - 1

        Step_PK = float(self.dlg_grid.Step_PK.text())
        Step_PR = float(self.dlg_grid.Step_PR.text())
        Num_PR = int(self.dlg_grid.Num_PR.text())
        OffsetPK = float(self.dlg_grid.Offset_PK.text())
        OffsetPR = float(self.dlg_grid.Offset_PR.text())
        len_pr = float(self.dlg_grid.len_pr.text())
        Start_PK = 1
        Start_PR = 1
        SNP = 1
        SNPk = 1
        layer = self.iface.activeLayer()

        if layer==None or layer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран слой с линией-вектором"); mbox.exec_(); return
        if layer.featureCount() == 0:
            mbox.setText("Нужно нарисовать линию-вектор в активном слое линий"); mbox.exec_(); return
        features = layer.getFeatures()

        for feature in features:
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.LineGeometry:
                if geomSingleType:
                    xy=geom.asPolyline()
                    point1x=xy[0][0]; point1y=xy[0][1]; point2x=xy[1][0]; point2y=xy[1][1];
                    lenght=geom.length()
                else:
                    xy=geom.asMultiPolyline()
                    point1x=xy[0][0].x(); point1y=xy[0][0].y(); point2x=xy[0][1].x(); point2y=xy[0][1].y();
                    lenght=geom.length()
            else:
                mbox.setText("Должен быть выбран слой с вектором")
                mbox.show()
                mbox.exec_()
                return


        fly_shift = Step_PR * Num_PR
        for k in range(num_fly):
            # Calculate Values
            layer_counter_start += 1
            d = point2x-point1x
            h = point2y-point1y
            cosa = d/lenght
            sina = h/lenght
            point1xx = (point1x+OffsetPK*cosa)+(OffsetPR+fly_shift*k)*sina
            point1yy = (point1y+OffsetPK*sina)-(OffsetPR+fly_shift*k)*cosa
            point2xx = (point2x+OffsetPK*cosa)+(OffsetPR+fly_shift*k)*sina
            point2yy = (point2y+OffsetPK*sina)-(OffsetPR+fly_shift*k)*cosa
            num_PK = int(len_pr / Step_PK)+1
            
    
            f = num_PK * Num_PR
            ff = f
    
            crs = layer.crs()
            targetCrs = QgsCoordinateReferenceSystem('EPSG:4326')
            transformContext = QgsProject.instance().transformContext()
            xform = QgsCoordinateTransform(crs, targetCrs, transformContext)
    
            # Calculate and Add attributes in array
            gridArray = []
            for j in range (1, Num_PR+1):
                for i in range (1, num_PK+1):
                    ff -= 1
                    if ff % 10000 == 0:
                        self.dlg_grid.progressBar.setValue(((f-ff)/f)*50)
                        QApplication.processEvents()
    
                    XX = (point1xx+(i-1)*Step_PK*cosa)+Step_PR*sina*(j-1)
                    YY = (point1yy+(i-1)*Step_PK*sina)-Step_PR*cosa*(j-1)
    
    
                    a = QgsPointXY(XX, YY)
                    xyTarget = xform.transform(a)
                    lat = xyTarget.y()
                    lon = xyTarget.x()
    
                    gridArray.append((j, i, XX, YY, lon, lat))
    
                            
            # Create new Layer
            grid = QgsVectorLayer("Point", layer_template + str(layer_counter_start), "memory")
    
            pr = grid.dataProvider()
            crs = layer.crs()
            if crs.authid() == "EPSG:4326":
                mbox.setText("Нельзя построить в системе координат WGS 84\nСистема координат слоя должна быть прямоугольной")
                mbox.show()
                mbox.exec_()
                return
            grid.setCrs(crs)
    
    
            pr.addAttributes([QgsField('Name', QVariant.String), 
                              QgsField('PR', QVariant.Int),
                              QgsField('PK', QVariant.Int),
                              QgsField('ELEV', QVariant.Double,'double', 20, 3),
                              QgsField('LON', QVariant.Double,'double', 20, 7),
                              QgsField('LAT', QVariant.Double,'double', 20, 7),
                              QgsField('X', QVariant.Double,'double', 20, 3),
                              QgsField('Y', QVariant.Double,'double', 20, 3)
                              ])
    
            grid.updateFields()
    
            # Add attributes in new Layer
            
            ff = f / 2
            fets = []
    
            for i in gridArray:
                ff -= 0.5
                if ff % 5000 == 0:
                    self.dlg_grid.progressBar.setValue(((f-ff)/f)*100)
                    QApplication.processEvents()
                fet = QgsFeature()
                fet.setGeometry(QgsPoint(i[2], i[3]))
                Name = str(i[0])+', '+str(i[1])
                attrs = [Name, i[0], i[1], None, i[4], i[5], i[2], i[3]]
                fet.setAttributes(attrs)
                fets.append(fet)
            pr.addFeatures(fets)
            grid.updateExtents()
    
            QgsProject.instance().addMapLayer(grid)


        if self.dlg_grid.remove_line_check_btn.isChecked():
            QgsProject.instance().removeMapLayer(layer)
        else:
            self.iface.setActiveLayer(layer)


        if self.dlg_grid.save_check_btn.isChecked():
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "ESRI Shapefile"
            options.layerName = layer.name()
            QgsVectorFileWriter.writeAsVectorFormatV3(layer, file_path, QgsCoordinateTransformContext(), options)
            vlayer = QgsVectorLayer(file_path+'.shp', "Ctrl_points_saved", "ogr")
            QgsProject.instance().addMapLayer(vlayer)
            QgsProject.instance().removeMapLayers([layer.id()])


        toc = time.perf_counter()
        print(f"time: {toc - tic:0.3f} секунд")
        self.dlg_grid.progressBar.setValue(0)
        self.iface.messageBar().pushMessage("Grid points created success", level=Qgis.Success, duration=5)


    #--------------------------------------------------------------------------
    # Second Window
    #--------------------------------------------------------------------------

    def import_layer(self):
        data = []
        fieldList = []
        layer = self.dlg_export.input_layer_CB.currentLayer()
        [fieldList.append(field.name()) for field in layer.fields()]
        features = layer.getFeatures()
        data.append(fieldList)
        for feature in features:
            attrs = feature.attributes()
            strAttrs = []
            for attr in attrs:
                try:
                    strAttrs.append(str(round(attr, 7)))
                except:
                    strAttrs.append(str(attr))
            data.append(strAttrs)

        vert = []
        for i in range(len(data)):
            vert.append(str(i+1))


        self.dlg_export.tableWidget.setRowCount(len(data)-1)
        self.dlg_export.tableWidget.setColumnCount(len(data[0]))
        self.dlg_export.tableWidget.setHorizontalHeaderLabels(data[0])
        self.dlg_export.tableWidget.setVerticalHeaderLabels(vert)

        for i in range(1, len(data)):
            for j in range(len(data[0])):
                self.dlg_export.tableWidget.setItem(i-1, j, QTableWidgetItem(data[i][j]))

        self.dlg_export.tableWidget.horizontalHeader().setDefaultSectionSize(80)


    def bind_elev(self):
        print('bind')
        rlayer = self.dlg_export.input_rlayer_CB.currentLayer()
        vlayer = self.dlg_export.input_layer_CB.currentLayer()
        vlayer.startEditing()
        if vlayer.type() != QgsMapLayerType.VectorLayer:
            mbox.setText("Должен быть выбран векторный слой с точками")
            mbox.show()
            mbox.exec_()
            return
        f = vlayer.featureCount()
        ff = f
        features = vlayer.getFeatures()

        test_none = 0

        geom = vlayer.getFeature(1).geometry()
        geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
        if geomSingleType:
            xy = geom.asPoint()
            try:
                ident = rpr.identify(QgsPointXY(xy.x(), xy.y()), 1)
                IFV = 1
            except:
                IFV = QgsRaster.IdentifyFormatValue
        else:
            xy = geom.asMultiPoint()
            try:
                ident = rpr.identify(QgsPointXY(xy[0].x(), xy[0].y()), 1)
                IFV = 1
            except:
                IFV = QgsRaster.IdentifyFormatValue

        fc = vlayer.fields().count()
        vpr = vlayer.dataProvider()
        rpr = rlayer.dataProvider()

        for i, field in enumerate(vlayer.fields()):
            if field.name()=="ELEV":
                fc = i

        if vlayer.providerType()=="memory":
            for field in vlayer.fields():
                if field.name()=="Z":
                    mbox.setText('Поле Z уже есть в таблице')
                    mbox.show()
                    mbox.exec_()
                    return
        for i in vlayer.getFeatures():
            if i.geometry().type() == 1 or i.geometry().type() == 2:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                mbox.exec_()
                return
            break
        if not rlayer.type()==QgsMapLayerType.RasterLayer:
            mbox.setText("В окне DEM должен быть выбран растровый слой рельефа")
            mbox.show()
            mbox.exec_()
            return
        vcrs = vlayer.crs()
        rcrs = rlayer.crs()
        if not vcrs==rcrs:
            mbox.setText("Проекции растра и точек не совпадают")
            mbox.show()
            mbox.exec_()
            return
        path = vpr.dataSourceUri()
        pp=path[len(path)-3]+path[len(path)-2]+path[len(path)-1]
        if (pp=="=no" or pp=="txt" or pp=="csv" or pp=="dat" or pp=="nts"):
            mbox.setText("Работает только с шейп файлами")
            mbox.show()
            mbox.exec_()
            return

        for i in features:
            ff-=1
            if ff%200==0:
                self.dlg_export.progressBar.setValue(((f-ff)/f)*100)
                QApplication.processEvents()
            geom = i.geometry()

            if not geom.type() == 0:
               continue

            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())

            if geomSingleType:
                xy = geom.asPoint()
                ident = rpr.identify(QgsPointXY(xy.x(), xy.y()), IFV)
            else:
                xy = geom.asMultiPoint()
                ident = rpr.identify(QgsPointXY(xy[0].x(), xy[0].y()), IFV)

            if ident.results()=={}:

                mbox.setText("Недоступный источник растра во вкладке DEM")
                mbox.show()
                mbox.exec_()
                return

            z = ident.results()[1]

            if z == None:
                test_none = 1

            ids = i.id()
            attr_value = {fc : z}
            vpr.changeAttributeValues({ids:attr_value})

        vlayer.updateFields()
        vlayer.commitChanges()
        self.dlg_export.progressBar.setValue(0)
        self.iface.messageBar().pushMessage("Elevation added in current layer", 
            level=Qgis.Success, duration=5)

        
        self.import_layer()

        if test_none == 1:
            mbox.setText("Есть пустые значения высот")
            mbox.show()
            mbox.exec_()
            return

        mboxi.setText("Высоты добавлены")
        mboxi.show()
        mboxi.exec_()


    def modify(self):
        print('modify')
        home_alt = float(self.dlg_export.home_alt.text())
        flight_alt = float(self.dlg_export.flight_alt.text())


        # Get input data
        col_cnt = self.dlg_export.tableWidget.columnCount()
        row_cnt = self.dlg_export.tableWidget.rowCount()

        input_data_dir = []
        input_data_rev = []
        new_dir = 0
        for i in range(row_cnt):
            line = []
            for j in range(col_cnt):
                item = self.dlg_export.tableWidget.item(i, j).text()
                line.append(item)

            if int(line[1]) % 2 != 0:
                if new_dir == 1:
                    input_data_rev.reverse()
                    input_data_dir.extend(input_data_rev)
                    input_data_rev = []
                input_data_dir.append(line)
                new_dir = 0
            elif int(line[1]) % 2 == 0:

                new_dir = 1
                input_data_rev.append(line)

        if new_dir == 1:
            input_data_rev.reverse()
            input_data_dir.extend(input_data_rev)


        # Modify data for waypoint
        vert = []
        self.modify_data = []
        self.modify_data.append(('0', '1', '0', '16', '0', '0', '0', '0', '0', '0', '0', '1'))
        for i, line in enumerate(input_data_dir):
            alt_rel = str(round(float(line[3]) - home_alt + flight_alt, 3))
            self.modify_data.append((str(i), '0', '3', '16', '0', '0', '0', '0', line[5], line[4], alt_rel, '1'))
            vert.append(str(i+1))
        self.modify_data.append((str(i+1), '0', '3', '20', '0', '0', '0', '0', '0', '0', '0', '1'))


        self.dlg_export.tableWidget_2.setRowCount(len(self.modify_data))
        self.dlg_export.tableWidget_2.setColumnCount(12)
        self.dlg_export.tableWidget_2.setVerticalHeaderLabels(vert)
        self.dlg_export.tableWidget_2.horizontalHeader().setDefaultSectionSize(60)    


        for i in range(len(self.modify_data)):
            for j in range(len(self.modify_data[0])):
                self.dlg_export.tableWidget_2.setItem(i, j, QTableWidgetItem(self.modify_data[i][j]))



    def export_waypoints(self):
        if self.dlg_export.mQgsFileWidget.filePath() == '':
            mbox.setText("Нужно выбрать путь к папке для сохранения")
            mbox.show()
            mbox.exec_()
            return

        vlayer = self.dlg_export.input_layer_CB.currentLayer().name()
        directory = self.dlg_export.mQgsFileWidget.filePath() + '/'
        path = directory + vlayer + '.waypoints'

        strr = 'QGC WPL 110' 

        with open(path, 'w', encoding = 'Windows-1251') as f:
            f.write(strr + '\n')
            line = []
            for i in self.modify_data:
                line = '\t'.join(i)
                f.write(line + '\n')


        self.iface.messageBar().pushMessage("Waypoints file has been created", level=Qgis.Success, duration=6)



    #--------------------------------------------------------------------------
    def run_gridding(self):
        self.dlg_grid = profilesDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_grid.show()
        # Buttons click
        self.dlg_grid.Grid.clicked.connect(self.Grid)
        self.dlg_grid.CreateLine.clicked.connect(self.CreateLines)

        self.cfg_lines_path = self.plugin_dir + '/cfg_lines.ini'
        self.cfg_lines_path_path = self.plugin_dir + '/cfg_lines_path.ini'

    
        with open(self.cfg_lines_path_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            self.dlg_grid.mQgsFileWidget.setFilePath(cfg[0][1])

        with open(self.cfg_lines_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            self.dlg_grid.Step_PK.setText(cfg[0][1])
            self.dlg_grid.len_pr.setText(cfg[1][1])
            self.dlg_grid.Offset_PK.setText(cfg[2][1])
            self.dlg_grid.Step_PR.setText(cfg[3][1])
            self.dlg_grid.Num_PR.setText(cfg[4][1])
            self.dlg_grid.Offset_PR.setText(cfg[5][1])
            self.dlg_grid.num_fly.setText(cfg[6][1])
            self.dlg_grid.layer_template.setText(cfg[7][1])
            self.dlg_grid.layer_counter.setText(cfg[8][1])


        self.dlg_grid.Step_PK.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.len_pr.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.Offset_PK.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.Step_PR.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.Num_PR.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.Offset_PR.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.num_fly.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.layer_template.textChanged.connect(self.change_cfg_lines)
        self.dlg_grid.layer_counter.textChanged.connect(self.change_cfg_lines)

        self.dlg_grid.mQgsFileWidget.fileChanged.connect(self.change_path_lines)




    def run_layers_operations(self):
        self.dlg_export = export_waypointsDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_export.show()
        # Buttons click
        self.dlg_export.import_layer.clicked.connect(self.import_layer)
        self.dlg_export.bind_elev.clicked.connect(self.bind_elev)
        self.dlg_export.modify.clicked.connect(self.modify)
        self.dlg_export.export_layer.clicked.connect(self.export_waypoints)

        self.dlg_export.input_layer_CB.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.dlg_export.input_rlayer_CB.setFilters(QgsMapLayerProxyModel.RasterLayer)


        self.cfg_path = self.plugin_dir + '/cfg.ini'

        with open(self.cfg_path, 'r') as f:
            lines = f.readlines()
            cfg = [i.replace('\n', '').split('\t') for i in lines]
            self.dlg_export.home_alt.setText(cfg[0][1])
            self.dlg_export.flight_alt.setText(cfg[1][1])


        self.dlg_export.home_alt.textChanged.connect(self.change_cfg_export)
        self.dlg_export.flight_alt.textChanged.connect(self.change_cfg_export)




    def change_path_lines(self):
        with open(self.cfg_lines_path_path, 'w') as f:
            f.write('path' + '\t' + self.dlg_grid.mQgsFileWidget.filePath() + '\n')

    def change_cfg_lines(self):
        with open(self.cfg_lines_path, 'w') as f:
            f.write('Step_PK' + '\t' + self.dlg_grid.Step_PK.text() + '\n')
            f.write('len_pr' + '\t' + self.dlg_grid.len_pr.text() + '\n')
            f.write('Offset_PK' + '\t' + self.dlg_grid.Offset_PK.text() + '\n')
            f.write('Step_PR' + '\t' + self.dlg_grid.Step_PR.text() + '\n')
            f.write('Num_PR' + '\t' + self.dlg_grid.Num_PR.text() + '\n')
            f.write('Offset_PR' + '\t' + self.dlg_grid.Offset_PR.text() + '\n')
            f.write('num_fly' + '\t' + self.dlg_grid.num_fly.text() + '\n')
            f.write('layer_template' + '\t' + self.dlg_grid.layer_template.text() + '\n')
            f.write('layer_counter' + '\t' + self.dlg_grid.layer_counter.text() + '\n')


    def change_cfg_export(self):
        with open(self.cfg_path, 'w') as f:
            f.write('home_alt' + '\t' + self.dlg_export.home_alt.text() + '\n')
            f.write('flight_alt' + '\t' + self.dlg_export.flight_alt.text() + '\n')


