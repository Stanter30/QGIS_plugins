# -*- coding: utf-8 -*-
"""
/***************************************************************************
 UAV_Mag_Process
                                 A QGIS plugin
                              -------------------
        begin                : 2023-09-15
        git sha              : $Format:%H$
        copyright            : (C) 2023 by Tereshkin S.A.
        email                : Stanter30@gmail.com
 ***************************************************************************/
"""
import pip
import wx
import win32gui
import win32con
from win32gui import GetWindowText, GetForegroundWindow
import win32com.client
import subprocess
import sys
import etc
import json
import copy
from array import *
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar
import matplotlib as mpl
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.figure import Figure
import scipy.interpolate as interp
from time import sleep
import operator
import time
from datetime import datetime
import os.path
import math
import processing
from osgeo import osr, gdal, ogr
from operator import itemgetter, attrgetter, methodcaller
from itertools import groupby
from qgis.analysis import *
from qgis.core import *
from qgis.core.additions.edit import edit
from qgis.gui import *
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtCore import QSettings, QTranslator, QVariant, QCoreApplication, Qt, QRectF
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QApplication, QAction, QProgressBar, QMessageBox, QHBoxLayout, QVBoxLayout, QSizePolicy, QPushButton, QDialog, QGridLayout, QDialogButtonBox, QMainWindow, QWidget
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtCore import QThread, QMetaMethod, QObject, pyqtSignal
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QWidget, QPushButton, QApplication, QMainWindow, QMenuBar, QMenu, QAction, QVBoxLayout
from PyQt5.QtWidgets import *
from qgis.gui import QgsLayerTreeView, QgsMapCanvas, QgsMapCanvasItem, QgsMessageBar, QgsVertexMarker, QgsRubberBand

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .UAVProcess_dialog import UAVProcessDialog

class Message:
    def msg(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Неправильный источник данных")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)
    def info(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Информация")
        mbox.setIcon(QMessageBox.Information)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

mbox = Message().msg()
mboxi = Message().info()


class UAVProcess:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor."""
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'UAVProcess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&UAV_Mag_Process')
        self.toolbar = self.iface.addToolBar(u'UAV_Mag_Process')
        self.toolbar.setObjectName(u'UAV_Mag_Process')

        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message): return QCoreApplication.translate('UAV_Mag_Process', message)

    def tool_UAV(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/UAVProcess/icon.png'
        self.tool_UAV(icon_path, text=self.tr(u'UAV_Mag_Process'), callback=self.run_UAV, parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&UAV_Mag_Process'), action)
            self.iface.removeToolBarIcon(action)

    def rejectDlg(self):
        self.dlg.close()

    def progress(self, f, ff, proc_freq, proc_text):
        if ff % proc_freq == 0:
            self.dlg_UAV.progressBar.setValue(((f-ff)/f)*100)
            self.dlg_UAV.progressBar.setFormat(proc_text + str(int(((f-ff)/f)*100)) + ' %')
            QApplication.processEvents()

    def timeForm(self, Time, var):
        d1 = self.dlg_UAV.d1_CB.currentText()
        d2 = self.dlg_UAV.d2_CB.currentText()
        d3 = self.dlg_UAV.d3_CB.currentText()
        t1 = self.dlg_UAV.t1_CB.currentText()
        t2 = self.dlg_UAV.t2_CB.currentText()
        t3 = self.dlg_UAV.t3_CB.currentText()
        t4 = self.dlg_UAV.t4_CB.currentText()

        d1_var = self.dlg_UAV.d1_var_CB.currentText()
        d2_var = self.dlg_UAV.d2_var_CB.currentText()
        d3_var = self.dlg_UAV.d3_var_CB.currentText()
        t1_var = self.dlg_UAV.t1_var_CB.currentText()
        t2_var = self.dlg_UAV.t2_var_CB.currentText()
        t3_var = self.dlg_UAV.t3_var_CB.currentText()
        t4_var = self.dlg_UAV.t4_var_CB.currentText()

        self.str_sep_var = ' '
        if var == 0:
            if Time.find('T') != -1:
                self.str_sep = 'T'
            else:
                self.str_sep = ' '
        else:
            if Time.find('T') != -1:
                self.str_sep_var = 'T'
            else:
                self.str_sep_var = ' '
    
        try:
            data_sep = Time[2]
            print('line 174', Time)
            if data_sep == '.':
                self.time_form = d1 + '.' + d2 + '.' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                self.time_form_var = d1_var + '.' + d2_var + '.' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
            elif data_sep == '-':
                self.time_form = d1 + '-' + d2 + '-' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                self.time_form_var = d1_var + '-' + d2_var + '-' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
            elif data_sep == '/':
                self.time_form = d1 + '/' + d2 + '/' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                self.time_form_var = d1_var + '/' + d2_var + '/' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
            elif data_sep == ' ':
                self.time_form = d1 + ' ' + d2 + ' ' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                self.time_form_var = d1_var + ' ' + d2_var + ' ' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
            elif data_sep == '_':
                self.time_form = d1 + '_' + d2 + '_' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                self.time_form_var = d1_var + '_' + d2_var + '_' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
            elif data_sep == ',':
                self.time_form = d1 + ',' + d2 + ',' + d3 + self.str_sep + t1+':'+t2+':'+t3+t4
                self.time_form_var = d1_var + ',' + d2_var + ',' + d3_var + self.str_sep_var + t1_var+':'+t2_var+':'+t3_var+t4_var
        except:
            if var == 0:
                mbox.setText('Формат времени для рядовых измерений не подходит')
            else:
                mbox.setText('Формат времени для вариаций не подходит')
            mbox.show()
            return


        self.dlg_UAV.label_Mag_form.setStyleSheet("background:rgba(255, 255, 200, 255);") 
        self.dlg_UAV.label_Mag_form.setText(self.time_form)
        self.dlg_UAV.label_Mag_test.setStyleSheet("background:rgba(255, 255, 200, 255);") 
        self.dlg_UAV.label_Mag_test.setText(Time)


        if var == 1:
            self.dlg_UAV.label_Var_form.setStyleSheet("background:rgba(255, 255, 200, 255);") 
            self.dlg_UAV.label_Var_form.setText(self.time_form_var)
            self.dlg_UAV.label_Var_test.setStyleSheet("background:rgba(255, 255, 200, 255);") 
            self.dlg_UAV.label_Var_test.setText(Time)




    #--------------------------------------------------------------------------
    # UAVProcess
    #--------------------------------------------------------------------------

    def run_process(self, data_merge, proc, tic):

        if self.dlg_UAV.process_list.item(2).checkState() == Qt.Checked or self.dlg_UAV.process_list.item(3).checkState() == Qt.Checked or self.dlg_UAV.process_list.item(4).checkState() == Qt.Checked:
            if len(self.dlg_UAV.mQgsProjectionSelectionWidget.crs().authid()) == 0:
                mbox.setText('Не задана система координат')
                mbox.show()
                return
            if self.dlg_UAV.mQgsFileWidget_4.filePath() == '':
                mbox.setText('Не заданы файлы с вариациями')
                mbox.show()
                return
        if self.dlg_UAV.process_list.item(0).checkState() == Qt.Checked and proc == 0: # Merge Data
            print('start proc 1')
            proc = 1
            UAVProcess.merge_coord_time(self, proc)
        return

    def run_process2(self, data_merge, proc, tic):

        if self.dlg_UAV.process_list.item(1).checkState() == Qt.Checked and proc == 1:  # Variations
            print('start proc 2')
            proc = 2
            UAVProcess.variations(self, data_merge, proc, tic)
        return

    def run_process3(self, data_merge, proc, tic):

        if self.dlg_UAV.process_list.item(2).checkState() == Qt.Checked and proc == 2: # Cut Points
            print('start proc 3')
            proc = 3
            UAVProcess.cut_points(self, data_merge, proc, tic)
        elif self.dlg_UAV.process_list.item(2).checkState() == Qt.Checked and proc == 1:
            print('start proc 3 without proc 2')
            proc = 3
            self.fieldList = [('T', 6), ('QMC', 2), ('ST', 2), ('TIME', 10), ('LAT', 6), ('LON', 6), ('ALT', 6), ('GR', 2)]
            UAVProcess.cut_points(self, data_merge, proc, tic)
        return

    def run_process4(self, data_merge, proc, tic):

        if self.dlg_UAV.process_list.item(3).checkState() == Qt.Checked and proc == 3: # Num Profiles
            print('start proc 4')
            proc = 4
            rect = 0
            UAVProcess.add_n_profile(self, data_merge, proc, tic, rect)
        return

    def run_process5(self, data_merge, proc, tic):

        if self.dlg_UAV.process_list.item(4).checkState() == Qt.Checked and proc == 4: # Control Separator
            print('start proc 5')
            proc = 5
            UAVProcess.control_separator(self, data_merge, proc, tic)
        return

    

    def load_files(self):
        file_path = self.dlg_UAV.mQgs_open_files.filePath()

        if len(file_path) == 0:
            mbox.setText("Нужно выбрать файлы с данными")
            mbox.show()
            return

        file_paths = file_path.rsplit('"')
        for i in range(len(file_paths), -1, -1):
            if i % 2 == 0:
                del file_paths[i]
        file_paths = [file_path] if len(file_paths) == 0 else file_paths

        if len(file_paths[0]) == 0:
            return

        data = []

        for file in file_paths:
            # Read var
            if file.endswith(".txt"):
                with open(file, 'r', encoding = 'Windows-1251') as file:
                    lines = file.readlines()

                    spliter = ' '
                    words = lines[6].replace('\n', '').split(spliter)
                    headers = lines[0].replace('\n', '').split(spliter)
                    if len(words) == 1:
                        spliter = '\t'
                        words = lines[6].replace('\n', '').split(spliter)
                        headers = lines[0].replace('\n', '').split(spliter)

                    if len(words) == 1:
                        spliter = ','
                        words = lines[6].replace('\n', '').split(spliter)
                        headers = lines[0].replace('\n', '').split(spliter)

                    if len(words) == 1:
                        spliter = ';'
                        words = lines[6].replace('\n', '').split(spliter)
                        headers = lines[0].replace('\n', '').split(spliter)


        self.dlg = QDialog()
        self.dlg.setWindowTitle("Fields selection")

        label, label1, label2, label3 = QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel()
        label4, label5, label6 = QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel()
        label.setText('FIELD')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        label1.setText('QMC')
        label1.setAlignment(Qt.AlignCenter)
        label1.setFont(QFont('MS Shell Dlg 2', 10))
        label2.setText('ST')
        label2.setAlignment(Qt.AlignCenter)
        label2.setFont(QFont('MS Shell Dlg 2', 10))
        label3.setText('TIME')
        label3.setAlignment(Qt.AlignCenter)
        label3.setFont(QFont('MS Shell Dlg 2', 10))
        label4.setText('LAT')
        label4.setAlignment(Qt.AlignCenter)
        label4.setFont(QFont('MS Shell Dlg 2', 10))
        label5.setText('LON')
        label5.setAlignment(Qt.AlignCenter)
        label5.setFont(QFont('MS Shell Dlg 2', 10))
        label6.setText('ALT')
        label6.setAlignment(Qt.AlignCenter)
        label6.setFont(QFont('MS Shell Dlg 2', 10))


        items, items1, items2, items3 = QComboBox(), QComboBox(), QComboBox(), QComboBox()
        items4, items5, items6, items7 = QComboBox(), QComboBox(), QComboBox(), QComboBox()

        items.addItem('')
        items1.addItem('')
        items2.addItem('')
        items3.addItem('')
        items4.addItem('')
        items5.addItem('')
        items6.addItem('')
        items7.addItem('')

        for head in headers:
            items.addItem(head)
            items1.addItem(head)
            items2.addItem(head)
            items3.addItem(head)
            items4.addItem(head)
            items5.addItem(head)
            items6.addItem(head)
            items7.addItem(head)

        gridLayout = QGridLayout()
        gridLayout.setVerticalSpacing(10)
        gridLayout.setHorizontalSpacing(30)
        gridLayout.addWidget(label, 0, 0)
        gridLayout.addWidget(items, 1, 0)
        gridLayout.addWidget(label1, 0, 1)
        gridLayout.addWidget(items1, 1, 1)
        gridLayout.addWidget(label2, 0, 2)
        gridLayout.addWidget(items2, 1, 2)
        gridLayout.addWidget(label3, 0, 3)
        gridLayout.addWidget(items3, 1, 3)
        gridLayout.addWidget(label4, 0, 4)
        gridLayout.addWidget(items4, 1, 4)
        gridLayout.addWidget(label5, 0, 5)
        gridLayout.addWidget(items5, 1, 5)
        gridLayout.addWidget(label6, 0, 6)
        gridLayout.addWidget(items6, 1, 6)
        gridLayout.addWidget(items7, 2, 3)


        projection = QgsProjectionSelectionWidget()
        crs = QgsCoordinateReferenceSystem('EPSG:4326')
        projection.setCrs(crs)
        gridLayout.addWidget(projection, 2, 0, 1, 3)

        for i, val in enumerate(headers):
            if val == 'T' or val == 'FIELD' or val == 'Field':
                items.setCurrentIndex(i+1)
            if val == 'QMC' or val == 'qmc':
                items1.setCurrentIndex(i+1)
            if val == 'ST' or val == 'st':
                items2.setCurrentIndex(i+1)
            if val == 'TIME' or val == 'Time' or val == 'time' or val == 'DATATIME':
                items3.setCurrentIndex(i+1)
            if val == 'LAT' or val == 'Lat' or val == 'lat':
                items4.setCurrentIndex(i+1)
            if val == 'LON' or val == 'Lon' or val == 'lon':
                items5.setCurrentIndex(i+1)
            if val == 'ALT' or val == 'Alt' or val == 'alt' or val == 'elev' or val == 'ELEV' or val == 'Elev':
                items6.setCurrentIndex(i+1)


        items_all = [items, items1, items2, items3, items4, items5, items6, items7]

        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(lambda: self.load_files_OK(items_all))
        btnBox.rejected.connect(self.rejectDlg)
        gridLayout.addWidget(btnBox, 2, 6)

        self.dlg.setLayout(gridLayout)
        self.dlg.exec_()



    def load_files_OK(self, items_all):
        tic = time.perf_counter()

        attrs = []

        for i in items_all:
            attrs.append([i.currentIndex(), i.currentText()])

        print(attrs)

        
        data = []
                        
        Time = ''
        for wor in words:
            if wor.find('T') != -1 or wor.find(' ') != -1:
                Time = wor
        if Time == '':
            Time = words[3] + ' ' + words[4]
        UAVProcess.timeForm(self, Time, var=0)
    
        for i in range(len(lines)):
            if lines[i][0] != ';' and len(lines[i]) > 1 and i > 0:
                words = lines[i].replace('\n', '').split(spliter)
                
                field = float(words[0])
                qmc = int(words[1])
                st = int(words[2])
                Time = words[3]
                time_sec = datetime.strptime(Time, self.time_form).timestamp()
                lon = float(words[4])
                lat = float(words[5])
                alt = float(words[6])
                data0 = [field, qmc, st, Time, lon, lat, alt, time_sec]
                data.append(data0)

        data.sort(key=lambda x: x[-1], reverse=False)


        # Add points
        pnt = QgsVectorLayer('Point', 'Mag_files', 'memory')
        crs = QgsCoordinateReferenceSystem()
        crs.createFromId(4326)
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        pr.addAttributes([
                          QgsField('T', QVariant.Double, 'double', 7, 3), 
                          QgsField('QMC', QVariant.Int),
                          QgsField('ST', QVariant.Int),
                          QgsField('TIME', QVariant.String),
                          QgsField('LON', QVariant.Double, 'double', 7, 7),
                          QgsField('LAT', QVariant.Double, 'double', 7, 7),
                          QgsField('ALT', QVariant.Double, 'double', 7, 3),
                         ])
        pnt.updateFields()
        
        fets = []

        f, ff, proc_freq, proc_text = len(data), len(data), 1000, 'Rendering: '
        for i, val in enumerate(data):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            attrs = [val[0], val[1], val[2], val[3], val[4], val[5], val[6]]
            fet = QgsFeature()
            fet.setGeometry(QgsPoint(val[4], val[5]))
            fet.setAttributes(attrs)
            fets.append(fet) 
        pr.addFeatures(fets)
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(data)))
        mboxi.show()
        mboxi.exec_()




    def merge_coord_time(self, proc):
        print('start merge', 'proc', proc)
        tic = time.perf_counter()
        
        days = []
        root_gen = self.dlg_UAV.mQgsFileWidget_3.filePath()
        if len(root_gen) == 0:
            mbox.setText('Не найден путь к папке исходников')
            mbox.show()
            return
        time_shift = float(self.dlg_UAV.time_shift.text())

        if self.dlg_UAV.all_project.isChecked():
            # def days
            for root, dirs, files in os.walk(root_gen):
                (Directory, File) = os.path.split(root)
                for day in dirs:
                    days.append(root + '/' + day)
                break
        elif self.dlg_UAV.one_day.isChecked():
            # def day
            for root, dirs, files in os.walk(root_gen):
                days.append(root)
                day_index = root.rfind(r'\\'[:-1])
                day_pref = root[day_index+1:]
                break
        else:
            # def group
            for root, dirs, files in os.walk(root_gen):
                subfold = [root]
                sub_index = root.rfind(r'\\'[:-1])
                sub = root[sub_index+1:]
                slice_index = root.rfind(r'\\'[:-1])
                day = root[:slice_index]
                days.append(day)
                day_index = day.rfind(r'\\'[:-1])
                day_pref = day[day_index+1:]
                break
    
        # def num groups
        for root, dirs, files in os.walk(days[0]):
            gr_num = len(dirs)
            break
        if self.dlg_UAV.one_group.isChecked():
            gr_num = 1

        # def all files
        gr = []
        for grp in range(gr_num):
            gr_day = []
            for day in days:
                subfolders = [f.path for f in os.scandir(day) if f.is_dir()]
                if self.dlg_UAV.one_group.isChecked():
                    subfolders = subfold
                dir_gr = subfolders[grp]
                files_in_days = []
                for root, dirs, files in os.walk(dir_gr):
                    for file in files:
                        if file.find('.txt') != -1 or file.find('.gpx') != -1:
                            files_in_days.append(root + '/' + file)
                gr_day.append(files_in_days)
            gr.append(gr_day)

        # del empty dir
        for num_g, g in enumerate(gr):
            for i, day in enumerate(g):
                if len(day) < 2:
                    del gr[num_g][i]

        file_n = 0 # n file for def time format
        data_merge = []
        g = 0
        # Merge days
        for grp in gr:
            g += 1
            d = 0

            for day in grp:
                d += 1
                self.dlg_UAV.progressBar.setValue(int((100/len(grp))*d))
                self.dlg_UAV.progressBar.setFormat('Gr: ' + str(g) + '/' + str(len(gr)) + '    Day: ' + str(d) + '/' + str(len(grp)))
                QApplication.processEvents()
                data_mag = []
                data_gpx = []
                data_merge0 = []

                for file in day:
                    # Read mag
                    if file.endswith(".txt"):
                        with open(file, 'r', encoding = 'Windows-1251') as file:
                            lines = file.readlines()
                            if lines[0][0] != ';':
                                continue
                        file_n += 1

                        if file_n == 1:
                            words = lines[6].replace('\n','').split(' ')
                            Time = words[3] + ' ' + words[4]
                            UAVProcess.timeForm(self, Time, var=0)
                
                        for line in lines:
                            if line[0] != ';':
                                words = line.replace('\n','').split(' ')
                                Time = words[3] + ' ' + words[4]
                                time_sec = datetime.strptime(Time, self.time_form).timestamp()
                                data0 = [float(words[0]) / 1000, int(words[1]), int(words[2]), Time, time_sec]
                                data_mag.append(data0)
        
                    # Read coord
                    elif file.endswith(".gpx"):
                        with open(file, 'r', encoding = 'Windows-1251') as file:
                            line = file.readline()
                            words = line.split('<trkpt ')
                            del words[0]
                            del words[-1]
        
                            for word in words:
                                lat_pos_start = word.find('lat="') + 5
                                lon_pos_start = word.find('lon="') + 5
                                ele_pos_start = word.find('ele>') + 4
                                time_pos_start = word.find('time>') + 5
                                lat_pos_end = word.find('" lon')
                                lon_pos_end = word.find('"><ele')
                                ele_pos_end = word.find('</ele>')
                                time_pos_end = word.find('+')
                                lat = float(word[lat_pos_start:lat_pos_end])
                                lon = float(word[lon_pos_start:lon_pos_end])
                                ele = float(word[ele_pos_start:ele_pos_end])
                                Time = word[time_pos_start:time_pos_end]
                                time_f = Time.replace('T', ' ')
                                try:
                                    time_sec = datetime.strptime(time_f, '%Y-%m-%d %H:%M:%S').timestamp()
                                except:
                                    continue
                                data0 = [lat, lon, ele, g, time_sec]
                                data_gpx.append(data0)
        
                data_mag.sort(key=lambda x: x[-1], reverse=False)
                data_gpx.sort(key=lambda x: x[-1], reverse=False)
        
                # Transpose
                list_gpx = list(map(list, zip(*data_gpx)))
                list_mag = list(map(list, zip(*data_mag)))
        
                # Cut bad data
                cut_data_gpx = []
                for i in range(1, len(list_gpx[0])):
                    if list_gpx[-1][i] != list_gpx[-1][i-1]:
                        cut_data_gpx.append(data_gpx[i])
        
                list_gpx = list(map(list, zip(*cut_data_gpx)))
                print('len_list_gpx', len(list_gpx[0]))

                #------------------------New interpolate------------------------------------
                a = [list_gpx[0], list_gpx[1], list_gpx[2], list_gpx[3], list_gpx[-1]] 
                gpx_list = [[], [], [], [], []]
          
                gpx_list[-1].append(a[-1][0])
                gpx_list[0].append(a[0][0])
                gpx_list[1].append(a[1][0])
                gpx_list[2].append(a[2][0])
                gpx_list[3].append(a[3][0])

                for i in range(1, len(a[-1])):
                    dist_time = int(a[-1][i] - a[-1][i-1])
                    if dist_time == 1:
                        gpx_list[-1].append(a[-1][i-1] + 0.5) # Time
                        gpx_list[-1].append(a[-1][i])
                        gpx_list[0].append(a[0][i-1] + (a[0][i] - a[0][i-1]) / 2) # lat
                        gpx_list[0].append(a[0][i])
                        gpx_list[1].append(a[1][i-1] + (a[1][i] - a[1][i-1]) / 2) # lon
                        gpx_list[1].append(a[1][i])
                        gpx_list[2].append(a[2][i-1] + (a[2][i] - a[2][i-1]) / 2) # alt
                        gpx_list[2].append(a[2][i])
                        gpx_list[3].append(a[3][i-1]) # gr
                        gpx_list[3].append(a[3][i])
                    else:
                        f, ff, proc_freq, proc_text = dist_time, dist_time, 1000, 'Gr: ' + str(g) + '/' + str(len(gr)) + '    Day: ' + str(d) + '/' + str(len(grp)) + ' Interpolate GPX: '
                        for j in range(dist_time):
                            if dist_time > 99999:
                                ff -= 1
                                UAVProcess.progress(self, f, ff, proc_freq, proc_text)
                            gpx_list[-1].append(a[-1][i-1] + j+1 - 0.5)
                            gpx_list[-1].append(a[-1][i-1] + j+1)
                            gpx_list[0].append(a[0][i-1] + ((a[0][i] - a[0][i-1]) / (dist_time)) * (j+1) - ((a[0][i] - a[0][i-1]) / (dist_time * 2)))
                            gpx_list[0].append(a[0][i-1] + ((a[0][i] - a[0][i-1]) / (dist_time)) * (j+1))
                            gpx_list[1].append(a[1][i-1] + ((a[1][i] - a[1][i-1]) / (dist_time)) * (j+1) - ((a[1][i] - a[1][i-1]) / (dist_time * 2)))
                            gpx_list[1].append(a[1][i-1] + ((a[1][i] - a[1][i-1]) / (dist_time)) * (j+1))
                            gpx_list[2].append(a[2][i-1] + ((a[2][i] - a[2][i-1]) / (dist_time)) * (j+1) - ((a[2][i] - a[2][i-1]) / (dist_time * 2)))
                            gpx_list[2].append(a[2][i-1] + ((a[2][i] - a[2][i-1]) / (dist_time)) * (j+1))
                            gpx_list[3].append(a[3][i-1]) # gr
                            gpx_list[3].append(a[3][i])

                #-------------------------------------------------------------

                gpx_points = list(map(list, zip(*gpx_list)))

        
                print('gpx', gpx_list[-1][0], gpx_list[-1][-1], gpx_list[-1][-1] - gpx_list[-1][0])
                print('mag', list_mag[-1][0], list_mag[-1][-1], list_mag[-1][-1] - list_mag[-1][0])

                if list_mag[-1][0] < gpx_list[-1][0] and list_mag[-1][-1] < gpx_list[-1][0]:
                    mbox.setText('Gr' + ' ' + str(g) + ' Day '+ str(d) +'/'+ str(len(days)) + ' Не найдено совпадений времени')
                    mbox.show()
                    continue
                if list_mag[-1][0] > gpx_list[-1][-1] and list_mag[-1][-1] < gpx_list[-1][-1]:
                    mbox.setText('Gr' + ' ' + str(g) + ' Day '+ str(d) +'/'+ str(len(days)) + ' Не найдено совпадений времени')
                    mbox.show()
                    continue

                for i in range(len(list_mag[-1])):
                    try:
                        start_gpx = gpx_list[-1].index(list_mag[-1][i])
                        start_mag = i
                        break
                    except:
                        continue
    
                cnt_mag = -1
                cnt_gpx = -1
    
                # Merge coord with attrs
                for i in range(start_mag, len(list_mag[-1])):
                    cnt_mag += 1
                    cnt_gpx += 1
    
                    try:
                        if data_mag[start_mag + cnt_mag][-1] == gpx_points[start_gpx + cnt_gpx][-1]:
                            point = data_mag[start_mag + cnt_mag][:-1]
                            point.extend([*gpx_points[start_gpx + cnt_gpx]])
                            data_merge0.append(point)
                        else:
                            for j in range(start_mag + cnt_mag, len(list_mag[-1])):
                                try:
                                    start_gpx = gpx_list[-1].index(list_mag[-1][j])
                                    start_mag = j
                                    point = data_mag[start_mag][:-1]
                                    point.extend([*gpx_points[start_gpx]])
                                    data_merge0.append(point)
                                    cnt_mag = 0
                                    cnt_gpx = 0
                                    break
                                except:
                                    continue
                    except:
                        break
            
                if len(data_merge0) == 0:
                    mbox.setText(str(d) +'/'+ str(len(days)) + 'Не найдено совпадений времени')
                    mbox.show()
            
                print('len_merge', len(data_merge0))
                data_merge += data_merge0

        # Shift time transpose
        if time_shift != 0:
            shift = int(time_shift * 2)
            list_merge = list(map(list, zip(*data_merge)))
            
            if shift > 0: # T cut in end
                list_merge[0] = list_merge[0][:-shift] # Cut end
                list_merge[1] = list_merge[1][:-shift]
                list_merge[2] = list_merge[2][:-shift]
                list_merge[3] = list_merge[3][shift:]
                list_merge[4] = list_merge[4][shift:]
                list_merge[5] = list_merge[5][shift:]
                list_merge[6] = list_merge[6][shift:]
                list_merge[7] = list_merge[7][shift:]
            else: # Time cut in end
                list_merge[0] = list_merge[0][-shift:] # Cut start
                list_merge[1] = list_merge[1][-shift:]
                list_merge[2] = list_merge[2][-shift:]
                list_merge[3] = list_merge[3][:shift]
                list_merge[4] = list_merge[4][:shift]
                list_merge[5] = list_merge[5][:shift]
                list_merge[6] = list_merge[6][:shift]
                list_merge[7] = list_merge[7][:shift]

            data_merge = list(map(list, zip(*list_merge)))

        if proc == 1 and self.dlg_UAV.process_list.item(1).checkState() == Qt.Checked:
            print(data_merge[0], 'stop merge')
            UAVProcess.run_process2(self, data_merge, proc, tic)
            return
        elif proc == 1 and self.dlg_UAV.process_list.item(2).checkState() == Qt.Checked:
            UAVProcess.run_process3(self, data_merge, proc, tic)
            return

        # Add points
        if self.dlg_UAV.all_project.isChecked():
            pnt = QgsVectorLayer('Point', File, 'memory')
        if self.dlg_UAV.one_group.isChecked():
            pnt = QgsVectorLayer('Point', 'MAG_' + day_pref +'_'+ sub, 'memory')
        if self.dlg_UAV.one_day.isChecked():
            pnt = QgsVectorLayer('Point', 'MAG_' + day_pref, 'memory')
        crs = QgsCoordinateReferenceSystem()
        crs.createFromId(4326)
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        pr.addAttributes([
                          QgsField('T', QVariant.Double, 'double', 7, 3), 
                          QgsField('QMC', QVariant.Int),
                          QgsField('ST', QVariant.Int),
                          QgsField('TIME', QVariant.String),
                          QgsField('LAT', QVariant.Double, 'double', 7, 7),
                          QgsField('LON', QVariant.Double, 'double', 7, 7),
                          QgsField('ALT', QVariant.Double, 'double', 7, 3),
                          QgsField('GR', QVariant.Int)
                         ])
        pnt.updateFields()
        
        fets = []
            

        f, ff, proc_freq, proc_text = len(data_merge), len(data_merge), 1000, 'Rendering: '
        for i, val in enumerate(data_merge):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            attrs = [val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7]]
            fet = QgsFeature()
            fet.setGeometry(QgsPoint(val[5], val[4]))
            fet.setAttributes(attrs)
            fets.append(fet) 
        pr.addFeatures(fets)
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(data_merge)))
        mboxi.show()
        mboxi.exec_()





    def read_var(self, layer):
        file_path = self.dlg_UAV.mQgsFileWidget_4.filePath()

        if len(file_path) == 0:
            mbox.setText("Нужно выбрать файл с вариациями")
            mbox.show()
            return

        file_paths = file_path.rsplit('"')
        for i in range(len(file_paths), -1, -1):
            if i % 2 == 0:
                del file_paths[i]
        file_paths = [file_path] if len(file_paths) == 0 else file_paths

        if len(file_paths[0]) == 0:
            return

        data_var = []

        for file in file_paths:
            # Read var
            if file.endswith(".txt"):
                with open(file, 'r', encoding = 'Windows-1251') as file:
                    lines = file.readlines()
                    words = lines[6].replace('\n','').split(' ')
                    Time = words[3] + ' ' + words[4]
                    UAVProcess.timeForm(self, Time, var=1)
        
                for i in range(len(lines)):
                    if lines[i][0] != ';' and len(lines[i]) > 1:
                        words = lines[i].replace('\n','').split(' ')
                        Time = words[3] + ' ' + words[4]
                        time_sec = datetime.strptime(Time, self.time_form_var).timestamp()
                        data0 = [float(words[0]) / 1000, int(words[1]), int(words[2]), Time, time_sec]
                        data_var.append(data0)

        data_var.sort(key=lambda x: x[-1], reverse=False)

        group_var = []
        group_var0 = []
        c = 1
        for i in range(1, len(data_var)):
            c += 1
            if abs(data_var[i-1][-1] - data_var[i][-1]) < 38:
                group_var0.append([data_var[i-1][0], data_var[i-1][-1]])
            else:
                group_var.append(group_var0)
                group_var0 = []
        group_var.append(group_var0)

        print('groups count', len(group_var))
        
        # Transpose
        group_list_var = []
        for group in group_var:
            list_data_var = list(map(list, zip(*group)))
            group_list_var.append(list_data_var)
        print('len_group_list_var', len(group_list_var))

        #------------------------New interpolate------------------------------------
        
        var_interp = [[], []]
    
        for gr in range(len(group_list_var)):
            self.dlg_UAV.progressBar.setValue(int((100/len(group_list_var)) * (gr+1)))
            self.dlg_UAV.progressBar.setFormat('Interpolate Variations: ' + str(gr+1) + '/' + str(len(group_list_var)))
            QApplication.processEvents()
            a = [group_list_var[gr][0], group_list_var[gr][-1]] 
            var_interp[-1].append(a[-1][0])
            var_interp[0].append(a[0][0])

            for i in range(1, len(a[-1])):
                dist_time = int(a[-1][i] - a[-1][i-1])
                if dist_time == 1:
                    var_interp[-1].append(a[-1][i-1] + 0.5) # Time
                    var_interp[-1].append(a[-1][i])
                    var_interp[0].append(a[0][i-1] + (a[0][i] - a[0][i-1]) / 2) # lat
                    var_interp[0].append(a[0][i])
                else:
                    for j in range(dist_time):
                        var_interp[-1].append(a[-1][i-1] + j+1 - 0.5)
                        var_interp[-1].append(a[-1][i-1] + j+1)
                        var_interp[0].append(a[0][i-1] + ((a[0][i] - a[0][i-1]) / (dist_time)) * (j+1) - ((a[0][i] - a[0][i-1]) / (dist_time * 2)))
                        var_interp[0].append(a[0][i-1] + ((a[0][i] - a[0][i-1]) / (dist_time)) * (j+1))

        return var_interp


    def variations(self, data_merge, proc, tic):
        print('start var', 'proc', proc)
        if proc == 0:
            tic = time.perf_counter()
            try:
                layer = self.vlayer
            except AttributeError:
                mbox.setText("Нужно загрузить слой в Load Data")
                mbox.show()
                return

        var_interp = self.read_var(layer)

        #-------------------------------------------------------------

        if self.dlg_UAV.med_check.isChecked():
            norm_T = float(np.median(var_interp[0], axis=0))
        else:
            norm_T = float(self.dlg_UAV.norm_T.text())

        norm_var = [[], []]
        for i in range(len(var_interp[-1])):
            norm_var[0].append(var_interp[0][i] - norm_T)
            norm_var[-1].append(var_interp[-1][i])

        # Load layer
        if proc == 0:
            time_index = self.dlg_UAV.time_CB.currentIndex() - 1
    
            Time = self.data[0][time_index]
            UAVProcess.timeForm(self, Time, var=0)
    
            f, ff, proc_freq, proc_text = len(self.data), len(self.data), 1000, 'Merge time: '
            for point in self.data:
                ff -= 1
                UAVProcess.progress(self, f, ff, proc_freq, proc_text)
    
                time_sec = datetime.strptime(point[time_index], self.time_form).timestamp()
                point.append(time_sec)

        if proc == 2:
            self.data = data_merge
            self.fieldList = [('T', 6), ('QMC', 2), ('ST', 2), ('TIME', 10), ('LAT', 6), ('LON', 6), ('ALT', 6), ('GR', 2)]


        # Add vars in T
        print('time norm', norm_var[-1][0], norm_var[-1][-1])
        print('time attrs', self.data[0][-1], self.data[-1][-1])

        try:
            if proc == 2:
                start = norm_var[-1].index(data_merge[0][-1])
            elif proc == 0:
                start = norm_var[-1].index(self.data[0][-1])
        except ValueError:
            mbox.setText('Не найдено совпадений времени')
            mbox.show()
            return

        cnt = -1
        f, ff, proc_freq, proc_text = len(self.data), len(self.data), 1000, 'Fill variations: '

        for i, point in enumerate(self.data):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            cnt += 1

            if point[-1] == norm_var[-1][start + cnt]:
                point[0] = round(point[0] - norm_var[0][start + cnt], 3)
            else:
                try:
                    start = norm_var[-1].index(point[-1])
                except:
                    pass
                cnt = 0
                point[0] = round(point[0] - norm_var[0][start], 3)

        if proc == 2 and self.dlg_UAV.process_list.item(2).checkState() == Qt.Checked:
            print(self.data[0], 'stop var')
            UAVProcess.run_process3(self, data_merge, proc, tic)
            return

        # Add points
        if proc == 0:
            pnt = QgsVectorLayer('Point', layer.name() + '_Var', 'memory')
        elif proc == 2:
            pnt = QgsVectorLayer('Point', 'MAG' + '_Var', 'memory')
        crs = QgsCoordinateReferenceSystem()
        crs.createFromId(4326)
        pnt.setCrs(crs)
        pr = pnt.dataProvider()

        for i in self.fieldList:
            pr.addAttributes([QgsField(i[0], i[1])])
        pnt.updateFields()
        
        fets = []

        f, ff, proc_freq, proc_text = len(self.data), len(self.data), 1000, 'Rendering: '
        for i, val in enumerate(self.data):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            attrs = []
            for v in val:
                attrs.extend([v])
            fet = QgsFeature()
            fet.setGeometry(QgsPoint(val[-3], val[-2]))
            fet.setAttributes(attrs)
            fets.append(fet)
        pr.addFeatures(fets)
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(self.data)))
        mboxi.show()
        mboxi.exec_()

    
    def check_var(self):
        try:
            layer = self.vlayer
        except AttributeError:
            mbox.setText("Нужно загрузить слой в Load Data")
            mbox.show()
            return

        # Load variations
        var_interp = self.read_var(layer)[1]

        start_time = var_interp[0]

        var_times = [0]
        var_times_flat = [None]
        for i in range(1, len(var_interp)):
            var_times.append(var_interp[i]-start_time)
            if var_interp[i] > var_interp[i-1] + 80:
                var_times_flat.append(None)
            else:
                var_times_flat.append(5.9)

        # Load layer
        time_index = self.dlg_UAV.time_CB.currentIndex() - 1

        Time = self.data[0][time_index]
        UAVProcess.timeForm(self, Time, var=0)

        mag_times = []
        f, ff, proc_freq, proc_text = len(self.data), len(self.data), 1000, 'Calc Mag Times: '
        for point in self.data:
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)

            time_sec = datetime.strptime(point[time_index], self.time_form).timestamp()
            mag_times.append(time_sec-start_time)

        mag_times.sort()

        mag_times_flat = [6]
        for i in range(1, len(mag_times)):
            if mag_times[i] > mag_times[i-1] + 1:
                mag_times_flat.append(None)
            else:
                mag_times_flat.append(6)

        day_tick = []
        day_tick_m = []
        day_tick_n = []
        for i in range(int(var_times[-1]/86400)+1):
            day_tick.append(86400*i)
            day_tick_m.append(86400*i+43200)
            day_tick_n.append(str(i+1))

        fig, axs = plt.subplots(1, 1, figsize = [22, 4]) # Figure
        plt.subplots_adjust(top=0.97, bottom=0.2, left=0.04, right=0.90, hspace=0.020)

        axs.set_yticklabels([])
        axs.plot(mag_times, mag_times_flat, linewidth = 2, label = 'Съемка')
        axs.plot(var_times, var_times_flat, linewidth = 2, label = 'Вариации')
        for day in day_tick:
            axs.axvline(x = day, color = 'g', linestyle='--', linewidth=0.8)

        ticks1 = axs.set_xticks(day_tick_m, minor=True)
        labels1 = axs.set_xticklabels(day_tick_n, minor=True, fontsize=10, fontname="Arial", style='italic', color='g')

        for lab in labels1:
            lab.set_y(0.1)

        axs.tick_params(which='minor', axis='x', bottom = False)

        plt.suptitle('Длительности записей вариаций и съемки', y = 0.94, fontsize = 20)
        axs.set_xlim(0, var_times[-1])
        axs.set_ylim(4, 8)
        axs.set_xlabel('Время, сек', labelpad = 10, fontsize = 14)
        #axs.set_ylabel('Группа', fontsize = 20, rotation = 90, labelpad = 24)
        fig.legend(loc=(0.91, 0.5), framealpha=1.0, frameon=True, fontsize = 12)
        #plt.grid(True)
        plt.show()



    def add_IGRF(self):
        self.layer = self.iface.activeLayer()

        self.fieldList = []
        [self.fieldList.append([field.name(), field.type()]) for field in self.layer.fields()]
        self.items = QgsFieldComboBox()
        self.items1 = QgsFieldComboBox()
        self.items2 = QgsFieldComboBox()
        self.items3 = QgsFieldComboBox()

        self.items.setLayer(self.layer)
        self.items1.setLayer(self.layer)
        self.items2.setLayer(self.layer)
        self.items3.setLayer(self.layer)

        for i, val in enumerate(self.fieldList):
            if val[0] == 'LON' or val[0] == 'lon' or val[0] == 'Lon':
                self.items.setCurrentIndex(i)
            if val[0] == 'LAT' or val[0] == 'lat' or val[0] == 'Lat':
                self.items1.setCurrentIndex(i)
            if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                self.items2.setCurrentIndex(i)
            if not self.dlg_UAV.fixed_data.isChecked():
                if val[0] == 'TIME' or val[0] == 'DATETIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATA':
                    self.items3.setCurrentIndex(i)

        label, label1, label2, label3= QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel()
        label.setText('Поле долготы')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        label1.setText('Поле широты')
        label1.setAlignment(Qt.AlignCenter)
        label1.setFont(QFont('MS Shell Dlg 2', 10))
        label2.setText('Поле высоты')
        label2.setAlignment(Qt.AlignCenter)
        label2.setFont(QFont('MS Shell Dlg 2', 10))
        label3.setText('Поле времени')
        label3.setAlignment(Qt.AlignCenter)
        label3.setFont(QFont('MS Shell Dlg 2', 10))
        self.dlg = QDialog()

        gridLayout = QGridLayout()
        gridLayout.setVerticalSpacing(10)
        gridLayout.setHorizontalSpacing(30)
        gridLayout.addWidget(label, 0, 0)
        gridLayout.addWidget(self.items, 1, 0)
        gridLayout.addWidget(label1, 0, 1)
        gridLayout.addWidget(self.items1, 1, 1)
        gridLayout.addWidget(label2, 0, 2)
        gridLayout.addWidget(self.items2, 1, 2)
        if not self.dlg_UAV.fixed_data.isChecked():
            gridLayout.addWidget(label3, 0, 3)
            gridLayout.addWidget(self.items3, 1, 3)

        self.dlg.setWindowTitle("Fields selection")
        #self.dlg.resize(300, 200)
        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(self.add_IGRF_OK)
        btnBox.rejected.connect(self.rejectDlg)
        if not self.dlg_UAV.fixed_data.isChecked():
            gridLayout.addWidget(btnBox, 2, 3)
        else:
            gridLayout.addWidget(btnBox, 2, 2)
        self.dlg.setLayout(gridLayout)
        self.dlg.exec_()

    def add_IGRF_OK(self):
        self.dlg.close()
        import UAVProcess.pyIGRF.value as igrf

        field_lon = self.items.currentField()
        field_lat = self.items1.currentField()
        field_alt = self.items2.currentField()
        field_time = self.items3.currentField()

        features = self.layer.getFeatures()

        # Time format
        for feature in features:
            Time = feature.attribute(field_time)
            UAVProcess.timeForm(self, Time, var=0)
            break

        # Fixed data
        if self.dlg_UAV.fixed_data.isChecked():
            year = int(self.dlg_UAV.year_str.text())
            if year % 4 == 0:
                year_sec = 31_622_400
            else:
                year_sec = 31_536_000
            month = int(self.dlg_UAV.month_str.text())
            day = int(self.dlg_UAV.day_str.text())

            moment1 = datetime(year, 1, 1, 00, 00, 00) # start year
            moment2 = datetime(year, month, day, 0, 0, 0)
            delta = moment2 - moment1
            d = delta.total_seconds() / year_sec
            time_year = year + d
        else:
            # Def year
            date_time_obj = datetime.strptime(Time, self.time_form)
            year = date_time_obj.date().year
            if year % 4 == 0:
                year_sec = 31_622_400
            else:
                year_sec = 31_536_000
            moment1 = datetime(year, 1, 1, 00, 00, 00) # start year


        fields = []

        # Load attrs layer
        f, ff, proc_freq, proc_text = self.layer.featureCount(), self.layer.featureCount(), 1000, 'Calculate: '
        for feature in features:
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)

            lon = feature.attribute(field_lon)
            lat = feature.attribute(field_lat)
            alt = feature.attribute(field_alt)
            
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.PointGeometry:
                if geomSingleType:
                    xy = geom.asPoint()
                    point = QgsPoint(xy)
                else:
                    xy = geom.asMultiPoint()
                    point = QgsPoint(xy[0])

            # calc share of year
            if not self.dlg_UAV.fixed_data.isChecked():
                time = feature.attribute(field_time)
                time_obj = datetime.strptime(time, self.time_form)
                mm = time_obj.date().month
                dd = time_obj.date().day
                hh = time_obj.time().hour
                m = time_obj.time().minute
                s = time_obj.time().second
                moment2 = datetime(year, mm, dd, hh, m, s)
                delta = moment2 - moment1
                d = delta.total_seconds() / year_sec
                time_year = year + d

            mag = igrf.igrf_value(lat, lon, alt/1000, time_year)
            dec = round(float(mag[0]), 5)
            inc = round(float(mag[1]), 5)
            F = round(float(mag[-1]), 3)

            fields0 = []
            for i in self.fieldList:
                fields0.extend([feature.attribute(i[0])])
            fields0.extend([dec, inc, F, point.x(), point.y()])
            fields.append(fields0)


        # Create points layer
        pnt = QgsVectorLayer('Point', self.layer.name() + '_igrf', 'memory')
        crs = self.layer.crs()
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        for i in self.fieldList:
            pr.addAttributes([QgsField(i[0], i[1])]) #add checked fields
        pr.addAttributes([
                       QgsField("DEC", QVariant.Double), 
                       QgsField("INC", QVariant.Double),
                       QgsField("F_norm", QVariant.Double)
                       ])
        pnt.updateFields()
        fet = QgsFeature()

        f, ff, proc_freq, proc_text = len(fields), len(fields), 1000, 'Rendering: '
        for i in fields:
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            attrs = i[:-2]
            fet.setGeometry(QgsPoint(i[-2], i[-1]))
            fet.setAttributes(attrs)
            pr.addFeatures([fet])
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)


    def load_layer_data(self):
        self.vlayer = self.iface.activeLayer()
        self.fieldList = []
        self.data = []
        [self.fieldList.append((field.name(), field.type())) for field in self.vlayer.fields()]
        if self.vlayer == None or self.vlayer.type() == QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран слой с точками")
            mbox.show()
            return
        features = self.vlayer.getFeatures()

        f, ff, proc_freq, proc_text = self.vlayer.featureCount(), self.vlayer.featureCount(), 1000, 'Load Data: '
        
        # Create points array
        for feature in features:
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)

            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.PointGeometry:
                if geomSingleType:
                    xy = geom.asPoint()
                    point = QgsPoint(xy)
                else:
                    xy = geom.asMultiPoint()
                    point = QgsPoint(xy[0])
            else:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                return
            attrs = [*feature.attributes(), point.x(), point.y()]
            self.data.append(attrs)

        CB = [self.dlg_UAV.field1_CB, self.dlg_UAV.field2_CB, self.dlg_UAV.time_CB, self.dlg_UAV.alt1_CB, self.dlg_UAV.alt2_CB, self.dlg_UAV.pr_CB]
        for i in range(self.dlg_UAV.field1_CB.count() + 1):
            for item in CB:
                item.removeItem(0)
        for item in CB:
                item.addItem('')
        for i in self.fieldList:
            for item in CB:
                item.addItem(i[0])

        for i, val in enumerate(self.fieldList):
            if val[0] == 'TIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATATIME':
                self.dlg_UAV.time_CB.setCurrentIndex(i + 1)
            if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                self.dlg_UAV.alt1_CB.setCurrentIndex(i + 1)
            if val[0] == 'Alt_con':
                self.dlg_UAV.alt2_CB.setCurrentIndex(i + 1)
            if val[0] == 'FIELD' or val[0] == 'Field' or val[0] == 'T' or val[0] == 'T_reg':
                self.dlg_UAV.field1_CB.setCurrentIndex(i + 1)
            if val[0] == 'T_con':
                self.dlg_UAV.field2_CB.setCurrentIndex(i + 1)
            if val[0] == 'PR' or val[0] == 'Pr' or val[0] == 'pr':
                self.dlg_UAV.pr_CB.setCurrentIndex(i + 1)

        time_index = self.dlg_UAV.time_CB.currentIndex() - 1
        Time = self.data[0][time_index]
        UAVProcess.timeForm(self, Time, var=0)

        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat('Data loaded')
        self.dlg_UAV.label_15.setStyleSheet("background:rgba(255, 255, 200, 255);") 
        self.dlg_UAV.label_15.setText(self.vlayer.name())
        
    def LinesFromPoints(self):
        tic = time.perf_counter()
        vlayer = self.iface.activeLayer()
        if vlayer == None or vlayer.type() == QgsMapLayerType.RasterLayer:
            mbox.setText("Должен быть выбран слой с точками")
            mbox.show()
            return
        d = QgsDistanceArea()
        Dist1 = float(self.dlg_UAV.dist.text()) * 1.0001

        features = vlayer.getFeatures()
        cc = -1
        points = []
        DistArrNew = []
        Vertex = []
        VertexLines = []

        # Create points array
        f, ff, proc_freq, proc_text = vlayer.featureCount(), vlayer.featureCount(), 1000, 'Load Data: '
        for feature in features:
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            if geom.type() == QgsWkbTypes.PointGeometry:
                if geomSingleType:
                    xy = geom.asPoint()
                    point = QgsPoint(xy)
                else:
                    xy = geom.asMultiPoint()
                    point = QgsPoint(xy[0])
            else:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                mbox.exec_()
                return
            points.append(point)
        arrCount = len(points)

        
        #  Define lines
        f, ff, proc_freq, proc_text = arrCount, arrCount, 200, 'Calculation: '
        for i in range(1, arrCount):
            Vertex.append(points[0])
            for i in range(1, arrCount):
                x0 = points[0].x()
                y0 = points[0].y()
                for i in range(1, arrCount):
                    dist = math.sqrt((points[i].x()-x0)**2+(points[i].y()-y0)**2)
                    if dist < Dist1:
                        break
                del points[0]
                arrCount=len(points)

                ff -= 1
                UAVProcess.progress(self, f, ff, proc_freq, proc_text)

                points.insert(0, points.pop(i-1))
                Vertex.append(points[0])
                if dist > Dist1:
                    cc += 1
                    del Vertex[-1]
                    Vertex.reverse()
                    x0=Vertex[-1].x()
                    y0=Vertex[-1].y()
                    for i in range(len(points)):
                        dist=math.sqrt((points[i].x()-x0) ** 2 + (points[i].y()-y0) ** 2)
                        DistArrNew.append(dist)
                        if dist<Dist1:
                            break
                    minIndex = DistArrNew.index(min(DistArrNew))
                    points.insert(0, points.pop(minIndex))
                    if min(DistArrNew)<Dist1:
                        DistArrNew = []
                        if cc >= len(Vertex):
                            break
                        break
                    #Vertex.sort(key=lambda x: x.x(), reverse=False)
                    if len(Vertex) >= 2:
                        VertexLines.append(Vertex)
                    DistArrNew = []
                    Vertex = []
                    break
                DistArrNew = []
        VertexLines.append(Vertex)

        # calc lenght lines
        measureL = []
        measureDist = []
        for i in VertexLines:
            for j in i:
                a = QgsPointXY(j)
                measureDist.append(a)
            measureL.append(round(d.measureLine(measureDist), 3))
            measureDist = []

        # create layer
        Lines = QgsVectorLayer("LineString", "Lines", "memory")
        crs = vlayer.crs()
        Lines.setCrs(crs)
        pr = Lines.dataProvider()
        pr.addAttributes([QgsField("PR", QVariant.Int), QgsField("Lenght", QVariant.Double,'double', 20, 3)])
        Lines.updateFields()
        fet = QgsFeature()

        # add lines
        for i in range(len(VertexLines)):
            fet.setGeometry(QgsGeometry.fromPolyline(VertexLines[i]))
            fet.setAttributes([i + 1, measureL[i]])
            pr.addFeatures([fet])
            Lines.updateExtents()
            QgsProject.instance().addMapLayer(Lines)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        print(f"time: {toc - tic:0.3f} секунд")
        print("Построено линий", len(VertexLines))

    def cut_points(self, data_merge, proc, tic):
        if proc == 0:
            vlayer = self.iface.activeLayer()
            crs = vlayer.crs()
            targetCrs = self.dlg_UAV.mQgsProjectionSelectionWidget.crs().authid()

            if len(targetCrs) == 0 and crs.authid() == 'EPSG:4326':
                mbox.setText("Нужно выбрать прямоугольную систему координат")
                mbox.show()
                return

            crsSrc = QgsCoordinateReferenceSystem(vlayer.crs().authid()) # input crs
            crsDest = QgsCoordinateReferenceSystem(targetCrs) # WGS 84 convert rect proj
            transformContext = QgsProject.instance().transformContext()
            self.xform = QgsCoordinateTransform(crsSrc, crsDest, transformContext)

            if vlayer == None or vlayer.type() == QgsMapLayerType.RasterLayer:
                mbox.setText("Должен быть выбран слой с точками")
                mbox.show()
                return
            self.fieldList = []
            [self.fieldList.append([field.name(), field.type()]) for field in vlayer.fields()]
            self.items, self.items1 = QgsFieldComboBox(), QgsFieldComboBox()
            self.items.setLayer(vlayer)
            self.items1.setLayer(vlayer)
            self.gr_index = None
    
            for i, val in enumerate(self.fieldList):
                if val[0] == 'TIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATATIME':
                    self.items.setCurrentIndex(i)
                if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                    self.items1.setCurrentIndex(i)
                if val[0] == 'Gr' or val[0] == 'GR' or val[0] == 'gr' or val[0] == 'Group' or val[0] == 'group' or val[0] == 'GROUP':
                    self.items2 = QgsFieldComboBox()
                    self.items2.setLayer(vlayer)
                    self.items2.setCurrentIndex(i)
                    self.gr_index = i
                    label2 = QtWidgets.QLabel()
                    label2.setText('Поле группы')
                    label2.setAlignment(Qt.AlignCenter)
                    label2.setFont(QFont('MS Shell Dlg 2', 10))
    
            label, label1 = QtWidgets.QLabel(), QtWidgets.QLabel(),
            
            label.setText('Поле времени')
            label.setAlignment(Qt.AlignCenter)
            label.setFont(QFont('MS Shell Dlg 2', 10))
            label1.setText('Поле высот датчика')
            label1.setAlignment(Qt.AlignCenter)
            label1.setFont(QFont('MS Shell Dlg 2', 10))
            
            self.dlg = QDialog()
            layout = QVBoxLayout()
            self.dlg.setWindowTitle("Fields selection")
            self.dlg.resize(180, 100)
            layout.addWidget(label)
            layout.addWidget(self.items)
            layout.addWidget(label1)
            layout.addWidget(self.items1)
            try:
                layout.addWidget(label2)
                layout.addWidget(self.items2)
            except:
                pass
            btnBox = QDialogButtonBox()
            btnBox.setStandardButtons(QDialogButtonBox.Ok)
            btnBox.accepted.connect(lambda: self.cut_pointsOK(data_merge = 0, proc = 0, tic = 0))
            btnBox.rejected.connect(self.rejectDlg)
            layout.addWidget(btnBox)
            self.dlg.setLayout(layout)
            self.dlg.exec_()
        elif proc == 3:
            UAVProcess.cut_pointsOK(self, data_merge, proc, tic)
            return


    def cut_pointsOK(self, data_merge, proc, tic):
        print('Start cut', 'proc', proc)

        coef = float(self.dlg_UAV.coef.text()) * 2.6
        c = 0
        fields = []
        Fieldex = []
        Fieldexes = []
        Fieldexes50 = []
        fi = []
        fii = []
        fin = []
        Means = []
        Means1 = []
        Splits = []
        Distarr = []
        Degarr = []

        time_pos = 2

        if proc == 0:
            self.dlg.close()
            check_time = self.items.currentField()
            check_alt = self.items1.currentField()
            tic = time.perf_counter()
            vlayer = self.iface.activeLayer()
            features = vlayer.getFeatures()

            # Time format
            for feature in features:
                Time = feature.attribute(check_time)
                UAVProcess.timeForm(self, Time, var=0)
                break

            # Load Data
            f, ff, proc_freq, proc_text = vlayer.featureCount(), vlayer.featureCount(), 1000, 'Load Data: '
            for feature in features:
                ff -= 1
                UAVProcess.progress(self, f, ff, proc_freq, proc_text)
    
                Time = feature.attribute(check_time)
                Alt = feature.attribute(check_alt)
                
                geom = feature.geometry()
                geom.transform(self.xform)

                geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
                if geom.type() == QgsWkbTypes.PointGeometry:
                    if geomSingleType:
                        xy = geom.asPoint()
                        point = QgsPoint(xy)
                    else:
                        xy = geom.asMultiPoint()
                        point = QgsPoint(xy[0])
    
                #Time.__class__.__name__ != 'QDateTime'
                
                try:
                    TimeSec = datetime.strptime(Time, self.time_form).timestamp()
                except:
                    mbox.setText('Формат времени не подходит')
                    mbox.show()
                    return
                    #TimeSec = Time

                fields0 = [Time, float(Alt), TimeSec, point]
                for i in self.fieldList:
                    fields0.extend([feature.attribute(i[0])])
                fields.append(fields0)
        elif proc == 3:
            self.gr_index = -1
            targetCrs = self.dlg_UAV.mQgsProjectionSelectionWidget.crs().authid()
            if len(targetCrs) == 0:
                mbox.setText("Нужно выбрать прямоугольную систему координат")
                mbox.show()
                return
            crsSrc = QgsCoordinateReferenceSystem("EPSG:4326") # WGS 84
            crsDest = QgsCoordinateReferenceSystem(targetCrs) # WGS 84 convert rect proj
            transformContext = QgsProject.instance().transformContext()
            xform = QgsCoordinateTransform(crsSrc, crsDest, transformContext)
            
            if self.dlg_UAV.process_list.item(1).checkState() != Qt.Checked:
                self.data = data_merge

            f, ff, proc_freq, proc_text = len(self.data), len(self.data), 1000, 'Load Data: '
            for point in self.data:
                ff -= 1
                UAVProcess.progress(self, f, ff, proc_freq, proc_text)

                # forward transformation: src -> dest
                pt = xform.transform(QgsPointXY(point[5], point[4]))
                fields.append([point[3], point[6], point[8], QgsPoint(pt.x(), pt.y()), point[0], point[1], point[2], point[3], round(point[4], 7), round(point[5], 7), round(point[6], 3), point[7]])

        if self.gr_index:
            if proc == 3:
                fields.sort(key=lambda x: (x[-1], x[time_pos]), reverse=False)
            elif proc == 0:
                fields.sort(key=lambda x: (x[self.gr_index + 4], x[time_pos]), reverse=False)
        else:
            fields.sort(key=lambda x: x[time_pos], reverse=False)
       

        print(fields[1]) 
        print(fields[0]) 
        timeStep = fields[1][2] - fields[0][2] # define Time Step

        f, ff, proc_freq, proc_text = len(fields), len(fields), 1000, 'Calculate Cut Points: '
        for i in range(1, len(fields)):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            x0 = fields[0][3].x()
            y0 = fields[0][3].y()
            dx = fields[i][3].x() - fields[i-1][3].x()
            dy = fields[i][3].y() - fields[i-1][3].y()
            if dy == 0:
                dy = 0.00000001
            tga = dx/dy

            deg = math.degrees(math.atan(tga))
            if 84 < deg or deg < -84:
                deg = abs(deg) 
            dist = math.sqrt((fields[i][3].x()-x0)**2+(fields[i][3].y()-y0)**2)
            disti = math.sqrt((fields[i][3].x()-fields[i-1][3].x())**2+(fields[i][3].y()-fields[i-1][3].y())**2)
            fields[i-1].insert(4, deg)
            fields[i-1].insert(5, dist)
            fields[i-1].insert(6, disti)
            Fieldex0 = []
            for j in range(len(fields[i-1])):
                Fieldex0.extend([fields[i-1][j]])
            Fieldex.append(Fieldex0)
        fields[i].insert(4, deg)
        fields[i].insert(5, dist)
        fields[i].insert(6, disti)
        Fieldex0 = []
        
        for j in range(len(fields[i])):
            Fieldex0.extend([fields[i][j]])
        Fieldex.append(Fieldex0)                # Arr of attrs
        
        #  Define line
        for i in range(1, len(Fieldex)):
            if Fieldex[i][5] > 15 and 1.2 < Fieldex[i][6] < 60:
                Fieldexes.append(Fieldex[i])
                Distarr.append(Fieldex[i][6])
                Degarr.append(Fieldex[i][4])

        npDeg = np.median(Degarr)

        Degarr2 = []
        Deg2 = []
        for i, val in enumerate(Degarr):
             Deg2.append(val)
             if i % 30 == 0 and (npDeg - 10 < val < npDeg + 10):
                Degarr2.append(np.median(Deg2))
                Deg2 = []
        npDeg2 = np.median(Degarr2)
        
        print('deg1', npDeg)
        print('deg2', npDeg2)

        if np.median(Distarr) > 10: # for dist >10
            c = 0
            for i in range(1, len(Fieldexes)):
                if npDeg - (5 * coef) < Fieldexes[i][4] < npDeg + (5 * coef):
                    fin.append(Fieldexes[i])
                    c += 1
                else:
                    if c > 5:
                        fin.append(Fieldexes[i])
                        c = 0
            c=0
            for i in range(1, len(fin)):
                c+=1
                if fin[c][2]>fin[c-1][2]+10:
                    if fin[c-1][2]>fin[c-2][2]+10:
                        del fin[c-1]
                        c-=1
        else:   # for dist <10
            for i in range(1, len(Fieldexes)):
                Fieldexes50.append(Fieldexes[i])
                if i % 20 == 0:
                    fi.append(Fieldexes50)
                    Fieldexes50 = []
            fi.append(Fieldexes)
            for i in range(len(fi)):
                Sums=[]
                for j in range(0, len(fi[i])):
                    Sums.append(fi[i][j][4])
                Means.append(np.mean(Sums))
            c=0
            els=0
            cnt=0
            j=0
            while cnt<len(Means)-1:
                cnt+=1
                if (Means[cnt-1]-(0.5*coef) < Means[cnt] < Means[cnt-1]+(0.5*coef))  and (npDeg2 - 10 < Means[cnt] < npDeg2 + 10):
                    c+=1
                    if c==1:
                        split=np.array_split(fi[cnt-2], 2)
                        for i in range(2):
                            splits=np.mean(split[i][:, 4])
                            if splits>Means[cnt-1]-(4*coef) and splits<Means[cnt-1]+(4*coef):
                                for j in range(10):
                                    if len(fi[cnt-3])>(29+(i*10)) and split[i][j][2]==fi[cnt-3][19+(i*10)][2]+timeStep: # against duplicate
                                        break
                                    fi[cnt-1].append(split[i][j])
                            else:
                                split5End=(np.array_split(split[i], 2))[1]
                                splits5=np.mean(split5End[:, 4])
                                if splits5>Means[cnt-1]-(6*coef) and splits5<Means[cnt-1]+(6*coef):
                                    for j in range(5, 10):
                                        fi[cnt-1].append(split[i][j])
                    fii.append(fi[cnt-1])
                    Means1.append(Means[cnt-1])
                else:
                    els+=1
                    if c>=1:
                        split=np.array_split(fi[cnt], 2)
                        for i in range(2):
                            splits=np.mean(split[i][:, 4])
                            if splits>Means[cnt-1]-(4*coef) and splits<Means[cnt-1]+(4*coef):
                                for j in range(10):
                                    fi[cnt-1].append(split[i][j])
                            else:
                                split5Start=(np.array_split(split[i], 2))[0]
                                splits5=np.mean(split5Start[:, 4])
                                if splits5>Means[cnt-1]-(8*coef) and splits5<Means[cnt-1]+(8*coef):
                                    for j in range(5):
                                        fi[cnt-1].append(split[i][j])
                                break
                        fii.append(fi[cnt-1])
                        Means1.append(Means[cnt-1])
                    c=0
            npm=np.median(Means1)
            c=-1
            for i in range(len(Means1)):
                c+=1
                if Means1[c]>npm-(0.8*coef) and Means1[c]<npm+(0.8*coef):
                    pass
                else:
                    del Means1[c]
                    del fii[c]
                    c-=1
            fin=[]
            for j in range(len(fii)):
                for i in range(len(fii[j])):
                    fin.append(fii[j][i])
        fin.sort(key=lambda x: x[time_pos], reverse=False)

        # Create points layer
        if proc == 3 and self.dlg_UAV.process_list.item(3).checkState() == Qt.Checked:
            print('stop cut')
            UAVProcess.run_process4(self, fin, proc, tic)
            return
        elif proc == 3 and self.dlg_UAV.process_list.item(3).checkState() != Qt.Checked:
            pnt = QgsVectorLayer('PointZ', 'MAG' + '_Cut', 'memory')
            crs = crsDest
        elif proc == 0:
            pnt = QgsVectorLayer('PointZ', vlayer.name() + '_Cut', 'memory')
            crs = self.dlg_UAV.mQgsProjectionSelectionWidget.crs()
        
        pnt.setCrs(crs)
        pr = pnt.dataProvider()

        for i in self.fieldList:
            pr.addAttributes([QgsField(i[0], i[1])]) #add checked fields
        pnt.updateFields()
        fet = QgsFeature()

        f, ff, proc_freq, proc_text = len(fin), len(fin), 1000, 'Rendering: '
        for i in range(len(fin)):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            attrs = []
            attrs.extend(fin[i][7:])
            fet.setGeometry(QgsPoint(fin[i][3].x(), fin[i][3].y(), float(fin[i][1])))
            fet.setAttributes(attrs)
            pr.addFeatures([fet])
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(fin)))
        mboxi.show()
        mboxi.exec_()

    def edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr):
        x_reg = i[2].x()
        y_reg = i[2].y()
        dist = round(((x_ctrl - x_reg)**2 + (y_ctrl - y_reg)**2)**0.5, 3)
        if dist < dist_ctrl:
            T0 = i[0]
            T1 = ctrl[0]
            Time0 = i[1]
            Time1 = ctrl[1]
            alt0 = i[3]
            alt1 = ctrl[3]
            alt_err = alt0 - alt1
            alt_err_abs = abs(alt0 - alt1)
            T_err = T0-T1
            T_err_abs = abs(T_err)
            self.fin.append([T0, T1, Time0, Time1, x_reg, y_reg, x_ctrl, y_ctrl, alt0, alt1, alt_err, alt_err_abs, dist, T_err, T_err_abs, pr])

    def Control(self):
        reg_layer = self.dlg_UAV.MapLayer_CB.currentLayer()
        con_layer = self.dlg_UAV.MapLayer_control_CB.currentLayer()

        self.fieldList_reg = []
        self.fieldList_con = []
        [self.fieldList_reg.append([field.name(), field.type()]) for field in reg_layer.fields()]
        [self.fieldList_con.append([field.name(), field.type()]) for field in con_layer.fields()]
        self.items_reg = QgsFieldComboBox()
        self.items1_reg = QgsFieldComboBox()
        self.items2_reg = QgsFieldComboBox()
        self.items_con = QgsFieldComboBox()
        self.items1_con = QgsFieldComboBox()
        self.items2_con = QgsFieldComboBox()
        self.items_reg.setLayer(reg_layer)
        self.items1_reg.setLayer(reg_layer)
        self.items2_reg.setLayer(reg_layer)
        self.items_con.setLayer(con_layer)
        self.items1_con.setLayer(con_layer)
        self.items2_con.setLayer(con_layer)

        gridLayout = QGridLayout()

        for i, val in enumerate(self.fieldList_reg):
            if val[0] == 'T' or val[0] == 'FIELD':
                self.items_reg.setCurrentIndex(i)
            if val[0] == 'TIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATATIME':
                self.items1_reg.setCurrentIndex(i)
            if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                self.items2_reg.setCurrentIndex(i)
            if val[0] == 'PR' or val[0] == 'Pr' or val[0] == 'pr':
                self.items3_reg = QgsFieldComboBox()
                self.items3_reg.setLayer(reg_layer)
                self.items3_reg.setCurrentIndex(i)
                self.gr_index = i
                label3 = QtWidgets.QLabel()
                label3.setText('Поле профиля')
                label3.setAlignment(Qt.AlignCenter)
                label3.setFont(QFont('MS Shell Dlg 2', 10))
                gridLayout.addWidget(label3, 0, 4)
                gridLayout.addWidget(self.items3_reg, 1, 4)
        for i, val in enumerate(self.fieldList_con):
            if val[0] == 'T' or val[0] == 'FIELD':
                self.items_con.setCurrentIndex(i)
            if val[0] == 'TIME' or val[0] == 'Time' or val[0] == 'time' or val[0] == 'DATATIME':
                self.items1_con.setCurrentIndex(i)
            if val[0] == 'ALT' or val[0] == 'Alt' or val[0] == 'alt' or val[0] == 'elev' or val[0] == 'ELEV' or val[0] == 'Elev' or val[0] == 'Alt_reg':
                self.items2_con.setCurrentIndex(i)
            if val[0] == 'PR' or val[0] == 'Pr' or val[0] == 'pr':
                self.items3_con = QgsFieldComboBox()
                self.items3_con.setLayer(con_layer)
                self.items3_con.setCurrentIndex(i)
                gridLayout.addWidget(self.items3_con, 2, 4)

        label, label1, label2, label_reg, label_con = QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel(), QtWidgets.QLabel()
        label.setText('Поле поля')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        label1.setText('Поле времени')
        label1.setAlignment(Qt.AlignCenter)
        label1.setFont(QFont('MS Shell Dlg 2', 10))
        label2.setText('Поле высот датчика')
        label2.setAlignment(Qt.AlignCenter)
        label2.setFont(QFont('MS Shell Dlg 2', 10))
        label_reg.setText('Reg')
        label_reg.setAlignment(Qt.AlignRight)
        label_reg.setFont(QFont('MS Shell Dlg 2', 10))
        label_con.setText('Con')
        label_con.setAlignment(Qt.AlignRight)
        label_con.setFont(QFont('MS Shell Dlg 2', 10))
        self.dlg = QDialog()

        
        gridLayout.setVerticalSpacing(10)
        gridLayout.setHorizontalSpacing(30)
        gridLayout.addWidget(label, 0, 1)
        gridLayout.addWidget(self.items_reg, 1, 1)
        gridLayout.addWidget(self.items_con, 2, 1)
        gridLayout.addWidget(label1, 0, 2)
        gridLayout.addWidget(self.items1_reg, 1, 2)
        gridLayout.addWidget(self.items1_con, 2, 2)
        gridLayout.addWidget(label2, 0, 3)
        gridLayout.addWidget(self.items2_reg, 1, 3)
        gridLayout.addWidget(self.items2_con, 2, 3)
        gridLayout.addWidget(label_reg, 1, 0)
        gridLayout.addWidget(label_con, 2, 0)

        self.dlg.setWindowTitle("Fields selection")

        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(self.ControlOK)
        btnBox.rejected.connect(self.rejectDlg)
        gridLayout.addWidget(btnBox, 3, 3)
        self.dlg.setLayout(gridLayout)
        self.dlg.exec_()        

    def ControlOK(self):
        self.dlg.close()
        tic = time.perf_counter()
        check_fields = []
        check_fields.append([self.items_reg.currentField(), self.items1_reg.currentField(), self.items2_reg.currentField()])
        check_fields.append([self.items_con.currentField(), self.items1_con.currentField(), self.items2_con.currentField()])

        try:
            pr_col = self.items3_reg.currentField()
        except:
            pr_col = None

        layer_list = []
        layer_list.append(self.dlg_UAV.MapLayer_CB.currentLayer())
        layer_list.append(self.dlg_UAV.MapLayer_control_CB.currentLayer())
        dist_ctrl = float(self.dlg_UAV.dist_control.text())
        square_len = float(self.dlg_UAV.square_len.text())
        f0 = layer_list[0].featureCount()
        f1 = layer_list[1].featureCount()
        f_sum = f0 + f1
        extent = layer_list[1].extent()
        xmax = extent.xMaximum() + 50
        ymax = extent.yMaximum() + 50
        xmin = extent.xMinimum() - 50
        ymin = extent.yMinimum() - 50
        len_a = xmax - xmin
        len_b = ymax - ymin
        
        rows = int(len_b // square_len + 1)
        cols = int(len_a // square_len + 1)
        square_count = (rows + 1) * cols

        print('square_count', square_count)
        fields_list = []
        Distarr = []


        # Reg and Control points array
        f, ff, proc_freq, proc_text = f_sum, f_sum, 1000, 'Load Data: '

        for i in range(2):
            features = layer_list[i].getFeatures()
            fields = []
            for feature in features:
                ff -= 1
                UAVProcess.progress(self, f, ff, proc_freq, proc_text)

                T = float(feature.attribute(check_fields[i][0]))
                Time = feature.attribute(check_fields[i][1])
                Alt = float(feature.attribute(check_fields[i][2]))

                if pr_col != None:
                    pr = feature.attribute(pr_col)
                else:
                    pr = None

                geom = feature.geometry()
                geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
                if geom.type() == QgsWkbTypes.PointGeometry:
                    if geomSingleType:
                        xy = geom.asPoint()
                        point = QgsPoint(xy)
                    else:
                        xy = geom.asMultiPoint()
                        point = QgsPoint(xy[0])

                fields.append([T, Time, point, Alt, pr])
            fields_list.append(fields)

        # Squares
        squares = []
        for _ in range(square_count):
            squares.append([])

        f, ff, proc_freq, proc_text = len(fields_list[0]), len(fields_list[0]), 100, 'Calc Squares: '

        for i in fields_list[0]:
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)

            if ((xmin - dist_ctrl) < i[2].x() < (xmax + dist_ctrl)) and ((ymin - dist_ctrl) < i[2].y() < (ymax + dist_ctrl)):
                x_shift = i[2].x() - xmin
                y_shift = i[2].y() - ymin
                col = int(abs(x_shift // square_len) + 1)
                row = int(abs(y_shift // square_len) + 1)
                square_num = (row - 1) * cols + col
                try:
                    squares[square_num - 1].append(i)
                except IndexError:
                    print(square_num, cols, col, row)

        # Calc controls
        self.fin = []

        f, ff, proc_freq, proc_text = len(fields_list[1]), len(fields_list[1]), 100, 'Calc Controls: '

        for ctrl in fields_list[1]:
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)

            x_ctrl = ctrl[2].x()
            y_ctrl = ctrl[2].y()
            x_shift = x_ctrl - xmin
            y_shift = y_ctrl - ymin
            col = int(abs(x_shift // square_len) + 1)
            row = int(abs(y_shift // square_len) + 1)
            square_num = (row - 1) * cols + col

            pr = ctrl[-1]

            # Edge conditions
            for i in squares[square_num - 1]:
                UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # L
            if (square_len * (col-1) - dist_ctrl) < x_shift < (square_len * (col-1) + dist_ctrl) and square_num > 1:
                for i in squares[square_num - 2]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # R
            if (square_len * col - dist_ctrl) < x_shift < (square_len * col + dist_ctrl) and square_num < square_count:
                for i in squares[square_num]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # B
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for i in squares[square_num - 1 - cols]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # T
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols:
                for i in squares[square_num - 1 + cols]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)

            # T - 1
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols:
                for i in squares[square_num - 1 + cols - 1]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # T + 1
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols and square_num - 1 + cols + 1 < square_count:
                for i in squares[square_num - 1 + cols + 1]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # B - 1
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for i in squares[square_num - 1 - cols - 1]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
            # B + 1
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for i in squares[square_num - 1 - cols + 1]:
                    UAVProcess.edge_conditions(self, dist_ctrl, ctrl, x_ctrl, y_ctrl, i, pr)
       
        #Create points layer
        try:
            if isinstance(self.fin[0][2], str) == True:
                f_type = QVariant.String
            else:
                f_type = QVariant.Double
        except IndexError:
            mbox.setText("Охваты слоев в разных СК")
            mbox.show()
            return

        pnt = QgsVectorLayer("PointZ", "Ctrl_points", "memory")
        crs = layer_list[0].crs()
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        pr.addAttributes([QgsField('T_reg', QVariant.Double, 'double', 7, 3), 
                          QgsField('T_con', QVariant.Double, 'double', 7, 3),
                          QgsField('TIME', f_type),
                          QgsField('TIME_con', f_type),
                          QgsField('x_reg', QVariant.Double, 'double', 20, 7),
                          QgsField('y_reg', QVariant.Double, 'double', 20, 7),
                          QgsField('x_con', QVariant.Double, 'double', 20, 7),
                          QgsField('y_con', QVariant.Double, 'double', 20, 7),
                          QgsField('Alt_reg', QVariant.Double, 'double', 7, 3),
                          QgsField('Alt_con', QVariant.Double, 'double', 7, 3),
                          QgsField('Alt_err', QVariant.Double, 'double', 7, 3),
                          QgsField('Alt_errabs', QVariant.Double, 'double', 7, 3),
                          QgsField('Dist', QVariant.Double, 'double', 7, 3),
                          QgsField('T_err', QVariant.Double, 'double', 7, 3),
                          QgsField('T_err_abs', QVariant.Double, 'double', 7, 3),
                          ])
        if pr_col != None:
            pr.addAttributes([QgsField('PR', QVariant.Int)])
        pnt.updateFields()
        fet = QgsFeature()
        
        # Remove dup
        if self.dlg_UAV.del_dup.isChecked():
            self.fin.sort(key = lambda x: (x[0], x[12]))
    
            temp = []
            for i, val in enumerate(self.fin):
                if self.fin[i-1][0] != val[0]:
                    temp.append(val)    
            self.fin = temp

            #self.fin.sort(key = lambda x: (x[1], x[12]))
            #temp = []
            #for i, val in enumerate(self.fin):
            #    if self.fin[i-1][1] != val[1]:
            #        temp.append(val)    
            #self.fin = temp

        # Sort
        sort_ctrl_index = self.dlg_UAV.sort_ctrl_CB.currentIndex()
        if sort_ctrl_index == 0:
            self.fin.sort(key = lambda x: (x[-1], x[4])) # Sort X
        else:
            self.fin.sort(key = lambda x: (x[-1], -x[5])) # Sort Y

        # Create points
        for i in self.fin:
            attrs = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10], i[11], i[12], i[13], i[14], i[15]]
            fet.setGeometry(QgsPoint(i[4], i[5], i[8]))
            fet.setAttributes(attrs)
            pr.addFeatures([fet])
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)

        file_path = self.dlg_UAV.mQgsFileWidget.filePath()
        lay = self.iface.activeLayer()
        if file_path != "":
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "ESRI Shapefile"
            options.layerName = lay.name()
            QgsVectorFileWriter.writeAsVectorFormatV3(lay, file_path, QgsCoordinateTransformContext(), options)
            vlayer = QgsVectorLayer(file_path+'.shp', "Ctrl_points_saved", "ogr")
            QgsProject.instance().addMapLayer(vlayer)
            QgsProject.instance().removeMapLayers([lay.id()])

        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(self.fin)))
        mboxi.show()
        mboxi.exec_()


    def control_separator(self, data_merge, proc, tic):
        if proc == 0:
            tic = time.perf_counter()
            time_index = self.dlg_UAV.time_CB.currentIndex() - 1
            pr_index = self.dlg_UAV.pr_CB.currentIndex() - 1
    
            try:
                Time = self.data[0][time_index]
            except AttributeError:
                mbox.setText("Нужно загрузить слой в Load Data")
                mbox.show()
                return
            if self.dlg_UAV.pr_CB.currentText() == '':
                mbox.setText("Нужно выбрать поле номера профиля в Load Data")
                mbox.show()
                return

        elif proc == 5:
            print('Start add n profile', 'proc', proc)
            Time = data_merge[0][3]
            time_index = 3
            pr_index = -3
            self.data = []
            for point in data_merge:
                self.data.append(point[:-2])

        UAVProcess.timeForm(self, Time, var=0)

        controls = []
        regs = []
        c = 0

        f, ff, proc_freq, proc_text = len(self.data), len(self.data), 1000, 'Ctrl-Reg separate: '
        regs.append(self.data[0])
        for i in range(1, len(self.data)):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)

            TimeSec0 = datetime.strptime(regs[-1][time_index], self.time_form).timestamp()
            TimeSec1 = datetime.strptime(self.data[i][time_index], self.time_form).timestamp()
            dist = ((self.data[i][-2] - regs[-1][-2])**2 + (self.data[i][-1] - regs[-1][-1])**2)**0.5
            if abs(TimeSec1) - abs(TimeSec0) > 3 and self.data[i][pr_index] == self.data[i-1][pr_index] and dist <= 10:
                controls.append(self.data[i])
            else:
                regs.append(self.data[i])

        # Filter dist
        c = 0
        section = []
        controls_cut = []
        controls_cut.append(controls[0])
        for i in range(1, len(controls)):
            if controls[i][pr_index] == controls[c][pr_index]:
                dist = ((controls[i][-2] - controls[i-1][-2])**2 + (controls[i][-1] - controls[i-1][-1])**2)**0.5
                if dist < 20:
                    controls_cut.append(controls[i])
                else:
                    if len(controls_cut) > 1:
                        segment_dist = ((controls_cut[-1][-2] - controls_cut[0][-2])**2 + (controls_cut[-1][-1] - controls_cut[0][-1])**2)**0.5
                        if segment_dist > 299:
                            section.extend(controls_cut)
                    controls_cut = []
            else:
                if len(controls_cut) > 1:
                    segment_dist = ((controls_cut[-1][-2] - controls_cut[0][-2])**2 + (controls_cut[-1][-1] - controls_cut[0][-1])**2)**0.5
                    if segment_dist > 299:
                        section.extend(controls_cut)
                controls_cut = []
                c = i

        # Add points
        if proc == 5:
            pnt = QgsVectorLayer('PointZ', 'MAG' + '_Reg', 'memory')
            pnt_ctrls = QgsVectorLayer('PointZ', 'MAG' + '_Ctrl', 'memory')
            targetCrs = self.dlg_UAV.mQgsProjectionSelectionWidget.crs().authid()
            crsDest = QgsCoordinateReferenceSystem(targetCrs)
            crs = crsDest
        elif proc == 0:
            crs = self.vlayer.crs()
            pnt = QgsVectorLayer('Point', self.vlayer.name()+ '_Reg', 'memory')
            pnt_ctrls = QgsVectorLayer('Point', self.vlayer.name()+ '_Ctrl', 'memory')
        
        pnt.setCrs(crs)
        pnt_ctrls.setCrs(crs)
        pr = pnt.dataProvider()
        pr_ctrls = pnt_ctrls.dataProvider()
        for i in self.fieldList:
            pr.addAttributes([QgsField(i[0], i[1])])
            pr_ctrls.addAttributes([QgsField(i[0], i[1])])
        pnt.updateFields()
        pnt_ctrls.updateFields()
        fet = QgsFeature()

        f, ff, proc_freq, proc_text = len(regs), len(regs), 1000, 'Rendering: '
        for i, val in enumerate(regs):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            fet.setGeometry(QgsPoint(val[-2], val[-1]))
            fet.setAttributes(val[:-2])
            pr.addFeatures([fet])
        pnt.updateExtents()

        for i, val in enumerate(section):
            fet.setGeometry(QgsPoint(val[-2], val[-1]))
            fet.setAttributes(val[:-2])
            pr_ctrls.addFeatures([fet])
        pnt_ctrls.updateExtents()

        QgsProject.instance().addMapLayer(pnt)
        QgsProject.instance().addMapLayer(pnt_ctrls)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(regs)))
        mboxi.show()
        mboxi.exec_()


    def add_n_profile(self, data_merge, proc, tic, rect):
        if proc == 0:
            tic = time.perf_counter()
            try:
                layer = self.vlayer
            except AttributeError:
                mbox.setText("Нужно загрузить слой в Load Data")
                mbox.show()
                return
            extent = layer.extent()
            crs = layer.crs()
            if crs.authid() == 'EPSG:4326':
                mbox.setText("СК слоя должна быть прямоугольной")
                mbox.show()
                return
            xmax = extent.xMaximum()
            ymax = extent.yMaximum()
            xmin = extent.xMinimum()
            ymin = extent.yMinimum()
            if self.dlg_UAV.time_CB.currentText() == '':
                mbox.setText("Нужно выбрать поле времени")
                mbox.show()
                return
            time_index = self.dlg_UAV.time_CB.currentIndex() - 1
            attrs = copy.deepcopy(self.data)
            attrs.sort(key=lambda x: x[time_index], reverse=False)
        elif proc == 4:
            self.fieldList = [('T', 6), ('QMC', 2), ('ST', 2), ('TIME', 10), ('LAT', 6), ('LON', 6), ('ALT', 6), ('GR', 2), ('PR', 2)]
            print('Start add n profile', 'proc', proc)
            attrs = []
            for pt in data_merge:
                attrs.append([pt[-8], pt[-7], pt[-6], pt[-5], pt[-4], pt[-3], pt[-2], pt[-1], pt[3].x(), pt[3].y()])
            attrs.sort(key=lambda x: x[3], reverse=False)

            xmin = min(attrs, key=lambda i : i[-2])[-2]
            xmax = max(attrs, key=lambda i : i[-2])[-2]
            ymin = min(attrs, key=lambda i : i[-1])[-1]
            ymax = max(attrs, key=lambda i : i[-1])[-1]

        dist_pr = float(self.dlg_UAV.dist_PR.text())
        width_line = float(self.dlg_UAV.width_line.text())
        
        len_a = xmax - xmin
        len_b = ymax - ymin
        centerXY = [xmin + len_a / 2, ymin + len_b / 2]

        rect_count = int(len_a // dist_pr)

        # Define angles
        f, ff, proc_freq, proc_text = len(attrs), len(attrs), 1000, 'Define angles: '

        for i in range(1, len(attrs)):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)

            x0 = attrs[i-1][-2]
            y0 = attrs[i-1][-1]
            x1 = attrs[i][-2]
            y1 = attrs[i][-1]
            dx = x1 - x0
            dy = y1 - y0
            if dy == 0:
                dy = 0.00000001
            tga = dx / dy
            deg = math.degrees(math.atan(tga))
            dist = ((x1 - x0)**2 + (y1 - y0)**2)**0.5
            attrs[i-1].extend([dist, deg])
        attrs[i].extend([dist, deg])

        # Define angle lines
        if len(attrs) >= 20000:
            gr_len = 20
        else:
            gr_len = 10
        band = []
        fi = []
        Means = []
        c = 0
        for i in attrs:
            if 1.2 < i[-2] < 60:
                c += 1
                band.append(i[-1])
            if c % gr_len == 0 and c > 0 and len(band) != 0:
                fi.append(band)
                band = []
        fi.append(band)

        Sums = []
        direct = []
        for i in fi:
            Sums = []
            Sums.append(i[0])
            for j in range(1, len(i)):
                if abs(i[j] - i[j-1]) >= 178.5: # For near 90 angle
                    if i[j-1] > 0:
                        direct.append(i[j-1] - 90)
                    else:
                        direct.append(i[j-1] + 90)
                else:
                    Sums.append(i[j])
            Means.append(np.mean(Sums))

        print('len_dir', len(direct))
        print('med_dir', np.median(direct))

        npDeg = -np.median(Means)
        print('deg1', npDeg, len(Means))
        filtered = list(filter(lambda x: ((-npDeg - 7.5) < x < (-npDeg + 7.5)), Means))
        npDeg = -np.median(filtered)
        print('deg2', npDeg, len(filtered))

        Means = []
        gg = []
        band = []

        for i in attrs:
            if (1.2 < i[-2] < 60) and (-npDeg - 7.5 <  i[-1] < -npDeg + 7.5):
                c += 1
                band.append(i[-1])
            if c % int(gr_len + 10) == 0 and c > 0 and len(band) != 0:
                gg.append(band)
                band = []
        gg.append(band)

        Sums = []
        for i in gg:
            Sums.append(np.mean(i))
        if not np.isnan(-np.median(Sums)):
            npDeg = -np.median(Sums)
            print('deg3', npDeg, len(Sums))
        
        if len(attrs) >= 10000:
            filtered = list(filter(lambda x: ((-npDeg - 0.05) < x < (-npDeg + 0.05)), Sums))
            if len(filtered) > 4:
                npDeg = -np.median(filtered)
                print('deg4', npDeg, len(filtered))

        if len(direct) >= len(attrs) / 3:
            if np.median(direct) > 0:
                npDeg = np.median(direct) + 90
            else:
                npDeg = np.median(direct) - 90
            print('deg_dir', npDeg)

        # Define rectangles
        cos = math.cos(math.radians(npDeg))
        sin = math.sin(math.radians(npDeg))
        
        zero_points = []
        for point in attrs:
            x = point[-4]
            y = point[-3]
            X = (x - centerXY[0]) * cos + (y - centerXY[1]) * sin + centerXY[0]
            Y = -(x - centerXY[0]) * sin + (y - centerXY[1]) * cos + centerXY[1]
            zero_points.append([X, Y, *point])

        # Def extent zero points
        xmin = list(map(min, *zero_points))[0] - dist_pr / 2
        xmax = list(map(max, *zero_points))[0]
        ymin = list(map(min, *zero_points))[1] - 1
        ymax = list(map(max, *zero_points))[1] + 1
        shift_x = (dist_pr - width_line) / 2

        len_a = xmax - xmin
        rect_count = int(len_a // dist_pr + 1)
        rects = []
        pt = []

        f, ff, proc_freq, proc_text = rect_count, rect_count, 1, 'Numerate: '
        
        for i in range(rect_count):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)

            xy0 = QgsPointXY(xmin + i * dist_pr + shift_x, ymin)
            xy1 = QgsPointXY(xmin + (i + 1) * dist_pr - shift_x, ymin)
            xy2 = QgsPointXY(xmin + (i + 1) * dist_pr - shift_x, ymax)
            xy3 = QgsPointXY(xmin + i * dist_pr + shift_x, ymax)

            px0_turn = cos * (xy0[0]-centerXY[0]) - sin * (xy0[1]-centerXY[1]) + centerXY[0]
            py0_turn = sin * (xy0[0]-centerXY[0]) + cos * (xy0[1]-centerXY[1]) + centerXY[1]
            px1_turn = cos * (xy1[0]-centerXY[0]) - sin * (xy1[1]-centerXY[1]) + centerXY[0]
            py1_turn = sin * (xy1[0]-centerXY[0]) + cos * (xy1[1]-centerXY[1]) + centerXY[1]
            px2_turn = cos * (xy2[0]-centerXY[0]) - sin * (xy2[1]-centerXY[1]) + centerXY[0]
            py2_turn = sin * (xy2[0]-centerXY[0]) + cos * (xy2[1]-centerXY[1]) + centerXY[1]
            px3_turn = cos * (xy3[0]-centerXY[0]) - sin * (xy3[1]-centerXY[1]) + centerXY[0]
            py3_turn = sin * (xy3[0]-centerXY[0]) + cos * (xy3[1]-centerXY[1]) + centerXY[1]
            p0 = QgsPointXY(px0_turn, py0_turn)
            p1 = QgsPointXY(px1_turn, py1_turn)
            p2 = QgsPointXY(px2_turn, py2_turn)
            p3 = QgsPointXY(px3_turn, py3_turn)

            rects.append([p0, p1, p2, p3])

            x0 = xmin + i * dist_pr + shift_x
            x1 = xmin + (i + 1) * dist_pr - shift_x

            filtered = list(filter(lambda x: x0 < x[0] < x1, zero_points))

            for num, point in enumerate(filtered):
                point.insert(-4, i+1)
                pt.append(point[2:])

        # Add polygons
        if rect == 1:
            poly = QgsVectorLayer("Polygon", "Rect", "memory")
            poly.setCrs(crs)
            pr = poly.dataProvider()
            pr.addAttributes([QgsField("PR", QVariant.Double)])
            poly.updateFields()
            fet = QgsFeature()
            
            for i in range(rect_count):
                fet.setGeometry(QgsGeometry.fromPolygonXY([rects[i]]))
                fet.setAttributes([i+1])
                pr.addFeatures([fet])
            poly.updateExtents()
            QgsProject.instance().addMapLayer(poly)
            return

        # Sort
        if 0 <= npDeg <= 30:
            pt.sort(key = lambda x: (x[-5], -x[-3]))
        elif -30 <= npDeg < 0:
            pt.sort(key = lambda x: (x[-5], x[-3]))
        else:
            pt.sort(key = lambda x: (x[-5], x[-4]))

        # Add points
        if proc == 4 and self.dlg_UAV.process_list.item(4).checkState() == Qt.Checked:
            print('stop add n profile')
            UAVProcess.run_process5(self, pt, proc, tic)
            return
        elif proc == 4 and self.dlg_UAV.process_list.item(4).checkState() != Qt.Checked:
            pnt = QgsVectorLayer('PointZ', 'MAG' + '_Num', 'memory')
            targetCrs = self.dlg_UAV.mQgsProjectionSelectionWidget.crs().authid()
            crsDest = QgsCoordinateReferenceSystem(targetCrs)
            crs = crsDest
        elif proc == 0:
            pnt = QgsVectorLayer('Point', layer.name() + '_Num', 'memory')
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        for i in self.fieldList:
            pr.addAttributes([QgsField(i[0], i[1])])
        pr.addAttributes([QgsField('PR', QVariant.Int)])
        pnt.updateFields()
        fet = QgsFeature()

        f, ff, proc_freq, proc_text = len(pt), len(pt), 1000, 'Rendering: '

        for i, val in enumerate(pt):
            ff -= 1
            UAVProcess.progress(self, f, ff, proc_freq, proc_text)
            
            fet.setGeometry(QgsPoint(val[-4], val[-3]))
            fet.setAttributes(pt[i][:-4])
            pr.addFeatures([fet])
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)
        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(pt)))
        mboxi.show()
        mboxi.exec_()

    def plots(self, arg):
        PR = int(self.dlg_UAV.pr_num.text())
        step_interp = float(self.dlg_UAV.step_interp.text())
        step_average = int(self.dlg_UAV.Spline_CB.currentText())

        if self.dlg_UAV.pr_CB.currentText() == '':
            mbox.setText("Нужно загрузить слой в Load Data и выбрать столбец профиля")
            mbox.show()
            return
        if self.dlg_UAV.field1_CB.currentText() == '':
            mbox.setText("Нужно загрузить слой в Load Data и выбрать столбец поля")
            mbox.show()
            return

        pr_index = self.dlg_UAV.pr_CB.currentIndex() - 1
        T0_index = self.dlg_UAV.field1_CB.currentIndex() - 1
        T1_index = self.dlg_UAV.field2_CB.currentIndex() - 1
        alt1_index = self.dlg_UAV.alt1_CB.currentIndex() - 1
        alt2_index = self.dlg_UAV.alt2_CB.currentIndex() - 1

        # List profiles
        if not self.dlg_UAV.save_all_check.isChecked():
            profiles = [PR]
        else:
            directory = self.dlg_UAV.mQgsFileWidget_2.filePath()
            profiles = []
            profiles.append(self.data[0][pr_index])
            for i in range(1, len(self.data)):
                if self.data[i][pr_index] != self.data[i-1][pr_index]:
                    profiles.append(self.data[i][pr_index])

        # Сycle PR  
        f = len(profiles)
        ff = f
        for profile in profiles:
            ff -= 1
            self.dlg_UAV.progressBar.setValue(((f-ff)/f)*100)
            self.dlg_UAV.progressBar.setFormat('Profile № ' + str(profile))
            QApplication.processEvents()
            filtered = list(filter(lambda x: x[pr_index] == profile, self.data))
            if len(filtered) == 0:
                mbox.setText('Профиль ' + str(profile) + ' не найден')
                mbox.show()
                return
    
            # Lists of self.data
            T0, T1, dists, alt1, alt2 = [], [], [], [], []
            for i in filtered:
                T0.append(i[T0_index])
                T1.append(i[T1_index])
                alt1.append(i[alt1_index])
                alt2.append(i[alt2_index])
                if len(T0) == 1:
                    x0, y0 = i[-2], i[-1]
                x1, y1 = i[-2], i[-1]
                dist = ((x1 - x0)**2 + (y1 - y0)**2)**0.5 
                dists.append(dist)
    
            # Interpolate
            T0_interp, T1_interp, dists_interp, alt_interp, alt2_interp = [], [], [], [], []
            try:
                dist_interp1 = interp.interp1d(dists, T0, fill_value = "extrapolate")
                dist_interp2 = interp.interp1d(dists, T1, fill_value = "extrapolate")
                dist_interp3 = interp.interp1d(dists, alt1, fill_value = "extrapolate")
                dist_interp4 = interp.interp1d(dists, alt2, fill_value = "extrapolate")
                for i in range(int(dists[-1] // step_interp + 1)):
                    interpolated = dist_interp1(step_interp * i)
                    T0_interp.append(interpolated)
                       
                    interpolated = dist_interp2(step_interp * i)
                    T1_interp.append(interpolated)
                    dists_interp.append(step_interp * i)
                        
                    interpolated = dist_interp3(step_interp * i)
                    alt_interp.append(interpolated)
                        
                    interpolated = dist_interp4(step_interp * i)
                    alt2_interp.append(interpolated)
            except IndexError:
                mbox.setText("Нет выбранного значения в таблице")
                mbox.show()
                return
    
            # Average
            T0_aver = pd.Series(T0_interp).rolling(window=step_average).mean().iloc[step_average-1:].values
            T1_aver = pd.Series(T1_interp).rolling(window=step_average).mean().iloc[step_average-1:].values
    
            summ = 0
            for i in range(len(T0_aver)):
                dev = (T0_aver[i] - T1_aver[i]) ** 2
                summ += dev
            dev = round((summ / len(T0_aver)) ** 0.5, 3)
    
            # Def dists
            for i in range(int(step_average // 2)):
                del dists_interp[0]
                del dists_interp[-1]
                del alt_interp[0]
                del alt_interp[-1]
                del alt2_interp[0]
                del alt2_interp[-1]
    
            # Plots
            fig, axs = plt.subplots(1, 1, figsize = [18, 12]) # Figure
            if alt1_index != -1:
                axs1 = axs.twinx()
                axs1.plot(dists_interp, alt_interp, linewidth = 1, color='g', label = self.fieldList[alt1_index][0])
                axs1.set_ylabel(self.fieldList[alt1_index][0], fontsize = 20, rotation = 90, labelpad = 24)
                axs1.legend(loc=(0.9, 1.001), fontsize = 12)
            if alt2_index != -1:
                axs1.plot(dists_interp, alt2_interp, linewidth = 1, color='m', label = self.fieldList[alt2_index][0])
                axs1.legend(loc=(0.9, 1.001), fontsize = 12)
    
            plt.subplots_adjust(hspace=.20)
            axs.plot(dists_interp, T0_aver, linewidth = 1.8, label = 'Рядовые измерения')
            if T1_index != -1:
                axs.plot(dists_interp, T1_aver, linewidth = 1.8, label = 'Контрольные измерения')
                plt.suptitle('Контрольный профиль №' + str(profile) + ' (СКО = ' + str(dev) + ')', y = 0.94, fontsize = 20)
            else:
                plt.suptitle('Профиль №' + str(profile), y = 0.94, fontsize = 20)
            axs.set_xlim(dists_interp[0], dists_interp[-1])
            axs.set_xlabel('Расстояние, м', labelpad = 20, fontsize = 14)
            axs.set_ylabel('T, нТл', fontsize = 20, rotation = 90, labelpad = 24)
            axs.legend(loc=(0, 1), fontsize = 12)
            plt.grid(True)
            if not self.dlg_UAV.save_all_check.isChecked():
                plt.show()
            else:
                plt.savefig(directory + '/' + 'PR_' + str(profile))
                plt.close()
                plt.clf()

        self.dlg_UAV.progressBar.setValue(0)
        self.dlg_UAV.progressBar.setFormat(None)


    #--------------------------------------------------------------------------
    # run
    #--------------------------------------------------------------------------

    def run_UAV(self):
        self.dlg_UAV = UAVProcessDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_UAV.show()
        self.dlg_UAV.progressBar.setFormat(None)

        # Buttons click
        self.dlg_UAV.run_process.clicked.connect(lambda: self.run_process(data_merge = 0, proc = 0, tic = 0))
        self.dlg_UAV.open_files.clicked.connect(self.load_files)
        self.dlg_UAV.merge_coord_time.clicked.connect(self.merge_coord_time)
        self.dlg_UAV.variations.clicked.connect(lambda: self.variations(data_merge = 0, proc = 0, tic = 0))
        self.dlg_UAV.check_var.clicked.connect(self.check_var)
        self.dlg_UAV.add_IGRF.clicked.connect(self.add_IGRF)
        self.dlg_UAV.load_layer_data.clicked.connect(self.load_layer_data)
        self.dlg_UAV.cut_points.clicked.connect(lambda: self.cut_points(data_merge = 0, proc = 0, tic = 0))
        self.dlg_UAV.LinesFromPoints.clicked.connect(self.LinesFromPoints)
        self.dlg_UAV.Control.clicked.connect(self.Control)
        self.dlg_UAV.control_separator.clicked.connect(lambda: self.control_separator(data_merge = 0, proc = 0, tic = 0))
        self.dlg_UAV.add_rects.clicked.connect(lambda: self.add_n_profile(data_merge = 0, proc = 0, tic = 0, rect = 1))
        self.dlg_UAV.add_n_PR.clicked.connect(lambda: self.add_n_profile(data_merge = 0, proc = 0, tic = 0, rect = 0))
        self.dlg_UAV.plot.clicked.connect(self.plots)
        # Filters
        self.dlg_UAV.MapLayer_CB.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.dlg_UAV.MapLayer_control_CB.setFilters(QgsMapLayerProxyModel.PointLayer)