# -*- coding: utf-8 -*-
"""
        begin                : 2024-03-06

"""
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from PyQt5 import QtGui, QtCore, QtWidgets
from qgis.core import *

from .resources import *

# Import the code for the dialog
from .GIS_Project_Updater_dialog import GIS_Project_UpdaterDialog
import shutil
import os.path
import glob

class GIS_Project_Updater:

    def __init__(self, iface):

        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'GIS_Project_Updater_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&GIS Project Updater')
        self.toolbar = self.iface.addToolBar(u'GIS Project Updater')
        self.toolbar.setObjectName(u'GIS Project Updater')

        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message): return QCoreApplication.translate('GIS_Project_Updater', message)


    def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None: action.setStatusTip(status_tip)
        if whats_this is not None: action.setWhatsThis(whats_this)
        if add_to_toolbar: self.toolbar.addAction(action)
        if add_to_menu: self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)

        return action

    def initGui(self):
        icon_path = ':/plugins/GIS_Project_Updater/icon.png'
        self.add_action(icon_path, text=self.tr(u'GIS Project Updater'), callback=self.run, parent=self.iface.mainWindow())

        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&GIS Project Updater'), action)
            self.iface.removeToolBarIcon(action)



    #----------------------------------------------------------------------
    def load_folder(self):
        self.path = self.dlg_prj_updater.import_FileWidget.filePath()
        icon_folder = self.plugin_dir + "/folder_icon.png"

        # Tree widget 
        self.tree = self.dlg_prj_updater.treeWidget
        self.tree.clear()
        self.tree.setSelectionMode(3)

        root_slash = self.path.count('\\')
        for root, dirs, files in os.walk(self.path):
            slash = root.count('\\')
            cnt = slash - root_slash
        
        node_1 = self.path.split('\\')[-1]

        item = QtWidgets.QTreeWidgetItem(self.tree) 
        self.tree.addTopLevelItem(item)
        item.setText(0, node_1)
        item.setIcon(0, QIcon(icon_folder))

        parents = []
        parents.append(node_1)

        lvl_old = 0
        n = -1
        test = 0
        for root, dirs, files in os.walk(self.path):
            n += 1
            slash = root.count('\\')
            lvl = slash - root_slash
            delta = lvl - lvl_old
            lvl_old = lvl
            #print(root, lvl, delta)
            node = root.split('\\')[-1]
            if n > 0 and delta == 1:
                #parents.append(node)
                if test > 0:
                    item = item.parent().child(item.parent().childCount()-1)
                item.addChild(QtWidgets.QTreeWidgetItem([node]))
                item.child(item.childCount()-1).setIcon(0, QIcon(icon_folder))
                item = item.child(0)
                
                
            elif n > 0 and delta == 0:
                test += 1
                #parents.pop(-1)
                #parents.append(node)
                item.parent().addChild(QtWidgets.QTreeWidgetItem([node]))
                item.parent().child(item.parent().childCount()-1).setIcon(0, QIcon(icon_folder))

            elif n > 0 and delta < 0:
                for i in range(abs(delta)+1):
                    #parents.pop(-1)
                    item = item.parent()
                #parents.append(node)
                item.addChild(QtWidgets.QTreeWidgetItem([node]))
                item.child(item.childCount()-1).setIcon(0, QIcon(icon_folder))
                item = item.child(item.childCount()-1)

            #print(parents, files)
            if n > 0:
                for f in files:
                    item.parent().child(item.parent().childCount()-1).addChild(QtWidgets.QTreeWidgetItem([f]))
            else:
                for f in files:
                    self.tree.addTopLevelItem(QtWidgets.QTreeWidgetItem([f]))
        

    def import_prj_OK(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Импорт")
        mbox.setText("Импортировать выбранные шейпы в проект?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.import_prj)
        mbox.exec_()


    def import_prj(self, buttonOK):
        home_path = QgsProject.instance().homePath()
        imported_files = []
        
        if buttonOK.text() == "OK":
            list_selected = self.tree.selectedItems()
            for item in list_selected:
                path = self.path
                p_list = []
                p_list.append('/' + item.text(0))
                for i in range(1000):
                    try:
                        item = item.parent()
                        p = item.text(0)
                    except AttributeError:
                        print(p_list)
                        for i in range(len(p_list)-2, 0, -1):
                            path += p_list[i]
                        path += p_list[0]
                        print(path)
                        shutil.copyfile(path, home_path + p_list[0])
                        imported_files.append(home_path + p_list[0])
                        break

                    a = '/' + p 
                    p_list.append(a)
    
            for file in imported_files:
                try:
                    targetlayer = QgsVectorLayer(home_path + p_list[0], 'vec', "ogr")
                    QgsProject.instance().addMapLayer(targetlayer)
                except:
                    print('fnfe')
                    self.iface.addRasterLayer(home_path + p_list[0])
                else:
                    print('нет файлов')
                    continue


                
        else: print('Reject')


    def export_prj_OK(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Замена проекта")
        mbox.setText("Заменить проект в указанной папке?")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        mbox.buttonClicked.connect(self.export_prj)
        mbox.exec_()


    def export_prj(self, buttonOK):
        if buttonOK.text() == "OK":

            dst_path = self.dlg_prj_updater.export_FileWidget.filePath()+'\\*'
            home_path = QgsProject.instance().homePath()
            
            slash_cnt = dst_path.count('\\')
            print(dst_path, slash_cnt)

            files = glob.glob(dst_path)

            if dst_path != '\\*' and slash_cnt > 2:

                for f in files:
                    print('del', f)
                    os.remove(f)

                os.rmdir(dst_path[:-1])

                print('home', home_path)
                shutil.copytree(home_path, dst_path[:-1])

            else: print('Not file')

        else: print('Reject')

    #----------------------------------------------------------------------

    def run(self):

        self.dlg_prj_updater = GIS_Project_UpdaterDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_prj_updater.show()
        # Buttons click
        self.dlg_prj_updater.import_prj.clicked.connect(self.import_prj_OK)
        self.dlg_prj_updater.load_folder.clicked.connect(self.load_folder)
        self.dlg_prj_updater.export_prj.clicked.connect(self.export_prj_OK)
        
